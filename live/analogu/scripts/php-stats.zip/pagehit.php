<?
  require_once 'engine.php';
  $request = $_SERVER['REQUEST_URI'];
  if($_SERVER['REDIRECT_STATUS'] == '404')
    $request = '404:' . $request;
  elseif($_SERVER['REDIRECT_STATUS'] == '403')
    $request = '403:' . $request;
  elseif($_SERVER['REDIRECT_STATUS'] == '401')
    $request = '401:' . $request;
  $engine->query('insert into hits (instant, ip, page, referrer, useragent) values (' . time() . ', \'' . $_SERVER['REMOTE_ADDR'] . '\', \'' . $request . '\', \'' . $_SERVER['HTTP_REFERER'] . '\', \'' . $_SERVER['HTTP_USER_AGENT'] . '\')');
?>