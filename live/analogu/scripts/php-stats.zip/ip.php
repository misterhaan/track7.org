<?
/*----------------------------------------------------------------------------*\
 | provides hit statistics by ip address, for admin only.  expand links will  |
 | display next to each ip address to view more details.                      |
\*----------------------------------------------------------------------------*/

  require_once 'layout.php';
  define('GODMODE', $engine->godmode());

  // show a 404 page not found error if not admin
  if(!GODMODE)
    $engine->fake404();

  define('TITLE', 'ip statistics');

  // show full hit data for an ip address
  if(isset($_GET['expand'])) {
    $layout->start('ip statistics', 'for ' . htmlspecialchars($_GET['expand']) . ' (' . htmlspecialchars(gethostbyaddr($_GET['expand'])) . ')', '', htmlspecialchars($_GET['expand']) . ' - ip statistics');

    // default sort is by instant
    if(!isset($_GET['sort']))
      $_GET['sort'] = 'instant';

    $hits = 'select * from hits where ip=\'' . $_GET['expand'] . '\' order by ' . $_GET['sort'] . ($_GET['sort'] == 'instant' ? ' desc' : '');
    if($hits = $engine->splitquery($hits, 50, 0, '', '', 'error reading hits for this ip:<br />', 'no hits found for this ip', true)) {
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th><a href="<?=$_SERVER['PHP_SELF']; ?>?expand=<?=$_GET['expand']; ?>&amp;sort=instant" title="sort by this column">time</a></th><th><a href="<?=$_SERVER['PHP_SELF']; ?>?expand=<?=$_GET['expand']; ?>&amp;sort=page" title="sort by this column">page</a></th><th><a href="<? echo $_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=referrer" title="sort by this column">referrer</a></th><th><a href="<? echo $_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=useragent" title="sort by this column">useragent</a></th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->split_skip];
      while($hit = $hits->fetchRow())
        echo '          <tr><td>' . ++$row . '</td><td>' . date('Y�m�d g:i a',$hit->instant) . '</td><td>' . htmlspecialchars($hit->page) . '</td><td>' . ((strlen($hit->referrer) <= 0) ? '' : '<a href="' . htmlspecialchars($hit->referrer) . '">' . htmlspecialchars(URL::strip($hit->referrer)) . '</a>') . '</td><td>' . htmlspecialchars($hit->useragent) . "</td></tr>\n";
?>
        </tbody>
      </table>

<?
      $layout->splitqlinks(array('expand'));
    }

  // show ip address stats -- we didn't have admin asking for details
  } else {
    $layout->start('ip statistics', '', '', 'ip statistics');

    $ips = 'select ip, hits from statip order by hits desc';
    if($ips = $engine->splitquery($ips, 50, 0, '', '', 'error reading ip statistics:<br />', 'no ip statistics found')) {
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th>ip</th><th>hits</th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->skip];
      while($ip = $ips->fetchRow())
        echo '          <tr><td>' . ++$row . '</td><td>' . $ip->ip . '</td><td class="hits">' . $ip->hits . '</td><td class="clear"><a href="' . $_SERVER['PHP_SELF'] . '?expand=' . $ip->ip . '" title="see all hits for this ip"><img src="details.png" alt="details" /></a></td></tr>' . "\n";
?>
        </tbody>
      </table>
<?
      $layout->splitqlinks();
    }
  }
  $layout->end();
?>
