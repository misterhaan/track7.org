<?
/*----------------------------------------------------------------------------*\
 | provides hit statistics by useragent.  admin will get expand links next to |
 | each browser or operating system to view more details.                     |
\*----------------------------------------------------------------------------*/

  require_once 'layout.php';
  define('GODMODE', $engine->godmode());
  
  // show full hit data for a useragent if admin asks for it
  if(GODMODE && isset($_GET['expand'])) {
    // default sort is by instant
    if(!isset($_GET['sort'])) {
      $_GET['sort'] = 'instant';
    }
    if(!isset($_GET['type']) || !($_GET['type'] == 'browser' || $_GET['type'] == 'os'))
      $_GET['type'] = 'useragent';
    $layout->start($_GET['type'] . ' statistics', 'for ' . htmlspecialchars($_GET['expand']), '', htmlspecialchars($_GET['expand']));
    $hits = '';
    if($_GET['type'] != 'useragent') {
      $uas = 'select useragent from statuseragent where ' . $_GET['type'] . '=\'' . GPC::slash($_GET['expand']) . '\'';
      if($uas = $engine->query($uas, 'error getting useragents for this ' . $_GET['type'] . ':<br />', 'no useragents found for this ' . $_GET['type'], true)) {
        while($ua = $uas->fetchRow())
          $hits .= ' or useragent=\'' . GPC::slash($ua->useragent) . '\'';
        $hits = substr($hits, 4);
      }
    } else
      $hits = 'useragent=\'' . GPC::slash($_GET['expand']) . '\'';

    if(strlen($hits)) {
      $hits = 'select * from hits where ' . $hits . ' order by ' . $_GET['sort'] . ($_GET['sort'] == 'instant' ? ' desc' : '');
      if($hits = $engine->splitquery($hits, 50, 0, '', '', 'error getting statistics for this ' . $_GET['type'] . ':<br />', 'no statistics found for this ' . $_GET['type'], true)) {
        $_GET['expand'] = GPC::unslash($_GET['expand']);
      if($_GET['type'] == 'useragent')
        $url = $_SERVER['PHP_SELF'] . '?expand=' . htmlspecialchars($_GET['expand']);
      else
        $url = str_replace('useragent', $_GET['type'], $_SERVER['PHP_SELF']) . '?expand=' . htmlspecialchars($_GET['expand']);
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th><a href="<?=$url; ?>&amp;sort=instant" title="sort by this column">time</a></th><th><a href="<?=$url; ?>&amp;sort=ip" title="sort by this column">ip</a></th><th><a href="<?=$url; ?>&amp;sort=page" title="sort by this column">page</a></th><th><a href="<?=$url; ?>&amp;sort=referrer" title="sort by this column">referrer</a></th><th><a href="<?=$url; ?>&amp;sort=useragent" title="sort by this column">useragent</a></th></tr></thead>
        <tbody>
<?
        $row = $_GET[$engine->split_skip];
        while($hit = $hits->fetchRow())
          echo '          <tr><td>' . ++$row . '</td><td>' . date('Y�m�d g:i a',$hit->instant) . '</td><td>' . $hit->ip . '</td><td>' . URL::strip($hit->page) . '</td><td>' . ((strlen($hit->referrer) <= 0) ? '' : '<a href="' . htmlspecialchars($hit->referrer) . '">' . htmlspecialchars(URL::strip($hit->referrer)) . '</a>') . '</td><td>' . htmlspecialchars($hit->useragent) . "</td></tr>\n";
?>
        </tbody>
      </table>
<?
        $layout->splitqlinks(array('type', 'expand'));
      }
    }

  // if they didn't specify browser or os, give a 404 error
  } elseif($_GET['type'] != 'browser' && $_GET['type'] != 'os') {
    $engine->fake404();

  // show browser / os stats -- we didn't have admin asking for details
  } else {
    $layout->start($_GET['type'] . ' statistics', '', '', $_GET['type'] . ' statistics');
    if($_GET['type'] == 'os') {
?>
      <p>
        the following list shows the number of hits this site has recieved from
        each of the listed operating systems.&nbsp; this should give some idea
        as to how people are viewing the site.
      </p>
      <hr class="minor" />

<?
    } else {
?>
      <p>
        the following list shows the number of hits this site has recieved from
        each of the listed browsers.&nbsp; this should give some idea as to how
        people are viewing the site, and also includes bots that sometimes crawl
        the site.
      </p>
      <hr class="minor" />

<?
    }
    $uas = 'select ' . $_GET['type'] . ' as keycol, sum(hits) as hitcount from statuseragent where ' . $_GET['type'] . ' is not null and not (' . $_GET['type'] . '=\'\') group by keycol order by hitcount desc';
    if($uas = $engine->splitquery($uas, 50, 0, '', '', 'error reading ' . $_GET['type'] . ' statistics:<br />', 'no ' . $_GET['type'] . ' statistics found', false, true)) {
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th><?=$_GET['type']; ?></th><th>hits</th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->split_skip];
      while($ua = $uas->fetchRow())
        echo '          <tr><td>'. ++$row . '</td><td>' . htmlspecialchars($ua->keycol) . '</td><td class="hits">' . $ua->hitcount . (GODMODE ? '</td><td class="clear"><a href="' . $_SERVER['PHP_SELF'] . '?type=' . $_GET['type'] . '&amp;expand=' . htmlspecialchars($ua->keycol) . '" title="see all hits for this ' . $_GET['type'] . '"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
?>
        </tbody>
      </table>
<?
      $layout->splitqlinks(array('type'));
    }
  }
  $layout->end();
?>
