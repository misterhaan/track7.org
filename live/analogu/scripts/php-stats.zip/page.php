<?
/*----------------------------------------------------------------------------*\
 | provides hit statistics by page.  admin will get expand links next to each |
 | page to view more details.                                                 |
\*----------------------------------------------------------------------------*/

  require_once 'layout.php';
  define('GODMODE', $engine->godmode());

  // show full hit data for a page if admin asks for it
  if(GODMODE && isset($_GET['expand'])) {
    // default sort is by instant
    if(!isset($_GET['sort']))
      $_GET['sort'] = 'instant';

    $layout->start('page statistics', 'for ' . htmlspecialchars($_GET['expand']), '', htmlspecialchars($_GET['expand']) . ' page statistics');

    $hits = 'select * from hits where page=\'' . GPC::slash($_GET['expand']) . '\' or page like \'' . GPC::slash($_GET['expand']) . '?%\'or page like \'' . GPC::slash($_GET['expand']) . 'index.php%\' order by ' . $_GET['sort'] . ($_GET['sort'] == 'instant' ? ' desc' : '');
    if($hits = $engine->splitquery($hits, 50, 0, '', '', 'error reading hits for this page:<br />', 'no hits found for this page')) {
      $_GET['expand'] = htmlspecialchars($_GET['expand']);
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th><a href="<?=$_SERVER['PHP_SELF']; ?>?expand=<?=$_GET['expand']; ?>&amp;sort=instant" title="sort by this column">time</a></th><th><a href="<?=$_SERVER['PHP_SELF']; ?>?expand=<?=$_GET['expand']; ?>&amp;sort=ip" title="sort by this column">ip</a></th><th><a href="<? echo $_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=referrer" title="sort by this column">referrer</a></th><th><a href="<? echo $_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=useragent" title="sort by this column">useragent</a></th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->split_skip];
      while($hit = $hits->fetchRow())
        echo '          <tr title="' . htmlspecialchars($hit->page) . '"><td>' . ++$row . '</td><td>' . date('Y�m�d g:i a',$hit->instant) . '</td><td>' . $hit->ip . '</td><td>' . ((strlen($hit->referrer) <= 0) ? '' : '<a href="' . htmlspecialchars($hit->referrer) . '">' . htmlspecialchars(URL::strip($hit->referrer)) . '</a>') . '</td><td>' . htmlspecialchars($hit->useragent) . "</td></tr>\n";
?>
        </tbody>
      </table>
<?
      $layout->splitqlinks(array('expand'));
    }
  
  // show page stats -- we didn't have admin asking for details
  } else {
    $layout->start('page statistics', '', '', 'page statistics');
?>
      <p>
        the following list shows the number of hits each page has received.&nbsp;
        this should give some idea as to what some of the more popular pages are.
      </p>
      <hr class="minor" />

<?
    $pages = 'select page, hits from statpage order by hits desc';
    if($pages = $engine->splitquery($pages, 50, 0, '', '', 'error reading page statistics:<br />', 'no page statistics found')) {
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th>page</th><th>hits</th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->split_skip];
      while($page = $pages->fetchRow())
        echo '          <tr><td>' . ++$row . '</td><td>' . $page->page . '</td><td class="hits">' . $page->hits . (GODMODE ? '</td><td class="clear"><a href="' . $_SERVER['PHP_SELF'] . '?expand=' . $page->page . '" title="see all hits for this page"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
?>
        </tbody>
      </table>
<?
      $layout->splitqlinks();
    }
  }
  $layout->end();
?>
