<?
/*----------------------------------------------------------------------------*\
 | provides hit statistics by month or by day.  without any GET parameters it |
 | shows month data, with $_GET['month'] (YYYY-MM) it shows days in that      |
 | month.  the days will have an expand link for admin to view more details.  |
\*----------------------------------------------------------------------------*/

  require_once 'layout.php';
  define('GODMODE', $engine->godmode());

  // show full hit data for a day if admin asks for it
  if(GODMODE && isset($_GET['expand'])) {
    $layout->start('daily statistics', 'for ' . htmlspecialchars($_GET['expand']), '', htmlspecialchars($_GET['expand']) . ' statistics');
    $expand = strtotime($_GET['expand']);
    // default sort is by instant
    if(!isset($_GET['sort']))
      $_GET['sort'] = 'instant';
    $stats = 'select * from hits' . ((date('Y', $expand) != date('Y') && time() - $expand > 7776000) ? date('Y', $expand) : '') . ' where instant>=' . $expand . ' and instant<' . DATE::tomorrow($expand) . ' order by ' . $_GET['sort'];  // 7776000 = 90 days
    if($stats = $engine->query($stats, 'error reading hits for this day:<br />', 'no hits found for this day', true)) {
      $_GET['expand'] = htmlspecialchars($_GET['expand']);  // shouldn't be needed, but safer
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=instant" title="sort by this column">time</a></th><th><a href="<?=$_SERVER['PHP_XELF']; ?>?expand=<?=$_GET['expand']; ?>&amp;sort=ip" title="sort by this column">ip</a></th><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=page" title="sort by this column">page</a></th><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=referrer" title="sort by this column">referrer</a></th><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=useragent" title="sort by this column">useragent</a></th></tr></thead>
        <tbody>
<?
      $row = $raw = $unique = 0;
      while($hit = $stats->fetchRow()) {
        if(substr($hit->page, 0, 2) != '40') {
          $raw++;
          if($hit->instant - $iptime[$hit->ip] >= 21600) // 21600 = 6 hours
            $unique++;
          $iptime[$hit->ip] = $hit->instant;
        }
        echo '            <tr><td>' . ++$row . '</td><td>' . date('g:i:s a',$hit->instant) . '</td><td>' . $hit->ip . '</td><td>' . htmlspecialchars(URL::strip($hit->page)) . '</td><td>' . ((strlen($hit->referrer) <= 0) ? '' : '<a href="' . htmlspecialchars($hit->referrer) . '">' . htmlspecialchars(URL::strip($hit->referrer)) . '</a>') . '</td><td>' . $hit->useragent . "</td></tr>\n";
      }
?>
        </tbody>
      </table>

      <p><?=$unique; ?> unique hits (<?=$raw; ?> raw)</p>

<?
    }

  // show monthly or daily stats -- we didn't have admin asking for day details
  } else {
    // if month is set, show data for all days in that month
    if(isset($_GET['month'])) {
      $layout->start('daily statistics', 'for ' . DATE::formatmonth($_GET['month'], 'F Y'), '', htmlspecialchars($_GET['month']) . ' daily statistics');
      $stats = 'select `date`, rhits, uhits from statdate where `date` like \'' . GPC::slash($_GET['month']) . '-%\' order by `date` desc';
      if($stats = $engine->query($stats, 'error reading statistics for this month:<br />', 'no statistics found for this month')) {
?>
      <table class="data" id="datestats">
        <thead><tr><th>date</th><th>raw</th><th>unique</th><th>pages</th><? if(GODMODE) echo '<td class="clear"></td>'; ?></tr></thead>
        <tbody>
<?
        while($day = $stats->fetchRow())
          echo '          <tr><td class="date">' . DATE::formatday($day->date, 'm�d�Y') . '</td><td>' . $day->rhits . '</td><td>' . $day->uhits . '</td><td>' . ($day->uhits > 0 ? number_format($day->rhits / $day->uhits, 1) : '&nbsp;') . (GODMODE ? '</td><td class="clear"><a href="' . $_SERVER['PHP_SELF'] . '?expand=' . $day->date . '" title="see all hits for this day"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
?>
        </tbody>
      </table>

<?
      }

    // month is not set, so show data for all months, along with daily and monthly graphs
    } else {
      $layout->start('monthly statistics', '', '', 'monthly statistics');
?>
      <p>
        the raw data below show daily visits, where raw is the total number of
        times some part of this site was accessed that day, unique is the number
        of times this site was accessed by a unique visitor in a 6-hour period,
        and pages is the average number of page views per unique visit.
      </p>

<?
      $stats = 'select month, rhits, uhits, days from statmonth where days>0 order by month desc';
      if($stats = $engine->query($stats, 'error reading monthly statistics:<br />', 'no monthly statistics found')) {
?>
      <table class="data" id="datestats">
        <thead><tr><th>month</th><th>raw</th><th>unique</th><th>pages</th></tr></thead>
        <tbody>
<?
        while($month = $stats->fetchRow())
          echo '          <tr><td class="date"><a href="' . $_SERVER['PHP_SELF'] . '?month=' . $month->month . '" title="view daily hits for this month">' . DATE::formatmonth($month->month, 'M Y') . '</a></td><td>' . number_format($month->rhits / $month->days, 1) . '</td><td>' . number_format($month->uhits / $month->days, 1) . '</td><td>' . ($month->uhits > 0 ? number_format($month->rhits / $month->uhits, 1) : '&nbsp;') . '</td></tr>' . "\n";
?>
        </tbody>
      </table>

<?
      }
    }
  }
  $layout->end();
?>
