<?
/*----------------------------------------------------------------------------*\
 | provides 404 statistics by request.  admin will get expand links next to   |
 | each page to view more details.                                            |
\*----------------------------------------------------------------------------*/

  require_once 'layout.php';
  define('GODMODE', $engine->godmode());

  // show full hit data for a request if admin asks for it
  if(GODMODE && isset($_GET['expand'])) {
    // default sort is by instant
    if(!isset($_GET['sort']))
      $_GET['sort'] = 'instant';

    $layout->start('nonexistant file statistics', 'for ' . htmlspecialchars($_GET['expand']), '', htmlspecialchars($_GET['expand']) . ' - 404 statistics');

    $hits = 'select * from hits where page=\'404:' . GPC::slash($_GET['expand']) . '\' or page like \'404:' . GPC::slash($_GET['expand']) . '?%\'or page like \'404:' . GPC::slash($_GET['expand']) . 'index.%\' order by ' . $_GET['sort'] . ($_GET['sort'] == 'instant' ? ' desc' : '');
    if($hits = $engine->splitquery($hits, 50, 0, '', '', 'error reading hits for this url:<br />', 'no hits found for this url')) {
      $_GET['expand'] = htmlspecialchars($_GET['expand']);
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th><a href="<?=$_SERVER['PHP_SELF']; ?>?expand=<?=$_GET['expand']; ?>&amp;sort=instant" title="sort by this column">time</a></th><th><a href="<?=$_SERVER['PHP_SELF']; ?>?expand=<?=$_GET['expand']; ?>&amp;sort=ip" title="sort by this column">ip</a></th><th><a href="<? echo $_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=referrer" title="sort by this column">referrer</a></th><th><a href="<? echo $_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=useragent" title="sort by this column">useragent</a></th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->split_skip];
      while($hit = $hits->fetchRow())
        echo '          <tr title="' . $hit->page . '"><td>' . ++$row . '</td><td>' . date('Y�m�d g:i a',$hit->instant) . '</td><td>' . $hit->ip . '</td><td>' . ((strlen($hit->referrer) <= 0) ? '' : '<a href="' . htmlspecialchars($hit->referrer) . '">' . htmlspecialchars(URL::strip($hit->referrer)) . '</a>') . '</td><td>' . htmlspecialchars($hit->useragent) . "</td></tr>\n";
?>
        </tbody>
      </table>
<?
      $layout->splitqlinks(array('expand'));
    }

  // show request stats -- we didn't have admin asking for details
  } else {
    $layout->start('nonexistant file statistics', '', '', '404 statistics');
?>
      <p>
        the following list shows files that don't exist that have people /
        bots have tried to find anyway.&nbsp; some of these files existed at one
        time and moved, others never existed at all and are weak attempts to
        crack this site.
      </p>
      <hr class="minor" />

<?
    require_once 'splitquery.php';
    // make sure the number of requests to skip and show are set appropriately
    if(!isset($_GET[SKIP]) || !is_numeric($_GET[SKIP]))
      $_GET[SKIP] = 0;
    if(!isset($_GET[SHOW]) || !is_numeric($_GET[SHOW]))
      $_GET[SHOW] = 50;
    $pages = 'select page, hits, notes from stat404 order by hits desc';
    if($pages = $engine->splitquery($pages, 50, 0, '', '', 'error reading 404 statistics:<br />', 'no 404 statistics found')) {
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th>page</th><th>hits</th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->split_skip];
      while($page = $pages->fetchRow()) {
        echo '          <tr><td>' . ++$row . '</td><td>' . $page->page . '</td><td class="hits">' . $page->hits . (GODMODE ? '</td><td class="clear"><a href="' . $_SERVER['PHP_SELF'] . '?expand=' . $page->page . '" title="see all hits for this page"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
      }
?>
        </tbody>
      </table>
<?
      $layout->splitqlinks();
    }
  }
  $layout->end();
?>
