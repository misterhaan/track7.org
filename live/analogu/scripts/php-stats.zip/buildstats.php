<?
/*----------------------------------------------------------------------------*\
 | compiles data from hits table into statistics tables.  meant to run from   |
 | a cron job nightly, though should work the same if run every second or     |
 | third day.                                                                 |
 |                                                                            |
 | command line arguments:  -verbose, -quiet, -silent                         |
 |   verbose shows all output, quiet shows only errors, silent produces no    |
 |   output at all.  the default is somewhere between verbose and quiet.      |
 |                                                                            |
\*----------------------------------------------------------------------------*/

  // you may need to MODIFY these with the correct path
  require_once '.consts.php';
  require_once 'engine.php';

  // adds a hit to a type of statistics--creates a row if there isn't one yet
  function updatetype($type, $selector) {
    global $engine;
    // don't do anything if the value is blank
    if(strlen($selector) <= 0)
      return;
    $query = 'select 1 from stat' . $type . ' where ' . ($type == '404' ? 'page' : $type) . '=\'' . addslashes(htmlspecialchars($selector)) . '\'';
    $query = $engine->query($query);
    if(DB::isError($query)) {
      if(!SILENT)
        echo "\n" . '** unable to check for ' . $type . ' entry in stats table:  ' . $query->getMessage();
    } elseif($query->numRows() > 0) {
      $query = 'update stat' . $type . ' set hits=hits+1 where ' . ($type == '404' ? 'page' : $type) . '=\'' . addslashes(htmlspecialchars($selector)) . '\'';
      $query = $engine->query($query);
      if(DB::isError($query) && !SILENT)
        echo "\n" . '** unable to update ' . $type . ' entry in stats table:  ' . $query->getMessage();
    } else {
      if(VERBOSE)
        echo "\n" . '* first entry for ' . $type . '=' . $selector;
      $query = 'insert into stat' . $type . ' (' . ($type == '404' ? 'page' : $type) . ', hits) values (\'' . addslashes(htmlspecialchars($selector)) . '\', 1)';
      $query = $engine->query($query);
      if(DB::isError($query) && !SILENT)
        echo "\n" . '** unable to insert ' . $type . ' entry in stats table:  ' . $query->getMessage();
    }
  }

  // add a new (empty) row to montly stats if it's the first day of the month
  function addaverages($thisdate) {
    global $engine;
    if(date('j', $thisdate) === '1') {
      $insert = 'insert into statmonth (month) values (\'' . date('Y-m', $thisdate) . '\')';
      $insert = $engine->query($insert);
      if(DB::isError($insert)) {
        if(!SILENT)
          echo "\n\n" . '*** unable to add row to stats table for new month:  ' . $insert->getMessage();
      } elseif(VERBOSE)
        echo "\n\n" . '* added row for new month';
    }
  }

  // check arguments from command line
  if(realpath($_SERVER['argv'][0]) == __FILE__) {
    define('VERBOSE', $_SERVER['argv'][1] == '-verbose');
    define('SILENT', $_SERVER['argv'][1] == '-silent');
    define('QUIET', SILENT || $_SERVER['argv'][1] == '-quiet');
  } else {
    define('VERBOSE', $_SERVER['argv'][0] == '-verbose');
    define('SILENT', $_SERVER['argv'][0] == '-silent');
    define('QUIET', SILENT || $_SERVER['argv'][0] == '-quiet');
  }

  // default date to stop at is today
  if(!isset($_GET['stopdate']))
    $_GET['stopdate'] = date('Y-m-d');

  // find which date needs to be processed next
  $nextdate = 'select `date` from statdate order by `date` desc';
  $nextdate = $engine->limitQuery($nextdate, 0, 1);
  if(DB::isError($nextdate))
    die('unable to read stats table to get next date:' . "\n" . $nextdate->getMessage());
  if($nextdate->numRows() == 1) {
    // there are dates in the stats table, so we need to get the day after the last one
    $nextdate = $nextdate->fetchRow();
    $nextdate = DATE::tomorrow(strtotime($nextdate->date));
  } else {
    // no dates in the stats table yet, so start from the oldest hit
    $nextdate = 'select instant from hits order by instant';
    $nextdate = $engine->limitQuery($nextdate, 0, 1);
    if(DB::isError($nextdate))
      die('unable to read page hit table to get next date:' . "\n" . $nextdate->getMessage());
    if($nextdate->numRows() < 1)
      die('page hit table is empty -- nothing to do!');
    else {
      $nextdate = $nextdate->fetchRow();
      $nextdate = strtotime(date('Y-m-d', $nextdate->instant));  // strip off time information
    }
  }

  // convert stopdate to timestamp
  $_GET['stopdate'] = strtotime($_GET['stopdate']);

  // make sure we don't run for more than 3 days
  if($_GET['stopdate'] - $nextdate > 259200)  // 2 (3, actually) days
    $_GET['stopdate'] = $nextdate + 259200;
  
  if(!QUIET)
    echo 'running for ' . strtolower(date('m-d-Y', $nextdate)) . ' up to ' . strtolower(date('m-d-Y', $_GET['stopdate']));
  while($nextdate < $_GET['stopdate']) {
    $iptime = array();
    $thisdate = $nextdate;
    $nextdate = DATE::tomorrow($nextdate);
    if(!QUIET)
      echo "\n\n\n" . 'calculating stats for ' . strtolower(date('l F j Y', $thisdate));
    $hits = 'select * from hits where instant<' . $nextdate . ' and instant >=' . $thisdate . ' order by instant';
    $hits = $engine->query($hits);
    if(DB::isError($hits)) {
      if(!SILENT)
        echo "\n\n" . '*** error reading hits from database:  ' . $hits->getMessage();
    } else {
      $dayshits['r'] = $dayshits['u'] = 0;
      while($hit = $hits->fetchRow()) {
        $unique = 0;
        if(VERBOSE)
          echo "\n\n" . date('h:i:sa', $hit->instant) . ' [' . $hit->ip . '] ' . $hit->page . ' (' . $hit->referer . ') ' . $hit->useragent;
        $hit->page = URL::strip($hit->page);
        $statcode = substr($hit->page, 0, 3);
        if($statcode != '403'  && $statcode != '401') {
          if($statcode == '404')
            $hit->page = substr($hit->page, 4);
          else
            $statcode = 'page';
          updatetype($statcode, $hit->page);
          $hit->referrer = URL::strip($hit->referrer);
          if($hit->instant - $iptime[$hit->ip] >= 21600) // 6 hours
            $unique = 1;
          $iptime[$hit->ip] = $hit->instant;
          updatetype('ip', $hit->ip);
          if($statcode != '404') {
            $dayshits['r']++;
            $dayshits['u'] += $unique;
            updatetype('referrer', $hit->referrer);
            updatetype('useragent', $hit->useragent);
          }
        }
      }
      addaverages($thisdate);
      $update = 'update statmonth set rhits=rhits+' . $dayshits['r'] . ', uhits=uhits+' . $dayshits['u'] . ', days=days+1 where month=\'' . date('Y-m', $thisdate) . '\'';
      $update = $engine->query($update);
      if(DB::isError($update) && !SILENT)
        echo "\n\n" . '*** unable to update month average:  ' . $update->getMessage();
      $update = 'insert into statdate (`date`, uhits, rhits) values (\'' . date('Y-m-d', $thisdate) . '\', ' . $dayshits['u'] . ', ' . $dayshits['r'] . ')';
      $update = $engine->query($update);
      if(DB::isError($update) && !SILENT)
        echo "\n\n" . '*** unable to add row for this date:  ' . $update->getMessage();
      if(!QUIET)
        echo "\n\n" . $dayshits['u'] . ' (' . $dayshits['r'] . ') hits';
    }
  }
  if(!QUIET)
    echo "\n\n\n" . 'reached stop date!';
?>
