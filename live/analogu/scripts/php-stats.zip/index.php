<?
/*----------------------------------------------------------------------------*\
 | provides a summary of statistics by showing top 5 or most recent 5 from    |
 | each category, and gives links to the full pages for each category.  also  |
 | provides simple admin interface for adding site field to referrer records  |
 | or browser and os fields to useragent records.                             |
\*----------------------------------------------------------------------------*/

  require_once 'layout.php';
  $layout->start('site statistics');
  define('GODMODE', $engine->godmode());

  // admin may request forms to enter data if $_GET['enter'] is set
  if(GODMODE) {
    if(isset($_GET['enter'])) {
      switch($_GET['enter']) {
  
        // deal with referrers to enter which site they belong to
        case 'referer':
          // make sure skip is a number
          if(!is_numeric($_POST['skip']))
            $_POST['skip'] = 0;
  
          if($_POST['submit'] == 'skip') {
            $_POST['skip']++;
            $layout->info('unknown referer \'' . GPC::unslash($_POST['referrer']) . '\'skipped');
  
          } elseif($_POST['submit'] == 'delete') {
            $del = 'delete from statreferrer where referrer=\'' . GPC::slash($_POST['referrer']) . '\'';
            if($engine->query($del, 'error deleting referrer \'' . GPC::unslash($_POST['referrer']) . '\':<br />'))
              $layout->info('deleted entry for referrer \'' . GPC::unslash($_POST['referrer']) . '\'');
  
          } elseif($_POST['submit'] == 'update') {
            $update = 'update statreferrer set site=\'' . GPC::slash($_POST['site']) . '\' where referrer=\'' . GPC::slash($_POST['referrer']) . '\'';
            if($engine->query($update, 'error updating referrer \'' . GPC::unslash($_POST['referrer']) . '\':<br />'))
              $layout->info('updated entry for referrer \'' . GPC::unslash($_POST['referrer']) . '\', set to \'' . GPC::unslash($_POST['site']) . '\'');
          }
  
          // get the next referrer that doesn't have a site set
          $referrers = 'select referrer, hits from statreferrer where site is null order by hits desc';
          if($referrers = $engine->limitQuery($referrers, $_POST['skip'], 1, 'error reading unknown referrers from database:<br />')) {
            if($referrers->numRows() < 1)
              if($_POST['skip'] == 0)
                $layout->info('there are no more unknown referrers');
              else
                $layout->info('there are no more unknown referrers, but you have skipped ' . $_POST['skip'] . ' of them');
            else {
              $referrers = $referrers->fetchRow();
              $referrers->referrer = htmlspecialchars($referrers->referrer);
              $form = new FORM($_SERVER['PHP_SELF'] . '?enter=referer');
                $form->startset('unknown referrer');
                  $form->label('referrer:&nbsp; ' . $referrers->referrer . ' <a class="img" href="referrer.php?expand=' . $referrers->referrer . '"><img src="details.png" alt="details" /></a>');
                  $form->data('referrer', $referrers->referrer);
                  $form->label('hits:&nbsp; ' . $referrers->hits);
                  $form->data('skip', $_POST['skip']);
                  $form->field('site:', 'site');
                $form->endset(array('update', 'skip', 'delete'));
              $form->end();
            }
          }
          break;
  
        // deal with useragents to enter the browser and operating system they represent
        case 'useragent':
          // make sure skip is a number
          if(!is_numeric($_POST['skip']))
            $_POST['skip'] = 0;
  
          if($_POST['submit'] == 'skip') {
            $_POST['skip']++;
            $layout->info('unknown useragent \'' . htmlspecialchars(GPC::unslash($_POST['useragent'])) . '\'skipped');
          
          } elseif($_POST['submit'] == 'delete') {
            $del = 'delete from statuseragent where useragent=\'' . GPC::slash($_POST['useragent']) . '\'';
            if($engine->query($del, 'error deleting useragent \'' . htmlspecialchars(GPC::unslash($_POST['useragent'])) . '\':<br />'))
              $layout->info('deleted entry for useragent \'' . htmlspecialchars(GPC::unslash($_POST['useragent'])) . '\'');
          
          } elseif($_POST['submit'] == 'update') {
            $update = 'update statuseragent set browser=\'' . GPC::slash($_POST['browser']) . '\', os=\'' . GPC::slash($_POST['os']) . '\' where useragent=\'' . GPC::slash($_POST['useragent']) . '\'';
            if($engine->query($update, 'error updating useragent \'' . htmlspecialchars(GPC::unslash($_POST['useragent'])) . '\':<br />'))
              $layout->info('updated entry for useragent \'' . htmlspecialchars(GPC::unslash($_POST['useragent'])) . '\', set to \'' . GPC::unslash($_POST['browser']) . '\' and \'' . GPC::unslash($_POST['os']) . '\'');
          }
  
          // get the next useragent that doesn't have browser or os set yet
          $ua = 'select useragent, hits from statuseragent where browser is null and os is null order by hits desc';
          if($ua = $engine->limitQuery($ua, $_POST['skip'], 1, 'error reading unknown useragents from database:<br />')) {
            if($ua->numRows() < 1)
              if($_POST['skip'] == 0)
                $layout->info('there are no more unknown useragents');
              else
                $layout->info('there are no more unknown useragents, but you have skipped ' . $_POST['skip'] . ' of them');
            else {
              $ua = $ua->fetchRow();
              $ua->useragent = htmlspecialchars($ua->useragent);
              $form = new FORM($_SERVER['PHP_SELF'] . '?enter=useragent');
                $form->startset('unknown useragent');
                  $form->label('useragent:&nbsp; ' . $ua->useragent . ' <a class="img" href="useragent.php?expand=' . $ua->useragent . '"><img src="details.png" alt="details" /></a>');
                  $form->data('useragent', $ua->useragent);
                  $form->label('hits:&nbsp; ' . $ua->hits);
                  $form->data('skip', $_POST['skip']);
                  $form->field('browser:', 'browser', _FORM_NORMAL, '', 16);
                  $form->field('os:', 'os', _FORM_NORMAL, '', 16);
                $form->endset(array('update', 'skip', 'delete'));
              $form->end();
            }
          }
          break;
      }
    }

    // show links for entering data for any unknown useragents / referrers
    $referers = 'select count(1) from statreferrer where site is null';
    $referers = $engine->getOne($referers, 'error getting count of unknown referrers:<br />');
    if($referers < 1)
      $referers = 0;
    $uas = 'select count(1) from statuseragent where browser is null and os is null';
    $uas = $engine->getOne($uas, 'error getting count of unknown useragents:<br />');
    if($uas < 1)
      $uas = 0;
    if($referers > 0 || $uas > 0) {
      echo '      <ul>' . "\n";
      if($referers > 0)
        echo '        <li><a href="' . $_SERVER['PHP_SELF'] . '?enter=referer" title="enter site for unknown referrers">' . $referers . ' unknown referrers</a></li>' . "\n";
      if($uas > 0)
        echo '        <li><a href="' . $_SERVER['PHP_SELF'] . '?enter=useragent" title="enter site for unknown referrers">' . $uas . ' unknown useragents</a></li>' . "\n";
      echo '      </ul>' . "\n\n";
    }
  }

  // the rest of this can be seen by anybody (for the most part)

  // show the past 5 days' statistics, with a link to the monthly stats page
  $daily = 'select `date`,rhits,uhits from statdate order by `date` desc';
  if($daily = $engine->limitQuery($daily, 0, 5, 'error reading daily statistics:<br />')) {
?>
      <h2>past 5 days</h2>
      <table class="data" id="datestats">
        <thead><tr><th>date</th><th>raw</th><th>unique</th><th>pages</th><? if(GODMODE) echo '<td class="clear"></td>'; ?></tr></thead>
        <tbody>
<?
    if(GODMODE) {
?>
          <tr><td class="date"><?=date('m�d�Y'); ?></td><td class="note">(today)</td><td class="note">(today)</td><td class="note">(today)</td><td class="clear"><a href="daily.php?expand=<?=date('Y-m-d'); ?>" title="see all hits for today"><img src="details.png" alt="details" /></a></td></tr>
<?
    }
    while($day = $daily->fetchRow())
      echo '          <tr><td class="date">' . date('m�d�Y', strtotime($day->date)) . '</td><td>' . $day->rhits . '</td><td>' . $day->uhits . '</td><td>' . (($day->uhits > 0) ? number_format($day->rhits / $day->uhits, 1) : '') . (GODMODE ? '</td><td class="clear"><a href="daily.php?expand=' . $day->date . '" title="see all hits for this day"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
    $days = 'select count(1) from statdate';
    $days = $engine->getOne($days);
    if(DB::isError($days))
      $days = '(unknown)';
?>
        </tbody>
        <tfoot class="seemore">
          <tr><td colspan="4"><a href="daily.php" title="daily statistics">view months (<?=$days; ?> days total)</a></td></tr>
        </tfoot>
      </table>

<?
  }

  // show the 5 most popular pages, with a link to the page stats page
  $pages = 'select page, hits from statpage order by hits desc';
  if($pages = $engine->limitQuery($pages, 0, 5, 'error reading page statistics:<br />')) {
?>
      <h2>top 5 pages</h2>
      <table class="data">
        <thead><tr><th>page</th><th>hits</th><? if(GODMODE) echo '<td class="clear"></td>'; ?></tr></thead>
        <tbody>
<?
    while($page = $pages->fetchRow())
      echo '          <tr><td>' . $page->page . '</td><td class="hits">' . $page->hits . (GODMODE ? '</td><td class="clear"><a href="page.php?expand=' . $page->page . '" title="see all hits for this page"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
    $pages = 'select count(1) from statpage';
    $pages = $engine->getOne($pages);
    if(DB::isError($pages))
      $pages = '(unknown)';
?>
        </tbody>
        <tfoot class="seemore">
          <tr><td colspan="2"><a href="page.php" title="page statistics">view more pages (<?=$pages; ?> total)</a></td></tr>
        </tfoot>
      </table>

<?
  }

  // show the 5 most common requests for files that don't exist, with a link
  if(GODMODE) {
    $pages = 'select page, hits from stat404 order by hits desc';
    if($pages = $engine->limitQuery($pages, 0, 5, 'error reading 404 statistics:<br />')) {
?>
      <h2>top 5 nonexistant files</h2>
      <table class="data">
        <thead><tr><th>file</th><th>hits</th><?=(GODMODE ? '<td class="clear"></td>' : ''); ?></tr></thead>
        <tbody>
<?
      while($page = $pages->fetchRow())
        echo '          <tr><td>' . $page->page . '</td><td class="hits">' . $page->hits . (GODMODE ? '</td><td class="clear"><a href="404.php?expand=' . $page->page . '" title="see all hits for this file"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
      $pages = 'select count(1) from stat404';
      $pages = $engine->getOne($pages);
      if(DB::isError($pages))
        $pages = '(unknown)';
?>
        </tbody>
        <tfoot class="seemore">
          <tr><td colspan="2"><a href="404.php" title="page statistics">view more nonexistant files (<?=$pages; ?> total)</a></td></tr>
        </tfoot>
      </table>

<?
    }
  }

  // show the 5 most common sites that people get here from
  // also give admin a link to enter sites for referrers that don't have one, if any
  $referers = 'select site, sum(hits) as sitehits from statreferrer where site is not null and site not like \'%track7.org%\' group by site order by sitehits desc';
  if($referers = $engine->limitQuery($referers, 0, 5, 'error reading referrer statistics:<br />')) {
?>
      <h2>top 5 referrers</h2>
      <table class="data">
        <thead><tr><th>referer</th><th>hits</th><? if(GODMODE) echo '<td class="clear"></td>'; ?></tr></thead>
        <tbody>
<?
    while($referer = $referers->fetchRow())
      echo '          <tr><td class="url"><a class="url" href="' . $referer->site . '">' . $referer->site . '</a></td><td class="hits">' . $referer->sitehits . (GODMODE ? '</td><td class="clear"><a href="referrer.php?expand=' . $referer->site . '" title="see all hits for this referrer"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
    $referers = 'select distinct site from statreferrer where site is not null and site not like \'%track7.org%\'';
    $referers = $engine->query($referers);
    if(DB::isError($referers))
      $referers = '(unknown)';
    else
      $referers = $referers->numRows();
?>
        </tbody>
        <tfoot class="seemore">
          <tr><td colspan="2"><a href="referrer.php" title="referrer statistics">view more referrers (<?=$referers; ?> total)</a></td></tr>
        </tfoot>
      </table>

<?
  }

  // show the 5 most common browsers (not bots) that people view the site with
  // also give admin a link to enter browser and os for unknown useragents, if any
  $browsers = 'select browser, sum(hits) as bhits from statuseragent where browser is not null and not (os=\'(robot)\') group by browser order by bhits desc';
  if($browsers = $engine->limitQuery($browsers, 0, 5, 'error reading browser statistics:<br />')) {
?>
      <h2>top 5 browsers</h2>
      <table class="data">
        <thead><tr><th>browser</th><th>hits</th><? if(GODMODE) echo '<td class="clear"></td>'; ?></tr></thead>
        <tbody>
<?
    while($browser = $browsers->fetchRow())
      echo '          <tr><td class="url">' . $browser->browser . '</td><td class="hits">' . $browser->bhits . (GODMODE ? '</td><td class="clear"><a href="useragent.php?type=browser&amp;expand=' . $browser->browser . '" title="see all hits for this browser"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
    $browsers = 'select distinct browser from statuseragent where browser is not null';
    $browsers = $engine->query($browsers);
    if(DB::isError($browsers))
      $browsers = '(unknown)';
    else
      $browsers = $browsers->numRows();
?>
        </tbody>
        <tfoot class="seemore">
          <tr><td colspan="2"><a href="browser.php" title="browser statistics">view more browsers (<?=$browsers; ?> total)</a></td></tr>
        </tfoot>
      </table>

<?
  }

  // show the 5 most common operating systems (not bots) that people view the site with
  // also give admin a link to enter browser and os for unknown useragents, if any
  $oss = 'select os, sum(hits) as oshits from statuseragent where not (os is null or os=\'(robot)\') group by os order by oshits desc';
  if($oss = $engine->limitQuery($oss, 0, 5, 'error reading os statistics:<br />')) {
?>
      <h2>top 5 operating systems</h2>
      <table class="data">
        <thead><tr><th>operating system</th><th>hits</th><? if(GODMODE) echo '<td class="clear"></td>'; ?></tr></thead>
        <tbody>
<?
    while($os = $oss->fetchRow())
      echo '          <tr><td class="url">' . $os->os . '</td><td class="hits">' . $os->oshits . (GODMODE ? '</td><td class="clear"><a href="useragent.php?type=os&amp;expand=' . $os->os . '" title="see all hits for this operating system"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
    $oss = 'select distinct os from statuseragent where os is not null';
    $oss = $engine->query($oss);
    if(DB::isError($oss))
      $oss = '(unknown)';
    else
      $oss = $oss->numRows();
?>
        </tbody>
        <tfoot class="seemore">
          <tr><td colspan="2"><a href="os.php" title="operating system statistics">view more operating systems (<?=$oss; ?> total)</a></td></tr>
        </tfoot>
      </table>

<?
  }

  // show top 5 ip addresses, but only to admin (for privacy issues)
  if(GODMODE) {
    $ips = 'select ip, hits from statip order by hits desc';
    if($ips = $engine->limitQuery($ips, 0, 5, 'error reading ip statistics:<br />')) {
?>
      <h2>top 5 ip addresses</h2>
      <table class="data">
        <thead><tr><th>ip</th><th>hits</th><td class="clear"></td></tr></thead>
        <tbody>
<?
      while($ip = $ips->fetchRow())
        echo '          <tr><td>' . $ip->ip . '</td><td class="hits">' . $ip->hits . '</td><td class="clear"><a href="ip.php?expand=' . $ip->ip . '" title="see all hits from this ip address"><img src="details.png" alt="details" /></a></td></tr>' . "\n";
      $ips = 'select count(1) from statip';
      $ips = $engine->getOne($ips);
      if(DB::isError($ips))
        $ips = '(unknown)';
?>
        </tbody>
        <tfoot class="seemore">
          <tr><td colspan="2"><a href="ip.php" title="ip address statistics">view more ips (<?=$ips; ?> total)</a></td></tr>
        </tfoot>
      </table>
<?
    }
  }

  $layout->end();
?>
