<?
/*----------------------------------------------------------------------------*\
 | provides hit statistics by referrer.  admin will get expand links next to  |
 | each referrer to view more details.                                        |
\*----------------------------------------------------------------------------*/

  require_once 'layout.php';
  define('GODMODE', $engine->godmode());

  // show full hit data for a referrer if admin asks for it
  if(GODMODE && isset($_GET['expand'])) {
    // default sort is by instant
    if(!isset($_GET['sort']))
      $_GET['sort'] = 'instant';
    $layout->start('referrer statistics', 'for ' . htmlspecialchars($_GET['expand']));
    $_GET['expand'] = GPC::slash($_GET['expand']);
    $referrers = 'select referrer from statreferrer where site=\'' . $_GET['expand'] . '\'';
    if($referrers = $engine->query($referrers, 'error getting referring urls for this site:<br />')) {
      $hits = 'referrer=\'' . $_GET['expand'] . '\' or referrer like \'' . $_GET['expand'] . 'index.%\' or referrer like \'' . $_GET['expand'] . '?%\'';
      while($referrer = $referrers->fetchRow())
        $hits .= ' or referrer=\'' . $referrer->referrer . '\' or referrer like \'' . $referrer->referrer . 'index.%\' or referrer like \'' . $referrer->referrer . '?%\'';
      $hits = 'select * from hits where ' . $hits . ' order by ' . $_GET['sort'] . ($_GET['sort'] == 'instant' ? ' desc' : '');
      if($hits = $engine->splitquery($hits, 50, 0, '', '', 'error getting statistics for this referrer:<br />', 'could not find any hits for this referrer')) {
        $_GET['expand'] = htmlspecialchars(GPC::unslash($_GET['expand']));
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=instant" title="sort by this column">time</a></th><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=ip" title="sort by this column">ip</a></th><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=page" title="sort by this column">page</a></th><th><a href="<?=$_SERVER['PHP_SELF'] . '?expand=' . $_GET['expand']; ?>&amp;sort=useragent" title="sort by this column">useragent</a></th></tr></thead>
        <tbody>
<?
        $row = $_GET[$engine->split_skip];
        while($hit = $hits->fetchRow())
          echo '          <tr title="' . htmlspecialchars($hit->referrer) . '"><td>' . ++$row . '</td><td>' . date('Y�m�d g:i a', $hit->instant) . '</td><td>' . $hit->ip . '</td><td>' . URL::strip($hit->page) . '</td><td>' . htmlspecialchars($hit->useragent) . "</td></tr>\n";
?>
        </tbody>
      </table>
<?
        $layout->splitqlinks(array('expand'));
      }
    }

  // show referrer stats -- we didn't have admin asking for details
  } else {
    $layout->start('referrer statistics');
?>
      <p>
        the following list shows the number of hits this site has recieved from
        each of the listed refering urls.&nbsp; this should give some idea as to
        how people are finding the site, though a lot of times the referring url
        comes through blank.
      </p>
      <hr class="minor" />

<?
    $referers = 'select site, sum(hits) as sitehits from statreferrer where site is not null group by site order by sitehits desc';
    if($referers = $engine->splitquery($referers, 50, 0, '', '', 'error reading referrers:<br />', null, 0, true)) {
?>
      <table class="data">
        <thead><tr><td class="clear"></td><th>referrer</th><th>hits</th></tr></thead>
        <tbody>
<?
      $row = $_GET[$engine->split_skip];
      while($referer = $referers->fetchRow())
        echo '          <tr><td>'. ++$row . '</td><td class="referer"><a class="referer" href="' . $referer->site . '">' . URL::shorten($referer->site, 48) . '</a></td><td class="hits">' . $referer->sitehits . (GODMODE ? '</td><td class="clear"><a href="' . $_SERVER['PHP_SELF'] . '?expand=' . $referer->site . '"><img src="details.png" alt="details" /></a>' : '') . '</td></tr>' . "\n";
?>
        </tbody>
      </table>
<?
      $layout->splitqlinks();
    }
  }
  $layout->end();
?>
