// ==UserScript==
// @name           MoreSPORE
// @namespace      http://www.spore.com/view/myspore/misterhaan
// @description    Adds more information and links to spore.com profile pages
// @include        http://www.spore.com/view/myspore/*
// @include        http://www.spore.com/view/profile/*
// ==/UserScript==

if(document.location.pathname.substring(0, 13) == "/view/myspore") {
  var username = getUsername();
  if(username) {
    var uploaded = document.getElementById("creationsUpLabel");
    if(uploaded) {
      showSubscribers();
      showAchievements();
    }
    addQualitySporeLink();
  }
}

function showSubscribers() {
  var subs = document.createTextNode("(counting...)");
  addUserStat("subscribers", "Subscribers: ", subs);
  getAsync("http://www.spore.com/rest/users/subscribers/" + username + "/0/100000", gotSubscriberXml, subs);
}
function gotSubscriberXml(req, subs) {
	var response = req.responseXML.documentElement;
	var count = response.getElementsByTagName("count");
	count = count[0].firstChild.data;
	subs.data = count;
}

function showAchievements() {
  var achs = document.createTextNode("(counting...)");
  addUserStat("achievements", "Achievements: ", achs);
  getAsync("http://www.spore.com/rest/achievements/" + username + "/0/10000", gotAchievementXml, achs);
}
function gotAchievementXml(req, achs) {
	var response = req.responseXML.documentElement;
	var count = response.getElementsByTagName("length");
	count = count[0].firstChild.data;
	achs.data = count;
	var achHdr = document.getElementById("achHdr");
	if(achHdr)
	  achHdr.firstChild.data += " (" + count + ")";
}

function addUserStat(id, label, value) {
  var span = document.createElement("span");
  span.id = id;
  span.className = "userData";
  span.appendChild(value);
  var div = document.createElement("div");
  div.id = id + "Label";
  div.className = "dataLabel";
  div.style.marginTop = "10px";
  div.appendChild(document.createTextNode(label));
  div.appendChild(span);
  uploaded.parentNode.insertBefore(div, uploaded);
}

function addQualitySporeLink() {
	var userData = document.getElementById("pubUserDataDiv");
	if(userData) {
		var qslink = document.createElement("a");
		qslink.href = "http://www.qualityspore.com/ProfileViewer.htm?profile=" + username;
		qslink.appendChild(document.createTextNode("See " + username + "'s QualitySPORE profile"));
		var div = document.createElement("div");
		div.id = "qualitySporeLink";
		div.className = "dataLabel";
		div.appendChild(qslink);
		userData.parentNode.insertBefore(div, userData);
	}
}

function getUsername() {
	if(document.location.pathname == '/view/profile') {
		var h3 = document.getElementsByTagName("h3");
		for(var i in h3)
			if(h3[i].className == "profileUsertitle")
				return h3[i].firstChild.data.split("'")[0];
	} else {
		var username = document.location.pathname.split("/");
		return username[username.length - 1];
	}
}

function getAsync(url, finished, args) {
	var req = new XMLHttpRequest();
	req.onreadystatechange = function() {
		if(req.readyState == 4)
			finished(req, args);
	}
	req.open("GET", url, true);
	req.send(null);
	return true;
}
