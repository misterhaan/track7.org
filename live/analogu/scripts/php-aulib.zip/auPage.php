<?
/******************************************************************************\
 * Title:    Generic page layout class
 * Purpose:  Provides functions for common page layout operations.  It should
 *           be extended to handle the layout specific to a given website.
 * History:  0.0.0 - Initial release
 *           0.1.0 - Change charset to utf-8 from iso-8859-1
 *           0.2.0 - Fix Show404() so it doesn't come up blank
 *           0.2.0 - Add Scripts() to write out script tags for related scripts
\******************************************************************************/

  if(!defined('_AU_PAGE_SITE_TITLE'))
    define('_AU_PAGE_SITE_TITLE', 'Generic Layout Class');

/*============================================================[ auPage class ]==
  This class is meant to be extended as it includes only an incredibly basic
  layout.  Every page on a website should create a page object for itself and
  use it for common layout operations.
*/
  class auPage {
    protected $started = false;
    protected $ended = false;
    protected $error = null;
    protected $info = null;
    protected $indent = '';

/*------------------------------------------------------[ auPage constructor ]--
  Creates a new generic page layout object.
*/
    public function auPage() {
      // if using a pages database, this is where the page record is looked up.
    }

/*-------------------------------------------------------[ auPage.FindParent ]--
  Finds the parent page that the current page belongs to.  It takes into
  account both query string variables and directories.
  $url = URL of the current page.
  @return = URL of parent page.
*/
    protected function FindParent($url) {
      $array = explode('&', $url);
      if(count($array) > 1) {
        $ret = $array[0];
        for($i = 1; $i < count($array) - 1; $i++)
          $ret .= '&' . $array[$i];
        return $ret;
      }
      $array = explode('?', $url);
      if(count($array) > 1)
        return $array[0];
      $url = dirname($url);
      if(substr($url, -1) != '/')
        $url .= '/';
      return $url;
    }

/*------------------------------------------------------------[ auPage.Error ]--
  Displays an error on the page.  If the page hasn't been started yet, the
  error is saved and then displayed once the page starts.
  $message = Error message.
  $detail = Any details of the error.
*/
    public function Error($message, $detail = '') {
      if($this->started) {
        echo $this->indent . '<p class="error">' . $message;
        if($detail)
          echo ':&nbsp; ' . $detail;
        echo ".</p>\n";
      } else {
        if($detail)
          $this->error[] = $message . ':&nbsp; ' . $detail;
        else
          $this->error[] = $message;
      }
    }

/*-------------------------------------------------------------[ auPage.Info ]--
  Displays a message on the page.  If the page hasn't been started yet, the
  message is saved and then displayed once the page starts.
  $message = Informational message.
*/
    public function Info($message) {
      if($this->started)
        echo $this->indent . '<p class="info">' . $message . "</p>\n";
      else
        $this->info[] = $message;
    }

/*------------------------------------------------[ auPage.HasQueuedMessages ]--
  Determines whether the page has queued messages to show.
  @return = True if there are queued messages to show.
*/
    public function HasQueuedMessages() {
      return !$this->started && (is_array($this->error) && count($this->error) || is_array($this->info) && count($this->info));
    }

/*-----------------------------------------------[ auPage.ShowQueuedMessages ]--
  Displays all queued messages (errors and then information) on the page, once
  the page has been started.
*/
    protected function ShowQueuedMessages() {
      if($this->started) {
        if(is_array($this->error))
          foreach($this->error as $error)
            $this->Error($error);
        if(is_array($this->info))
          foreach($this->info as $info)
            $this->Info($info);
      }
    }

/*------------------------------------------------------------[ auPage.Start ]--
  Writes out the part of the layout that comes before the page-specific
  content.  Also writes any queued messages.
  $windowtitle = Title of the page to be displayed in the browser titlebar.
  $title = Title of the page, to be displayed on the page itself.
    Default is to use $windowvalue here too.
*/
    public function Start($windowtitle, $title = null) {
      if($this->started)
        return;
      $this->started = true;
      if($windowtitle == null)
        $windowtitle = $title;
      if(strpos($windowtitle, _AU_PAGE_SITE_TITLE) === false)
        $windowtitle .= ' - ' . _AU_PAGE_SITE_TITLE;
      header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title><?=$windowtitle; ?></title>
    <meta name="distribution" content="global" />
    <meta name="resource-type" content="document" />
    <meta name="language" content="en" />
<?
      $this->indent = '    ';
      $this->Favicon();
      $this->StyleSheets();
      $this->Scripts();
?>
  </head>
  <body>
<?
      if(strlen($title) > 0) {
?>
    <h1><?=$title; ?></h1>
<?
      }
      $this->ShowQueuedMessages();
    }

/*----------------------------------------------------------[ auPage.Favicon ]--
  Writes out a link to the most specific favicon that can be found.
*/
    protected function Favicon() {
      $path = $_SERVER['PHP_SELF'];
      if(substr($path, -1) != '/')
        $path = dirname($path);
      else
        $path = substr($path, 0, -1);
      while(strlen($path) > 1 && !file_exists($_SERVER['DOCUMENT_ROOT'] . $path . '/favicon.ico'))
        $path = dirname($path);
      if(strlen($path) == 1) {
        if(file_exists($_SERVER['DOCUMENT_ROOT'] . '/favicon.ico'))
          echo $this->indent . '<link rel="shortcut icon" href="/favicon.ico" />' . "\n";
      } else
        echo $this->indent . '<link rel="shortcut icon" href="' . $path . '/favicon.ico" />' . "\n";
    }

/*------------------------------------------------------[ auPage.StyleSheets ]--
  Writes out a link to the relevant style sheets.
*/
    protected function StyleSheets() {
      $css = str_replace('/', '-', substr($_SERVER['PHP_SELF'], 1, -4));  // remove the leading / as well as the .php, then change /s into -s
      while(strlen($css)) {
        if(file_exists($_SERVER['DOCUMENT_ROOT'] . '/style/' . $css . '.css'))
          $sheets[] = $css;  // collect in array now for looping backward later
        $css = explode('-', $css);
        unset($css[count($css) - 1]);
        $css = implode('-', $css);
      }
?>
    <link rel="stylesheet" href="/style/general.css" type="text/css" />
<?
      for($i = count($sheets) - 1; $i >= 0; $i--) {
?>
    <link rel="stylesheet" href="/style/<?=$sheets[$i]; ?>.css" type="text/css" />
<?
      }
      if(file_exists($_SERVER['DOCUMENT_ROOT'] . '/style/ie-fixes.css')) {
?>
    <!--[if IE]><link rel="stylesheet" href="/style/ie-fixes.css" type="text/css" /><![endif]-->
<?
        if(file_exists($_SERVER['DOCUMENT_ROOT'] . '/style/ie6-fixes.css')) {
?>
    <!--[if lt IE 7]><link rel="stylesheet" href="/style/ie6-fixes.css" type="text/css" /><![endif]-->
<?
        }
      }
      if(file_exists($_SERVER['DOCUMENT_ROOT'] . '/style/print.css')) {
?>
    <link rel="stylesheet" media="print" href="/style/print.css" type="text/css" />
<?
      }
    }

/*----------------------------------------------------------[ auPage.Scripts ]--
  Writes out a link to the relevant client-side scripts.
*/
    protected function Scripts() {
      $js = str_replace('/', '-', substr($_SERVER['PHP_SELF'], 1, -4));  // remove the leading / as well as the .php, then change /s into -s
      while(strlen($js)) {
        if(file_exists($_SERVER['DOCUMENT_ROOT'] . '/scripts/' . $js . '.js'))
          $scripts[] = $js;  // collect in array now for looping backward later
        $js = explode('-', $js);
        unset($js[count($js) - 1]);
        $js = implode('-', $js);
      }
      if(count($scripts)) {
?>
    <script src="/scripts/general.js" type="text/javascript"></script>
<?
      }
      for($i = count($scripts) - 1; $i >= 0; $i--) {
?>
    <script src="/scripts/<?=$scripts[$i]; ?>.js" type="text/javascript"></script>
<?
      }
    }

/*--------------------------------------------------------------[ auPage.End ]--
  Writes out the part of the layout that comes after the page-specific content.
*/
    public function End() {
      if(!$this->started || $this->ended)
        return;
?>
  </body>
</html>
<?
      $this->ended = true;
    }

/*----------------------------------------------------------[ auPage.Show404 ]--
  Sends a page not found header and then displays the 404 error page.
*/
    public function Show404() {
      header('HTTP/1.0 404 Not Found');
      $page = $this;
      @include $_SERVER['DOCUMENT_ROOT'] . '/404.php';
      die;
    }

/*----------------------------------------------------------[ auPage.Heading ]--
  Writes out a heading on the page.
  $heading = Text of the heading.
  $id = ID of the heading, to work as #$id in links.
*/
    public function Heading($heading, $id = '') {
      echo $this->indent . '<h2';
      if($id)
        echo ' id="' . $id . '"';
      echo '>' . $heading . "</h2>\n";
    }

/*-------------------------------------------------------[ auPage.SubHeading ]--
  Writes out a sub-heading on the page.
  $heading = Text of the sub-heading.
  $id = ID of the sub-heading, to work as #$id in links.
*/
    public function SubHeading($heading, $id = '') {
      echo $this->indent . '<h3';
      if($id)
        echo ' id="' . $id . '"';
      echo '>' . $heading . "</h3>\n";
    }
  }
?>
