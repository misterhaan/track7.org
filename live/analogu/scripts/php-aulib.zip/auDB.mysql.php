<?
/******************************************************************************\
 * Title:    Database class for MySQL using PHP's mysql_* functions.
 * Purpose:  Interacts with a MySQL database through PHP's mysql_* functions.
 * History:  0.0.0 - Initial release
 *           0.1.0 - Update var to public
 *           0.2.0 - Update to use auDBBase
\******************************************************************************/

require_once 'auDB.base.php';

/*==============================================================[ auDB class ]==
  Create an auDB object using new auDB(), then run queries against it with
  Get(), GetRecord(), GetValue(), GetLimit(), GetSplit(), Put(), and Change().
  NumQueries() will tell you how many queries have been run since the object
  was created.
*/
  class auDB extends auDBBase {

/*--------------------------------------------------------[ auDB constructor ]--
  Creates a new database object.
  $user = Username for database account.
  $pass = Password for database account.
  $host = Name of server hosting the database (often 'localhost' works).
  $name = Name of database to work with.
  $report = Object with Error($, $) and Info($) methods for displaying error
    and information messages.  Defaults to built-in object which simply writes
    HTML messages.
*/
    public function auDB($user, $pass, $host, $name, &$report = null) {
      mysql_connect($host, $user, $pass);
      mysql_select_db($name);
      parent::auDBBase($user, $pass, $host, $name, $report);
    }
    
/*-----------------------------------------------------------[ auDB.GetLimit ]--
  Runs an SQL SELECT query against the database and gets back a limited number
    of records in the results.
  $query = SQL SELECT query to run.
  $skip = Number of result records to skip.
  $show = Number of result records to show.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  $emptymsg = Message to report if the query does not return any results.
    Default is to return the results without checking to see if there are any
    results.
  $emptyerror = Whether empty results should be reported as an error.
    Default is to report empty results as information.
  @return = The results as an auDBResult object, or false.
*/
    public function GetLimit($query, $skip, $show, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      return $this->Get($query . ' limit ' . $skip . ', ' . $show, $errormsg, $emptymsg, $emptyerror);
    }

/*----------------------------------------------------------------[ auDB.Put ]--
  Runs an SQL INSERT or REPLACE query against the database.
  $query = SQL INSERT/REPLACE query to run.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  @return = The ID of the inserted record, or false on failure.
*/
    public function Put($query, $errormsg = null) {
      if(parent::Put($query, $errormsg))
        return mysql_insert_id();
      return false;
    }
  }

/*========================================================[ auDBResult class ]==
  Provides access to results of an SQL query.  This class is instantiated and
  returned by methods in the auDB class.
*/
  class auDBResult extends auDBResultBase {

/*--------------------------------------------------[ auDBResult constructor ]--
  Runs an SQL query against the database and provides access to the results.
  $query = SQL query to run.
*/
    public function auDBResult($query) {
      if($this->result = mysql_query($query)) {
        $this->error = false;
        $this->message = '';
        if(strtolower(substr(trim($query), 0, 6)) == 'select')
          $this->affected = mysql_num_rows($this->result);
        else
          $this->affected = mysql_affected_rows();
      } else {
        $this->error = true;
        $this->message = htmlspecialchars(mysql_error());
        $this->affected = 0;
      }
    }

/*---------------------------------------------------[ auDBResult.NextRecord ]--
  Returns the next record returned by the query.
  $object = Set to false to return the record as an array.
  @return = The next record returned by the query, or false if no more records.
*/
    public function NextRecord($object = true) {
      if(!$object)
        return mysql_fetch_array($this->result, MYSQL_NUM);
      return mysql_fetch_object($this->result);
    }
  }
?>
