<?
// History:
// 0.0.0 - Initial release
// 0.0.1 - Started using htmlentities / html_entity_decode
// 0.0.1 - Handle links to #id
// 0.2.0 - Added _CHARSET for htmlentities / html_entity_decode
// 0.3.0 - Added PhoneFormat
// 0.3.0 - Change [code] handling for one-line code samples
// 0.3.0 - Add assumeP parameter to BB2HTML()
// 0.3.0 - Fix handling of two links on the same line in BB2HTML()
// 0.3.0 - Add phpDoc
// 0.3.0 - Change htmlentities back to htmlspecialchars
// 0.3.0 - Added Diff
// 0.4.0 - Change SmartTime / SmartDate same year format to 2nd instead of 02nd
// 0.4.0 - Use blockquote instead of q for quotes

  if(!defined('_HOST')) {  // used to strip the local domain off link URLs
    list($host) = explode(':', strtolower($_SERVER['HTTP_HOST']), 2);  // put domain in lowercase, and strip off port number if there is one
    $host = preg_replace('/^(web|www[0-9]*|secure)\./', '', $host);  // remove the www. if there is one, so that the same cookie will work for both with and without the www
    define('_HOST', $host);
    unset($host);
  }
  if(!defined('_CHARSET'))
    define('_CHARSET', 'UTF-8');

  /**
   * Text class:  A static class grouping together functions dealing with text.
   * All functions should be called using auText::function.
   *
   * @package auLib
   * @author misterhaan
   * @copyright © 2008 - 2011 track7.org
   * @tutorial http://wiki.track7.org/auText
   */
  class auText {

    /**
     * Translates a true/false value into yes/no.
     *
     * @param bool $bool True/false value to translate.
     * @return string Yes or no.
     */
    public static function YesNo($bool) {
      return $bool ? 'yes' : 'no';
    }

    /**
     * Takes a contact address (e-mail or website) and forms it into a valid URL.
     *
     * @param string $link User-entered contact address.
     * @param bool $htmlspecialchars If false, the return value will not be made safe for HTML.
     * @return string Contact address formed into a valid URL.
     */
    public static function FixLink($link, $htmlspecialchars = true) {
      if(strlen($link) <= 0)
        return '';
      if($htmlspecialchars)
        $link = htmlspecialchars($link, ENT_COMPAT, _CHARSET);
      if(substr($link, 0, 1) == '#')  // links to the elsewhere on the page are okay
        return $link;
      if(substr($link, 0, 1) == '/')  // links to the root of this site are okay
        return $link;
      if(substr($link, 0, 7) != 'mailto:' && strpos($link, '//') === false)
        if(strpos($link, '@') !== false)
          return 'mailto:' . $link;
        else
          $link = 'http://' . $link;
      return preg_replace('/^https?:\/\/((web|www[0-9]*|secure)\.)?' . str_replace('.', '\.', _HOST) . '/i', '', $link);
    }

    /**
     * Strips both the querystring and any index.* from the end of a URL.
     *
     * @param string $url URL to strip.
     * @return string URL with querystring and index.* removed.
     */
    public static function StripURL($url) {
      return auText::StripIndex(auText::StripQuery($url));
    }

    /**
     * Strips the querystring from the end of a URL.
     *
     * @param string $url URL to strip.
     * @return string URL with querystring removed.
     */
    public static function StripQuery($url) {
      $url = explode('?', $url);
      return $url[0];
    }

    /**
     * Strips any index.* from the end of a URL.
     *
     * @param string $url URL to strip.
     * @return string URL with index.* removed.
     */
    public static function StripIndex($url) {
      return preg_replace('/(index\.((p|s)?html?|php3?)|(default\.asp))/i', '', $url);
    }

    /**
     * Takes an e-mail address and randomly chooses an obfuscation method to
     * avoid spambot harvests.
     *
     * @param string $email E-mail address to obfuscate.
     * @return string Obfuscated e-mail address.
     */
    public static function SafeEmail($email) {
      if(!preg_match('/(.+)@(.*?)\.(.+)/', $email, $mailarr))
        return $email;
      if($extratext = rand(0,1)) {
        $specific = array(
          'EINSTEIN',
          'SOCRATES',
          'LINCOLN',
          'CARROT',
          'ZEBRA',
          'POLAND'
        );
        $general = array(
          'physicist',
          'philosopher',
          'ex-president',
          'vegetable',
          'animal',
          'country'
        );
        $index = rand(0, count($specific) - 1);
        $char = round(strlen($mailarr[2]) / 2);
        $mailarr[2] = substr($mailarr[2], 0, $char) . $specific[$index] . substr($mailarr[2], $char);
        $mailarr[3] .= ' minus ' . $general[$index];
      }
      if(!$extratext || rand(0,1))
        return $mailarr[1] . '{at}' . $mailarr[2] . '[DOT]' . $mailarr[3];
      return $mailarr[1] . '@' . $mailarr[2] . '.' . $mailarr[3];
    }

    /**
     * Checks and formats a user-provided phone number.  Accepts input with 11
     * (where the first digit is 1), 10, or 7 digits.
     *
     * @param string $input User-entered phone number.
     * @param string $areaCodeFormat Format for phone numbers that specify an area code.  For a sample phone number input (101) 555-1234, 101 replaces %ac% in the format string, 555 replaces %lc%, and 1234 replaces %pc%.  Default format is (101) 555-1234.
     * @param string $localFormat Format for phone numbers that do not specify an area code.  The same %lc% and %pc% (but not %ac%) placeholders described for $areaCodeFormat also apply here.  Default format is 555-1234.
     * @return string Formatted phone number, or false if incorrect number of digits.
     */
    public static function PhoneFormat($input, $areaCodeFormat = '(%ac%) %lc%-%pc%', $localFormat = '%lc%-%pc%') {
      if(!preg_match('/^[^0-9]*1?[^0-9]*([0-9]{3})?[^0-9]*([0-9]{3})[^0-9]*([0-9]{4})[^0-9]*$/', $input, $match))
        return false;
      if(strlen($match[1]))
        return str_replace(array('%ac%', '%lc%', '%pc%'), array($match[1], $match[2], $match[3]), $areaCodeFormat);
      return str_replace(array('%lc%', '%pc%'), array($match[2], $match[3]), $localFormat);
    }

    /**
     * Converts end-of-line (EOL) characters to HTML equivalents of p and br
     * tags.  It is assumed that the end result will be contained within a p
     * tag.  It properly recognizes the three EOL forms of \r\n, \r, and \n.
     * Multiple spaces are converted to a non-breaking space followed by a
     * normal space.  An odd number of spaces greater than 2 will get rounded
     * down to the next even number of spaces.
     *
     * @param string $text User-entered text that may contain EOL characters or multiple spaces.
     * @return string Text converted to HTML.
     */
    public static function EOL2pbr($text) {
      return str_replace(array("\r\n", "\n", "\r"), '<br />',
             str_replace(array("\r\n\r\n", "\n\n", "\r\r"), '</p><p>',
             str_replace('  ', '&nbsp; ', $text)));
    }

    /**
     * Converts end-of-line (EOL) characters to HTML equivalent of br tags.  It
     * properly recognizes the three EOL forms of \r\n, \r, and \n.  Multiple
     * spaces are converted to a non-breaking space followed by a normal space.
     * An odd number of spaces greater than 2 will get rounded down to the next
     * even number of spaces.
     *
     * @param string $text User-entered text that may contain EOL characters or multiple spaces.
     * @return string Text converted to HTML.
     */
    public static function EOL2br($text) {
      return str_replace(array("\r\n", "\n", "\r"), '<br />',
             str_replace('  ', '&nbsp; ', $text));
    }

    /**
     * Undoes what EOL2pbr does.  Generally this should be used when the user
     * wants to edit something they previously entered.  It can also be used to
     * undo EOL2br as it simply wouldn't contain any p tags in that case.
     *
     * @param string $text HTML-formatted text.
     * @return string Text converted back to what the user entered.
     */
    public static function pbr2EOL($text) {
      return str_replace(array('</p>', '<p>', '<br />', '&nbsp;'), array("\n\n", '', "\n", ' '), $text);
    }
    public static function br2EOL($text) { return auText::pbr2EOL($text); }  // included since it makes more sense to have a function named this way to go with EOL2br.

    /**
     * Converts user-entered text that may contain BBcode into HTML.
     *
     * @param string $bb User-entered BBcode text.
     * @param bool $head Allows [head] and [subhead] BBcode tags if true.  Default is to not allow these tags.
     * @param bool $assumeP Assume the HTML will be enclosed within a paragragh tag if true.  Default is to assume a paragraph tag.
     * @return string
     */
    public static function BB2HTML($bb, $head = false, $assumeP = true) {
      $html = htmlspecialchars($bb, ENT_COMPAT, _CHARSET);
      $html = str_replace('  ', '&nbsp; ', $html);
      while(preg_match('/(^|(\r\n|\r|\n){1,2})\[code\](.+?)\[\/code\]((\r\n|\r|\n){1,2}|$)/s', $html, $code))
        $html = str_replace($code[0], '</p><samp>' . auText::EOL2br(str_replace(array('[', ']'), array('\[', '\]'), $code[3])) . '</samp><p>', $html);
      while(preg_match('/\[code\](.+?)\[\/code\]/', $html, $code))
        $html = str_replace($code[0], '<code>' . str_replace(array('[', ']'), array('\[', '\]'), $code[1]) . '</code>', $html);
      if($head) {
        $html = preg_replace('/(\r\n|\r|\n){0,2}\[head\](.+?)\[\/head\](\r\n|\r|\n){0,2}/is', '<h2>$2</h2>', $html);
        $html = preg_replace('/(\r\n|\r|\n){0,2}\[subhead\](.+?)\[\/subhead\](\r\n|\r|\n){0,2}/is', '<h3>$2</h3>', $html);
      }
      while(preg_match('/(\r\n|\r|\n){0,2}\[bullets\](\r\n|\r|\n)?(.+?)(\r\n|\r|\n)?\[\/bullets\](\r\n|\r|\n){0,2}/is', $html, $bullets))
        $html = str_replace($bullets[0], '</p><ul><li>' . str_replace(array("\r\n", "\r", "\n"), '</li><li>', $bullets[3]) . '</li></ul><p>', $html);
      while(preg_match('/(\r\n|\r|\n){0,2}\[numbers\](\r\n|\r|\n)?(.+?)(\r\n|\r|\n)?\[\/numbers\](\r\n|\r|\n){0,2}/is', $html, $numbers))
        $html = str_replace($numbers[0], '</p><ol><li>' . str_replace(array("\r\n", "\r", "\n"), '</li><li>', $numbers[3]) . '</li></ol><p>', $html);
      while(preg_match('/\[(link|url)=(.+?)](.+?)\[\/(link|url)]/', $html, $link))
        $html = str_replace($link[0], '<a href="' . auText::FixLink($link[2]) . '">' . $link[3] . '</a>', $html);
      while(preg_match('/(\r\n|\r|\n)?\[q](.+?)\[\/q](\r\n|\r|\n)?/s', $html, $quote))
        $html = str_replace($quote[0], '<blockquote><p>' . $quote[2] . '</p></blockquote>', $html);
      while(preg_match('/(\r\n|\r|\n)?\[q=([^\]]+)](.+?)\[\/q](\r\n|\r|\n)?/s', $html, $quote))
        $html = str_replace($quote[0], '<cite>' . $quote[2] . ' said:</cite><blockquote><p>' . $quote[3] . '</p></blockquote>', $html);
      $html = preg_replace('/\[i\](.+?)\[\/i\]/s', '<i>$1</i>', $html);
      $html = preg_replace('/\[b\](.+?)\[\/b\]/s', '<b>$1</b>', $html);
      $html = str_replace(array('\[', '\]'), array('[', ']'), $html);
      if(strpos($html, '<samp>') === false)
        $html = auText::EOL2pbr($html);
      else {
        $array = explode('<samp>', $html);
        $html = auText::EOL2pbr($array[0]);
        for($i = 1; $i < count($array); $i++) {
          $pieces = explode('</samp>', $array[$i]);
          $html .= '<samp>' . $pieces[0] . '</samp>' . auText::EOL2pbr($pieces[1]);
        }
      }
      if(!$assumeP) {
        if(substr($html, 0, 4) == '</p>')
          $html = substr($html, 4);
        else
          $html = '<p>' . $html;
        if(substr($html, -3) == '<p>')
          $html = substr($html, 0, -3);
        else
          $html .= '</p>';
      }
      return $html;
    }

    /**
     * Converts HTML generated from BBcode back to BBcode.  This should only
     * need to be used when a user is editing text they previously entered, or
     * quoting text entered by another user.
     *
     * @param string $html HTML code to convert back to BBcode.
     * @return string Text converted to BBcode.
     */
    public static function HTML2BB($html) {
      if(substr($html, 0, 3) == '<p>') {
        $html = substr($html, 3);
        if(substr($html, -4) == '</p>')
          $html = substr($html, 0, -4);
        else
          $html .= '<p>';
      } elseif(substr($html, -4) == '</p>')
        $html = '</p>' . substr($html, 0, -4);
      elseif(substr($html, 0, 1) == '<' && substr($html, -1) == '>')
        $html = '</p>' . $html . '<p>';
      $bb = auText::pbr2EOL($html);
      $bb = str_replace(array('<i>', '</i>', '<b>', '</b>'), array('[i]', '[/i]', '[b]', '[/b]'), $bb);
      $bb = preg_replace('/<cite>(.+?) said:<\/cite><blockquote>/', "\n" .'[q=$1]', $bb);
      $bb = preg_replace('/<cite>(.+?) said:<\/cite><q>/', "\n" .'[q=$1]', $bb);
      $bb = str_replace(array('<blockquote><p>', '<blockquote>', '</p></blockquote>', '</blockquote>'), array("\n[q]", "\n[q]", "[/q]\n", "[/q]\n"), $bb);
      $bb = str_replace(array('<q><p>', '<q>', '</p></q>', '</q>'), array("\n[q]", "\n[q]", "[/q]\n", "[/q]\n"), $bb);
      $bb = preg_replace('/<a href="([^"]*)">([^<].*?)<\/a>/', '[link=$1]$2[/link]', $bb);
      $bb = str_replace(array('</p><ol><li>', '</li></ol><p>', '</p><ul><li>', '</li></ul><p>', '</li><li>'), array("\n[numbers]", "[/numbers]\n", "\n[bullets]", "[/bullets]\n", "\n"), $bb);
      $bb = str_replace(array('<ol><li>', '</li></ol>', '<ul><li>', '</li></ul>', '</li><li>'), array("\n[numbers]", "[/numbers]\n", "\n[bullets]", "[/bullets]\n", "\n"), $bb);
      $bb = str_replace(array('<h3>', '</h3>', '<h2>', '</h2>'), array("\n[subhead]", "[/subhead]\n", "\n[head]", "[/head]\n"), $bb);
      $bb = str_replace(array('</p><samp>', '<code>', '</samp><p>', '</code>', '<samp>', '</samp>'), array("\n[code]", '[code]', "[/code]\n", '[/code]', '[code]', "[/code]\n"), $bb);
      $bb = auText::pbr2EOL($bb);
      return html_entity_decode($bb, ENT_COMPAT, _CHARSET);
    }

    /**
     * Perform a wordwise diff on two strings, highlighting old words with del and new words with ins tags.
     *
     * @param string $old Old version of the string
     * @param string $new New version of the string
     * @return string Combined string with changes highlighted
    */
    public static function Diff($old, $new) {
      return auText::diffArray(auText::makeArray($old), auText::makeArray($new));
    }

    /**
     * Turns an HTML string into an array of words, keeping tags together as one word.
     *
     * @param string $str HTML string to split
     * @return array Array of words from the string
    */
    private static function makeArray($str) {
      $words = explode(' ', $str);
      $tag = array();
      $ret = array();
      foreach($words as $word)
        if(count($tag)) {
          $tag[] = $word;
          $gt = explode('>', $word);
          if(count($gt) > 1 && strpos($gt[count($gt) - 1], '<') === false) {
            $ret[] = implode(' ', $tag);
            $tag = array();
          }
        } else {
          $lt = explode('<', $word);
          if(count($lt) > 1 && strpos($lt[count($lt) - 1], '>') === false)
            $tag[] = $word;
          else
            $ret[] = $word;
        }
      return $ret;
    }

    /**
     * Perform a diff on two string arrays, highlighting old strings with del and new strings with ins tags.
     *
     * @param array $old Old version of the array
     * @param array $new New version of the array
     * @return string Combined string with changes highlighted
    */
    private static function diffArray($old, $new) {
      foreach($old as $io => $valo) {
        $keysn = array_keys($new, $valo);
        foreach($keysn as $in) {
          $map[$io][$in] = $map[$io - 1][$in - 1] + 1;
          if($map[$io][$in] > $max) {
            $max = $map[$io][$in];
            $maxo = $io + 1 - $max;
            $maxn = $in + 1 - $max;
          }
        }
      }
      if($max)
        return implode(' ', array_merge(array(auText::diffArray(array_slice($old, 0, $maxo), array_slice($new, 0, $maxn))), array_slice($new, $maxn, $max), array(auText::diffArray(array_slice($old, $maxo + $max), array_slice($new, $maxn + $max)))));
      return '<del>' . implode(' ', $old) . '</del> <ins>' . implode(' ', $new) . '</ins>';
    }

    /**
     * Takes a unix timestamp and determines how long before now it occurred.
     *
     * @param integer $timestamp Unix timestamp.
     * @return string How long ago the timestamp was, in the form <value> <units>.
     */
    public static function HowLongAgo($timestamp) {
      $seconds = time() - $timestamp;
      if($seconds <= 90)
        return $seconds . ' second' . ($seconds != 1 ? 's' : '');
      $minutes = round($seconds / 60);
      if($minutes <= 90)
        return $minutes . ' minutes';
      $hours = round($minutes / 60);
      if($hours <= 36)
        return $hours . ' hours';
      $days = round($hours / 24);
      if($days <= 12)
        return $days . ' days';
      $weeks = round($days / 7);
      if($weeks <=6)
        return $weeks . ' weeks';
      $months = round($days * 12 / 365);
      if($months <= 18)
        return $months . ' months';
      $years = round($days / 365);
      return $years . ' years';
    }

    /**
     * Takes a Unix timestamp and intelligently converts it to a human-readable
     * time format with an appropriate level of detail.
     *
     * @param integer $timestamp Unix timestamp to convert.
     * @param object $tz Object that can handle timezones, providing a tzdate function.  The standard php date function is used by default.
     * @return string Human-readable time.
     */
    public static function SmartTime($timestamp, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      $diff = time() - $timestamp;
      if($diff < 86400 && date('Y-m-d') == date('Y-m-d', $timestamp)) // 86400 s == 1 day
        return $tz->tzdate('g:i a', $timestamp);
      if($diff < 518400) // 518400 s == 6 days
        return $tz->tzdate('l', $timestamp);
      if(date('Y') == date('Y', $timestamp))
        return $tz->tzdate('M j<\s\u\p>S</\s\u\p>', $timestamp);
      return $tz->tzdate('M Y', $timestamp);
    }

    /**
     * Takes a Unix timestamp and intelligently converts it to a human-readable
     * date format with an appropriate level of detail.
     *
     * @param integer $timestamp Unix timestamp to convert.
     * @param object $tz Object that can handle timezones, providing a tzdate function.  The standard php date function is used by default.
     * @return string Human-readable date.
     */
    public static function SmartDate($timestamp, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      if(time() - $timestamp < 518400) // 518400 s == 6 days
        return $tz->tzdate('l', $timestamp);
      if(date('Y') == date('Y', $timestamp))
        return $tz->tzdate('M j<\s\u\p>S</\s\u\p>', $timestamp);
      return $tz->tzdate('M Y', $timestamp);
    }

    /**
     * Takes a Unix timestamp and finds the timestamp for the following day.
     *
     * @param integer $today Unix timestamp of current day.
     * @return integer Unix timestamp of following day.
     */
    public static function Tomorrow($today) {
      return strtotime(date('Y-m-d', $today + 115200));  // 32 hours--helps for daylight savings
    }

    /**
     * Takes a formatted date and converts it to a different format.
     *
     * @param string $day Date in yyyy-mm-dd format (or something strtotime() understands).
     * @param string $format Format string -- see php date() for options.
     * @param object $tz Object that can handle timezones, providing a tzdate function.  The standard php date function is used by default.
     * @return string Formatted date.
     */
    public static function FormatDay($day, $format, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      return $tz->tzdate($format, strtotime($day));
    }

    /**
     * Takes a formatted date and converts it to a different format.
     *
     * @param string $month Month in yyyy-mm format.
     * @param string $format Format string -- see php date() for options.
     * @param object $tz Object that can handle timezones, providing a tzdate function.  The standard php date function is used by default.
     * @return string Formatted date.
     */
    public static function FormatMonth($month, $format, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      return $tz->tzdate($format, strtotime($month . '-01'));
    }
  }

  /**
   * This class is used by date and time functions if a different object with
   * tzdate() has not been provided.  It really shouldn't be used other than
   * that since it just duplicates date().
   */
  class auTextDefaultTZ {
    public function tzdate($fmt, $timestamp = false) {
      if($timestamp === false)
        $timestamp = time();
      return date($fmt, $timestamp);
    }
  }
?>