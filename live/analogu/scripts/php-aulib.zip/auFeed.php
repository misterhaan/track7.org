<?
// History:
// 0.1.0 - Initial release
// 0.2.0 - Added _CHARSET for htmlentities
// 0.3.0 - Add phpDoc
// 0.3.0 - Add xmlspecialchars function and atom:link tag

  if(!defined('_CHARSET'))
    define('_CHARSET', 'UTF-8');

  /**
   * Generic RSS feed class
   *
   * Provides functions for common RSS feed building operations.
   * @package auLib
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFeed
   */
  class auFeed {
    /**
     * Starts the XML for a feed, with some information about the entire feed.
     *
     * @param string $title Title of the feed.
     * @param string $url URL where the contents of the feed can be found.  Default is the website front page.
     * @param string $description A description of the feed.
     * @param string $copyright The copyright of the contents of the feed.
     * @param string $lang The language of the feed.  Default is 'en-us'.
     * @return auFeed
     */
    public function auFeed($title, $url = '', $description = '', $copyright = '', $lang = 'en-us') {
      header('Content-Type: application/rss+xml; charset=utf-8');
      echo '<?xml version="1.0" encoding="utf-8"?>' . "\n";
?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title><?=$this->xmlspecialchars($title); ?></title>
<?
    if(substr($url, 0, 1) != '/')
      $url = '/' . $url;
?>
    <link>http://<?=$_SERVER['HTTP_HOST']; ?><?=$url; ?></link>
    <atom:link href="http://<?=$_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" rel="self" type="application/rss+xml" />
<?
    if($description)
      echo '    <description>' . $this->xmlspecialchars($description) . "</description>\n";
    if($lang)
      echo '    <language>' . $this->xmlspecialchars($lang) . "</language>\n";
    if($copyright)
      echo '    <copyright>' . $this->xmlspecialchars($copyright) . "</copyright>\n";
?>
    <generator>auFeed, PHP/<?=phpversion(); ?></generator>
    <docs>http://blogs.law.harvard.edu/tech/rss</docs>

<?
    }

    /**
     * Adds an item to the feed.  All parameters are optional, but either
     * $description or $title must be provided.
     *
     * @param string $description Item description.
     * @param string $title Item title.
     * @param string $url URL where the content can be found on the main website.
     * @param integer $date Unix timestamp for the item.
     * @param string $id Unique identifier for the item.
     * @param bool $idLink Whether the ID is a link.  Default is not a link.
     */
    public function AddItem($description = '', $title = '', $url = '', $date = '', $id = '', $idLink = false) {
?>
    <item>
<?
      if($title)
        echo '      <title>' . $this->xmlspecialchars($title) . "</title>\n";
      if($url) {
        if(substr($url, 0, 1) != '/')
          $url = '/' . $url;
        echo '      <link>http://' . $_SERVER['HTTP_HOST'] . $url . "</link>\n";
      }
      if($description)
        echo '      <description><![CDATA[' . $description . "]]></description>\n";
      if($date)
        echo '      <pubDate>' . gmdate('r', $date) . "</pubDate>\n";
      if($id)
        if($idLink)
          echo '      <guid>http://' . $_SERVER['HTTP_HOST'] . $id . "</guid>\n";
        else
          echo '      <guid isPermaLink="false">' . $this->xmlspecialchars($id) . "</guid>\n";
?>
    </item>

<?      
    }

    /**
     * Closes out the XML for a feed.
     */
    public function End() {
?>
  </channel>
</rss>
<?
    }

    /**
     * Translates special characters to be valid in XML.
     *
     * @param string $text Text to be translated.
     * @return string Text translated to be valid in XML.
     */
    private function xmlspecialchars($text) {
      return str_replace(array('&', '<', '>'), array('&#x26;', '&#x3c;', '&#x3e;'), $text);
    }
  }
?>
