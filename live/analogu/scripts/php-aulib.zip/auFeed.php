<?
/******************************************************************************\
 * Title:    Generic RSS feed class
 * Purpose:  Provides functions for common RSS feed building operations.  It should
 *           be extended to handle the layout specific to a given website.
 * History:  0.1.0 - Initial release
 *           0.2.0 - Added _CHARSET for htmlentities
\******************************************************************************/

  if(!defined('_CHARSET'))
    define('_CHARSET', 'UTF-8');

/*============================================================[ auFeed class ]==
  RSS feeds can use this class to handle common functions. 
*/
  class auFeed {
/*------------------------------------------------------[ auFeed constructor ]--
  Starts the XML for a feed, with some information about the entire feed.
  $title = Title of the feed.
  $url = URL where the contents of the feed can be found.  Default is the
    website front page.
  $description = A description of the feed.
  $copyright = The copyright of the contents of the feed.
  $lang = The language of the feed.  Default is 'en-us'.
*/
    public function auFeed($title, $url = '', $description = '', $copyright = '', $lang = 'en-us') {
      header('Content-Type: application/rss+xml; charset=utf-8');
      echo '<?xml version="1.0" encoding="utf-8"?>' . "\n";
?>
<rss version="2.0">
  <channel>
    <title><?=htmlentities($title, ENT_COMPAT, _CHARSET); ?></title>
<?
    if(substr($url, 0, 1) != '/')
      $url = '/' . $url;
?>
    <link>http://<?=$_SERVER['HTTP_HOST']; ?><?=$url; ?></link>
<?
    if($description)
      echo '    <description>' . htmlentities($description, ENT_COMPAT, _CHARSET) . "</description>\n";
    if($lang)
      echo '    <language>' . $lang . "</language>\n";
    if($copyright)
      echo '    <copyright>' . htmlentities($copyright, ENT_COMPAT, _CHARSET) . "</copyright>\n";
?>
    <generator>auFeed, PHP/<?=phpversion(); ?></generator>
    <docs>http://blogs.law.harvard.edu/tech/rss</docs>

<?
    }

/*----------------------------------------------------------[ auFeed.AddItem ]--
  Adds an item to the feed.  All parameters are optional, but either
  $description or $title must be provided.
  $description = Item description.
  $title = Item title.
  $url = URL where the content can be found on the main website.
  $date = Unix timestamp for the item.
  $id = Unique identifier for the item.
  $idLink = Whether the ID is a link.  Default is not a link.
*/
    public Function AddItem($description = '', $title = '', $url = '', $date = '', $id = '', $idLink = false) {
?>
    <item>
<?
      if($title)
        echo '      <title>' . htmlentities($title, ENT_COMPAT, _CHARSET) . "</title>\n";
      if($url) {
        if(substr($url, 0, 1) != '/')
          $url = '/' . $url;
        echo '      <link>http://' . $_SERVER['HTTP_HOST'] . $url . "</link>\n";
      }
      if($description)
        echo '      <description><![CDATA[' . $description . "]]></description>\n";
      if($date)
        echo '      <pubDate>' . gmdate('r', $date) . "</pubDate>\n";
      if($id)
        if($idLink)
          echo '      <guid>http://' . $_SERVER['HTTP_HOST'] . $id . "</guid>\n";
        else
          echo '      <guid isPermaLink="false">' . $id . "</guid>\n";
?>
    </item>

<?      
    }

/*--------------------------------------------------------------[ auFeed.End ]--
  Closes out the XML for a feed.
*/
    public Function End() {
?>
  </channel>
</rss>
<?
    }
  }
?>
