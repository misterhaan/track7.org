<?
// History:
// 0.4.0 - Initial release

// URL for shortening URLs with bit.ly
define('_AU_SEND_BITLY_URL', 'http://api.bit.ly/v3/shorten');
// URL for posting tweets.
define('_AU_SEND_TWEET_URL', 'https://api.twitter.com/1/statuses/update.xml');

/**
 * Send class:  a static class providing functions to send messages using a
 * variety of protocols and services.
 * All functions should be called using auSend::function.
 *
 * @package auLib
 * @author misterhaan
 * @copyright © 2010 track7.org
 * @tutorial http://wiki.track7.org/auSend
 */
class auSend {
  /**
   * Shortens a URL using the bit.ly web service.  To use a bit.ly account, make
   * sure the constants _AU_SEND_BITLY_LOGIN and _AU_SEND_BITLY_KEY are set to
   * the login and API key for the account.
   * @param string $url URL to shorten.
   * @return string Shortened URL.
   */
  public static function Bitly($url) {
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, _AU_SEND_BITLY_URL . '?login=' . _AU_SEND_BITLY_LOGIN . '&apiKey=' . _AU_SEND_BITLY_KEY . '&uri=' . urlencode($url) . '&format=txt');
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_USERAGENT, 'auSend');
    curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($c, CURLOPT_TIMEOUT, 30);
    $url = curl_exec($c);
    curl_close($c);
    return $url;
  }

  /**
   * Sends an e-mail using the PHP mail function.
   * @param string $subject Subject line for the e-mail.
   * @param string $body Message body of the e-mail.
   * @param string $from Sender of the e-mail.  May be formatted either name@example.com or Display Name <name@example.com>.
   * @param string $to Recipient of the e-mail.  May be formatted either name@example.com or Display Name <name@example.com>.  Multiple recipients may be separated by commas.
   * @param string $fromname Display name of the sender.  Should only be used if sender is formatted name@example.com.
   * @param string $toname Display name of the recipient.  Should only be used for single-recipient messages with recipient formatted name@example.com.
   * @param string $cc Carbon copy recipient(s).  Each may be formatted name@example.com or Display Name <name@example.com>.  Multiple carbon copy recipients may be separated by commas.
   * @param string $bcc Blind carbon copy recipient(s).  Each may be formatted name@example.com or Display Name <name@example.com>.  Multiple blind carbon copy recipients may be separated by commas.
   * @param mixed $reply Whether the Reply-To header should be set.  Use true to set sender as reply address or format a different address as either name@example.com or Display Name <name@example.com>.
   * @return boolean Whether an e-mail message was sent.
   */
  public static function EMail($subject, $body, $from, $to, $fromname = false, $toname = false, $cc = false, $bcc = false, $reply = false) {
    // subject may not contain line breaks
    if(strpos($subject, "\r") !== false || strpos($subject, "\n") !== false)
      return false;
    if($fromname)
      $from = $fromname . ' <' . $from . '>';
    // sender may not contain line breaks
    if(strpos($from, "\r") !== false || strpos($from, "\n") !== false)
      return false;
    if($toname)
      $to = $toname . '<' . $to . '>';
    // recipient may not contain line breaks
    if(strpos($to, "\r") !== false || strpos($to, "\n") !== false)
      return false;
    $headers = array('X-Mailer: auSend/0.4.0', 'From: ' . $from);
    if($cc) {
      // cc may not contain line breaks
      if(strpos($cc, "\r") !== false || strpos($cc, "\n") !== false)
        return false;
      $headers[] = 'Cc: ' . $cc;
    }
    if($bcc) {
      // bcc may not contain line breaks
      if(strpos($bcc, "\r") !== false || strpos($bcc, "\n") !== false)
        return false;
      $headers[] = 'Bcc: ' . $bcc;
    }
    if($reply)
      if($reply === true)
        $headers[] = 'Reply-To: ' . $from;
      else {
        // reply-to may not contain line breaks
        if(strpos($reply, "\r") !== false || strpos($reply, "\n") !== false)
          return false;
        $headers[] = 'Reply-To: ' . $reply;
      }
    return @mail($to, $subject, $body, implode("\r\n", $headers));
  }

  /**
   * Sends a message to Twitter to be posted as a tweet.  The following
   * constants must be defined correctly for the Twitter account the message
   * should be posted to:
   * _AU_SEND_TWITTER_OAUTH_CONSUMER_KEY
   * _AU_SEND_TWITTER_OAUTH_CONSUMER_SECRET
   * _AU_SEND_TWITTER_OAUTH_TOKEN
   * _AU_SEND_TWITTER_OAUTH_TOKEN_SECRET
   * @param string $message Message to post to Twitter as a tweet.
   * @return object Response from Twitter with code and text fields.
   */
  public static function Tweet($message) {
    // these must be in alphabetical order
    $params = 'oauth_consumer_key=' . _AU_SEND_TWITTER_OAUTH_CONSUMER_KEY
      . '&oauth_nonce=' . md5(microtime() . mt_rand())
      . '&oauth_signature_method=HMAC-SHA1'
    	. '&oauth_timestamp=' . time()
    	. '&oauth_token=' . _AU_SEND_TWITTER_OAUTH_TOKEN
    	. '&oauth_version=1.0'
    	. '&status=' . rawurlencode($message);
    // sign the request
    $sig = 'POST&' . rawurlencode(_AU_SEND_TWEET_URL) . '&' . rawurlencode($params);
    $params .= '&oauth_signature=' . rawurlencode(base64_encode(hash_hmac('sha1', $sig, _AU_SEND_TWITTER_OAUTH_CONSUMER_SECRET . '&' . _AU_SEND_TWITTER_OAUTH_TOKEN_SECRET, true)));
    // send the request
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, _AU_SEND_TWEET_URL);
    curl_setopt($c, CURLOPT_POST, true);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_USERAGENT, 'auSend');
    curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($c, CURLOPT_TIMEOUT, 30);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_HEADER, false);
    curl_setopt($c, CURLOPT_POSTFIELDS, $params);
    $response->text = curl_exec($c);
    $response->code = curl_getinfo($c, CURLINFO_HTTP_CODE);
    curl_close($c);
    return $response;
  }
}
?>
