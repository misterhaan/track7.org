<?
// History:
// 0.2.0 - Initial release
// 0.3.0 - Fix auDBResult constructor for non-select queries
// 0.3.0 - Add phpDoc

require_once 'auDB.base.php';

  /**
   * Database class for MySQL using PHP's mysqli procedures.
   *
   * Create an auDB object using new auDB(), then run queries against it with
   * Get(), GetRecord(), GetValue(), GetLimit(), GetSplit(), Put(), and
   * Change().  NumQueries() will tell you how many queries have been run since
   * the object was created.
   * @package auLib
   * @subpackage auDB
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auDB
   */
  class auDB extends auDBBase {
    /**
     * @var resource mysqli connection resource
     */
    private $mysqli;

    /**
     * Creates a new database object.
     *
     * @param string $user Username for database account.
     * @param string $pass Password for database account.
     * @param string $host Name of server hosting the database (often 'localhost' works).
     * @param string $name Name of database to work with.
     * @param object $report Object with Error($, $) and Info($) methods for displaying error and information messages.  Defaults to built-in object which simply writes HTML messages.
     * @return auDB
     */
    public function auDB($user, $pass, $host, $name, &$report = null) {
      $this->mysqli = mysqli_connect($host, $user, $pass, $name);
      parent::auDBBase($user, $pass, $host, $name, $report);
    }
    
    /**
     * Runs an SQL SELECT query against the database and gets back a limited
     * number of records in the results.
     *
     * @param string $query SQL SELECT query to run.
     * @param integer $skip Number of result records to skip.
     * @param integer $show Number of result records to show.
     * @param string $errormsg Error message to report if the query results in an error.  Default is to return the results without checking for errors.
     * @param string $emptymsg Message to report if the query does not return any results.  Default is to return the results without checking to see if there are any results.
     * @param bool $emptyerror Whether empty results should be reported as an error.  Default is to report empty results as information.
     * @return auDBResult|bool The results as an auDBResult object, or false.
     */
    public function GetLimit($query, $skip, $show, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      return $this->Get($query . ' limit ' . $skip . ', ' . $show, $errormsg, $emptymsg, $emptyerror);
    }

    /**
     * Runs an SQL INSERT or REPLACE query against the database.
     *
     * @param string $query SQL INSERT/REPLACE query to run.
     * @param string $errormsg Error message to report if the query results in an error.  Default is to return the results without checking for errors.
     * @return unknown The ID of the inserted record, or false on failure.
     */
    public function Put($query, $errormsg = null) {
      if(parent::Put($query, $errormsg))
        return mysqli_insert_id($this->mysqli);
      return false;
    }

    /**
     * Performs a query against the database and returns an auDBResult object.
     *
     * @param string $sql SQL query to run.
     * @return auDBResult
     */
    protected function Query($sql) {
      $this->queries++;
      return new auDBResult($sql, $this->mysqli);
    }
  }

  /**
   * Provides access to results of an SQL query.  This class is instantiated and
   * returned by methods in the auDB class.
   *
   * @package auLib
   * @subpackage auDB
   * @author misterhaan
   * @copyright © 2008 track7.org
   */
  class auDBResult extends auDBResultBase {

    /**
     * Runs an SQL query against the database and provides access to the results.
     *
     * @param string $query SQL query to run.
     * @param object $mysqli MySQLi connection object used to run the query.
     * @return auDBResult
     */
    public function auDBResult($query, &$mysqli) {
      if(mysqli_real_query($mysqli, $query) && mysqli_errno($mysqli) == 0) {
        $this->result = mysqli_store_result($mysqli);
        $this->error = false;
        $this->message = '';
        if(strtolower(substr(trim($query), 0, 6)) == 'select')
          $this->affected = mysqli_num_rows($this->result);
        else
          $this->affected = mysqli_affected_rows($mysqli);
      } else {
        $this->error = true;
        $this->message = htmlspecialchars(mysqli_errno($mysqli) . ' ' . mysqli_error($mysqli));
        $this->affected = 0;
      }
    }

    /**
     * Returns the next record returned by the query.
     *
     * @param bool $object Set to false to return the record as an array.
     * @return object|array|bool The next record returned by the query, or false if no more records.
     */
    public function NextRecord($object = true) {
      if(!$object)
        return mysqli_fetch_row($this->result);
      return mysqli_fetch_object($this->result);
    }
  }
?>
