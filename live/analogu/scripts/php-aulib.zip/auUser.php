<?
// History:
// 0.0.0 - Initial release
// 0.3.0 - Add phpDoc
// 0.3.0 - Add $this->homepage for going to a specific page after login
// 0.4.0 - Don't send a location header for ajax logins ($_POST['return'] == 'xml')
// 0.4.0 - Use SHA512 instead of SHA1 for passwords.  !!!IMPORTANT:  databases now need 96 characters for password fields instead of 48

  if(!defined('_AU_USER_SESS_TIMEOUT'))
    define('_AU_USER_SESS_TIMEOUT', 3600);  // session timeout - 1 hour
  if(!defined('_AU_USER_COOKIE_LIFE'))
    define('_AU_USER_COOKIE_LIFE', 2592000);  // login cookie lifetime - 30 days
  if(!defined('_AU_USER_COOKIE_NAME'))
    define('_AU_USER_COOKIE_NAME', 'autologin');  // login cookie name

  if(!defined('_HOST')) {  // used as the domain for cookies (put a '.' in front) and e-mail
    list($host) = explode(':', strtolower($_SERVER['HTTP_HOST']), 2);  // put domain in lowercase, and strip off port number if there is one
    $host = preg_replace('/^(web|www[0-9]*|secure)\./', '', $host);  // remove the www. if there is one, so that the same cookie will work for both with and without the www
    define('_HOST', $host);
    unset($host);
  }

  define('_AU_USER_LOGIN_REGISTER', 'User information read from registration form');
  define('_AU_USER_LOGIN_FORM', 'User information read from login form');
  define('_AU_USER_LOGIN_SESSION', 'User information read from session');
  define('_AU_USER_LOGIN_COOKIE', 'User information read from cookie');
  define('_AU_USER_LOGIN_NONE', 'User information not found');
  define('_AU_USER_LOGIN_WRONGIP', 'Cannot continue session from different IP than the one that started it');
  define('_AU_USER_LOGIN_TIMEOUT', 'Session timed out');
  define('_AU_USER_LOGIN_DBERROR', 'Error looking up user');
  define('_AU_USER_LOGIN_WRONGPASSWORD', 'Incorrect username or password');
  define('_AU_USER_LOGIN_BADPASSWORD', 'Password missing or corrupt');

  /**
   * User class provides common functions for users.  This class needs to be
   * extended in order to work with a site's specific users table(s).
   *
   * auUser implements some functions that are most likely useful to any site's
   * user system.  Since different sites will usually have different needs for
   * their user systems, this class does not implement any specifics and should
   * be extended by each site in order to do so.
   * @package auLib
   * @author misterhaan
   * @copyright © 2008 - 2011 track7.org
   * @tutorial http://wiki.track7.org/auUser
   */
  class auUser {
    /**
     * @var auDB Database connection.
     */
    protected $db;

    /**
     * @var string Page to load after login.
     */
    protected $homepage;

    /**
     * @var bool True if the object represents a valid user.
     */
    public $Valid = false;
    /**
     * @var string Results of trying to log in.
     */
    public $LoginMessage;
    /**
     * @var string Logged-in users's ID, if user is valid.
     */
    public $ID;
    /**
     * @var string Logged-in users's display name, if user is valid.
     */
    public $Name;

    /**
     * Creates a new user object.
     *
     * @param auDB $db Database connection for looking up user information.
     * @return auUser
     */
    public function auUser(&$db) {
      $this->db = $db;
      $this->LoginMessage = _AU_USER_LOGIN_NONE;
      // check for logout
      if(isset($_GET['userlogout'])) {
        $this->LoginMessage = _AU_USER_LOGIN_LOGGEDOUT;
        @session_unset();
        @session_destroy();
        setcookie(_AU_USER_COOKIE_NAME, '', time() - 60, '/', '.' . _HOST);
        if($_GET['userlogout'])
          header('Location: http' . (strtolower($_SERVER['HTTPS']) == 'on' ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_GET['userlogout']);
        else
          header('Location: http' . (strtolower($_SERVER['HTTPS']) == 'on' ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . str_replace('userlogout', '', $_SERVER['REQUEST_URI']));
        die;
      }
      // check for registration form
      if($_POST['formid'] == 'userregister') {
        if($this->ProcessRegistrationForm())
          return;
      }
      // check for login form
      if($_POST['formid'] == 'userlogin') {
        $this->homepage = $_SERVER['REQUEST_URI'];
        if($this->GetUserInfo(trim($_POST['login']), true, trim($_POST['password']))) {
          $this->LoginMessage = _AU_USER_LOGIN_FORM;
          // if not ajax request, redirect to the homepage now that the session has been set, to avoid warnings about the page containing post data.
          if(!isset($_POST['return']) || $_POST['return'] != 'xml') {
            header('Location: http' . (strtolower($_SERVER['HTTPS']) == 'on' ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $this->homepage);
            die;
          }
        }
      }
      // check for session data
      if(isset($_SESSION['uid'])) {
        if($_SESSION['ip'] != $_SERVER['REMOTE_ADDR'])
          $this->LoginMessage = _AU_USER_LOGIN_WRONGIP;
        elseif(time() - $_SESSION['time'] > _AU_USER_SESS_TIMEOUT)
          $this->LoginMessage = _AU_USER_LOGIN_TIMEOUT;
        elseif($this->GetUserInfo($_SESSION['uid'])) {
          $this->LoginMessage = _AU_USER_LOGIN_SESSION;
          return;
        }
        // there was a problem with the session, so get rid of it
        @session_unset();
        @session_destroy();
      }
      // check for cookie data
      if(isset($_COOKIE[_AU_USER_COOKIE_NAME])) {
        list($id, $passhash) = explode('|', $_COOKIE[_AU_USER_COOKIE_NAME], 2);
        if($this->GetUserInfo($id, true, $passhash, true)) {
          $this->LoginMessage = _AU_USER_LOGIN_COOKIE;
          return;
        }
        // there was a problem with the cookie, so get rid of it
        setcookie(_AU_USER_COOKIE_NAME, '', time() - 86400, '/', '.' . _HOST);
      }
      $this->GetGuestInfo();
    }

    /**
     * Attempts to process the user registration form (must be overridden to use
     * site-specific user data).
     *
     * @return bool True if user was successfully registered and logged in.
     */
    protected function ProcessRegistrationForm() {
      return $this->GetUserInfo(1);
    }

    /**
     * Gets user information from the database (must be overridden to get
     * site-specific user data).  Set $this->homepage to a URL to load after
     * successful login if desired -- will be added to http://www.example.com so
     * must start with a forward slash.
     *
     * @param string $id Look up information for user with this ID.
     * @param bool $login Set this to true if the user is logging in.
     * @param string $password If present, this password is checked against the user's password stored in the database.
     * @param bool $hashed Set this to true if $password is set to the hashed version of the user's password.
     * @return bool True if user information was retrieved.
     */
    protected function GetUserInfo($id, $login = false, $password = false, $hashed = false) {
      $this->ID = $id;
      $this->Valid = true;
      $this->Name = 'User';
      $_SESSION['uid'] = $id;
      $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
      $_SESSION['time'] = time();
      return true;
    }

    /**
     * Gets user information for a guest user (should be overridden to get
     * site-specific user data).
     */
    protected function GetGuestInfo() {
      $this->ID = 0;
      $this->Valid = false;
      $this->Name = 'Guest';
    }

    /**
     * Encrypts a plain-text password for storing in a cookie or the database.
     *
     * @param string $password Plain-text password to encrypt.
     * @return string Encrypted password.
     */
    public function EncryptPassword($password) {
      for($salt = ''; strlen($salt) < 6; $salt .= chr(mt_rand(0, 255)));
      $salt = base64_encode($salt);
      return $salt . base64_encode(hash('sha512', $password . $salt, true));
    }

    /**
     * Checks a plain-text password against an encrypted password.
     *
     * @param string $password Plain-text password.
     * @param string $hash Encrypted password.
     * @return bool True if passwords match.
     */
    public function CheckPassword($password, $hash) {
      $len = strlen($hash);
      if($len == 96)  // currently auUser uses base64 SHA512 with 8-character base64 salt for 96 characters total
        return $this->CheckPasswordSha512($password, $hash);
      if($len == 48)  // until version 0.4.0, auUser used hexadecimal SHA1 with 8-character hexadecimal salt for 48 characters total
        return $this->CheckPasswordSha1($password, $hash);
      if($len == 32)  // this should not happen except for old track7 users, since auUser never used MD5
        return $this->CheckPasswordMd5($password, $hash);
      $this->LoginMessage = _AU_USER_LOGIN_BADPASSWORD;
      return false;
    }

    /**
     * Checks a plain-text password against a password encrypted using SHA512.
     *
     * @param string $password Plain-text password.
     * @param string $hash Encrypted password.
     * @return bool True if passwords match.
     */
    private function CheckPasswordSha512($password, $hash) {
      $saltpass = $password . substr($hash, 0, 8);
      return base64_encode(hash('sha512', $saltpass, true)) == substr($hash, 8);
    }

    /**
     * Checks a plain-text password against a password encrypted using SHA1 and
     * updates the password in the database to use SHA512.
     *
     * @param string $password Plain-text password.
     * @param string $hash Encrypted password.
     * @return bool True if passwords match.
     */
    private function CheckPasswordSha1($password, $hash) {
      $saltpass = $password . substr($hash, 0, 8);
      if(sha1($saltpass) != substr($hash, 8))
        return false;
      $this->UpdatePassword($password);
      return true;
    }

    /**
     * Checks a plain-text password against a password encrypted using MD5 and
     * updates the password in the database to use SHA512.
     *
     * @param string $password Plain-text password.
     * @param string $hash Encrypted password.
     * @return bool True if passwords match.
     */
    private function CheckPasswordMd5($password, $hash) {
      if(md5($pass) != $hash)
        return false;
      $this->UpdatePassword($password);
      return true;
    }

    /**
     * Update the database with the new password format.  This should be
     * overridden by child classes to actually store the hash value in the
     * database.
     * @param string $newpass New password in plain text.
     */
    protected function UpdatePassword($newpass) {
      $hash = $this->EncryptPassword($newpass);
    }
  }
?>