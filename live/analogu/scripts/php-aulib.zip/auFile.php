<?
/******************************************************************************\
 * Title:    File library
 * Purpose:  Provides functions for working with files.
 * History:  0.0.0 - Initial release
 *           0.1.0 - Various fixes in SaveUploadImage
\******************************************************************************/

define('_AU_FILE_UPLOAD_BADTYPE', 'Files of type %TYPE% are not allowed here');
define('_AU_FILE_UPLOAD_TOOBIG', 'Uploaded file is %SIZE%, but the maximum allowed size is %MAX%');
define('_AU_FILE_UPLOAD_ERROR', 'Error trying to save file');
define('_AU_FILE_UPLOAD_NONE', 'No file uploaded');
define('_AU_FILE_UPLOAD_TOOWIDE', 'Uploaded image is %WIDTH% pixels wide, but the maximum allowed width is %MAX% pixels');
define('_AU_FILE_UPLOAD_TOOTALL', 'Uploaded image is %HEIGHT% pixels tall, but the maximum allowed height is %MAX% pixels');
define('_AU_FILE_UPLOAD_CANTREADIMAGE', 'Error reading uploaded image');
define('_AU_FILE_UPLOAD_CANTRESIZE', 'Unable to resize image');

define('_AU_FILE_IMAGE_PNG', 1);
define('_AU_FILE_IMAGE_JPEG', 2);
define('_AU_FILE_IMAGE_GIF', 4);
define('_AU_FILE_IMAGE_ANY', 7);

/*============================================================[ auFile class ]==
  All functions in auFile are static, which means they can only be called in
  the form auFile::Function().
*/
  class auFile {
/*-------------------------------------------------------------[ auFile.Size ]--
  Formats the size of a file in an easy-to-read format.
  $file = Full path to the file.
  @return = File size in easy-to-read format.
*/
    public static function Size($file) {
      if(!file_exists($file))
        return 'File not found';
      return auFile::NiceSize(filesize($file));
    }
    
    private static function NiceSize($size) {
      if($size > 2097152)  // 2097152 = 2^21 = 2 meg
        return round($size / 1048576, 1) . ' megs';
      if($size > 2048)  // 2048 = 2^11 = 2 k
        return round($size / 1024, 1) . ' k';
      return $size . ' bytes';
    }

/*--------------------------------------------------------[ auFile.ImageSize ]--
  Formats the size of an image file in an easy-to-read format.
  $file = Full path to the image file.
  @return = Image file size in easy-to-read format.
*/
    public static function ImageSize($file) {
      if(!file_exists($file))
        return 'Image file not found';
      list($width, $height) = getimagesize($file);
      return $width . ' x ' . $height . ' pixels, ' . auFile::Size($file);
    }

/*-----------------------------------------------------[ auFile.ImageSizeCSS ]--
  Formats the size of an image file into a CSS style attribute.
  $file = Full path to the image file.
  @return = CSS style attribute with image size.
*/
    public static function ImageSizeCSS($file) {
      if(!file_exists($file))
        return '';
      list($width, $height) = getimagesize($file);
      return 'style="width: ' . $width . 'px; height: ' . $height . 'px;" ';
    }

/*---------------------------------------------------------[ auFile.NiceName ]--
  Makes sure a filename is fit for being on a web server.  Specifically, this
  means anything not alphanumeric, underscores, dashes, or periods will be
  removed.
  $name = Filename which may not be fit for a web server.
  @return = Filename which definitely is fit for a web server.
*/
    public static function NiceName($name) {
      return strtolower(preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name));
    }

/*-------------------------------------------------------[ auFile.SaveUpload ]--
  Saves an uploaded file.
  $fieldname = Name of the input field in the HTML form that submitted this
    file.
  $savedir = Directory to save file in.
  $type = MIME types allowed by this upload field.  Default is to allow all
    MIME types.
  $savename = Filename to save file as.  Start with a dot to keep the uploaded
    name but change the extension.  End with a dot to keep the uploaded
    extension.  Filenames are always run through NiceName().  Default is to
    use the uploaded name and extension.
  $maxsize = Maximum size for uploaded file (in bytes).  Default is unlimited.
  @return = True if file was saved, or an error message.
*/
    public static function SaveUpload($fieldname, $savedir, $type = false, $savename = false, $maxsize = 0) {
      if(is_uploaded_file($_FILES[$fieldname]['tmp_name'])) {
        if($type !== false) {
          if(!is_array($type))
            $type = array($type);
          if(in_array('image/jpeg', $type) && !in_array('image/pjpeg', $type))  // IE bug sends mime type with an extra 'p' for jpeg
            $type[] = 'image/pjpeg';
          if(in_array('image/png', $type) && !in_array('image/x-png', $type))  // IE6 sends x-png since it doesn't fully support png or something
            $type[] = 'image/x-png';
          if(!in_array($_FILES[$fieldname]['type'], $type))
            return str_replace('%TYPE%', $_FILES[$fieldname]['type'], _AU_FILE_UPLOAD_BADTYPE);
        }
        if($maxsize > 0 && $_FILES[$fieldname]['size'] > $maxsize)
          return str_replace(array('%SIZE', '%MAX%'), array(auFile::Size($_FILES[$fieldname]['tmp_name']), auFile::NiceSize($maxsize)), _AU_FILE_UPLOAD_TOOBIG);
        if(!$savename)
          $savename = str_replace(' ', '', strtolower($_FILES[$fieldname]['name']));
        elseif(substr($savename, 0, 1) == '.') {
          $name = explode('.', $_FILES[$fieldname]['name']);
          $name[count($name) - 1] = substr($savename, 1);
          $savename = implode('.', $name);
        } elseif(substr($savename, -1) == '.') {
          $name = explode('.', $_FILES[$fieldname]['name']);
          $savename .= $name[count($name) - 1];
        }
        $savename = auFile::NiceName($savename);
        if(!move_uploaded_file($_FILES[$fieldname]['tmp_name'], $savedir . $savename))
          return _AU_FILE_UPLOAD_ERROR;
        return true;
      } else
        return _AU_FILE_UPLOAD_NONE;
    }

/*--------------------------------------------------[ auFile.SaveUploadImage ]--
  Saves an uploaded image file file.
  $fieldname = Name of the input field in the HTML form that submitted this
    file.
  $savedir = Directory to save file in.
  $type = Image types allowed by this upload field (see _AU_FILE_IMAGE_*
    constants).  Default is to allow all image types (PNG, JPEG, and GIF).
  $savename = Filename to save file as.  Extensions are always set according
    to the type of the uploaded file.  Default is to use the uploaded name.
  $maxwidth = Maximum width of the image (in pixels).  Default is unlimited.
  $maxheight = Maximum height of the image (in pixels).  Default is unlimited.
  $scale = If maximum width and/or height are specified and this is true, the
    image will be scaled down so that it fits within the maximum(s).
  $maxsize = Maximum size for uploaded file (in bytes).  Default is unlimited.
  @return = Array with result information:
    ['found'] = True if a file was uploaded.
    ['saved'] = True if image was saved.
    ['message'] = Why the image wasn't saved if it wasn't saved.
    ['size'] = Size of the image if it was saved.
    ['width'] = Width of the image if it was saved.
    ['height'] = Height of the image if it was saved.
    ['path'] = Path image was saved in.
    ['file'] = Filename image was saved as.
*/
    public static function SaveUploadImage($fieldname, $savedir, $type = _AU_FILE_IMAGE_ANY, $savename = false, $maxwidth = 0, $maxheight = 0, $scale = false, $maxsize = 0) {
      $result['saved'] = false;
      if(!($result['found'] = is_uploaded_file($_FILES[$fieldname]['tmp_name']))) {
        $result['message'] = _AU_FILE_UPLOAD_NONE;
        return $result;
      }
      if(!is_numeric($type))
        $type = _AU_FILE_IMAGE_ANY;
      switch($_FILES[$fieldname]['type']) {
        case 'image/jpeg':
        case 'image/pjpeg':  // IE bug sends mime type with an extra 'p' for jpeg
          $oktype = _AU_FILE_IMAGE_JPEG & $type;
          break;
        case 'image/png':
        case 'image/x-png':  // IE is old and sends x-png instead of png
          $oktype = _AU_FILE_IMAGE_PNG & $type;
          break;
        case 'image/gif':
          $oktype = _AU_FILE_IMAGE_GIF & $type;
          break;
        default:
          $oktype = false;
          break;
      }
      if(!$oktype) {
        $result['message'] = str_replace('%TYPE%', $_FILES[$fieldname]['type'], _AU_FILE_UPLOAD_BADTYPE);
        return $result;
      }
      if($maxsize > 0 && ($result['size'] = $_FILES[$fieldname]['size']) > $maxsize) {
        $result['message'] = str_replace(array('%SIZE', '%MAX%'), array(auFile::Size($_FILES[$fieldname]['tmp_name']), auFile::NiceSize($maxsize)), _AU_FILE_UPLOAD_TOOBIG);
        return $result;
      }
      $img = getimagesize($_FILES[$fieldname]['tmp_name']);
      $result['width'] = $img[0];
      $result['height'] = $img[1];
      if($maxwidth > 0 && $result['width'] > $maxwidth)
        if(!$scale) {
          $result['message'] = str_replace(array('%WIDTH%', '%MAX%'), array($result['width'], $maxwidth), _AU_FILE_UPLOAD_TOOWIDE);
          return $result;
        } else {
          $result['height'] = round($result['height'] * $maxwidth / $result['width']);
          $result['width'] = $maxwidth;
        }
      if($maxheight > 0 && $result['height'] > $maxheight)
        if(!$scale) {
          $result['message'] = str_replace(array('%HEIGHT%', '%MAX%'), array($result['height'], $maxheight), _AU_FILE_UPLOAD_TOOTALL);
          return $result;
        } else {
          $result['width'] = round($result['width'] * $maxheight / $result['height']);
          $result['height'] = $maxheight;
        }
      $scale &= !($result['width'] == $img[0] && $result['height'] == $img[1]);
      switch($img[2]) {
        case 1:  // gif
          if(_AU_FILE_IMAGE_GIF & $type == 0) {
            $result['message'] = str_replace('%TYPE%', 'GIF', _AU_FILE_UPLOAD_BADTYPE);
            return $result;
          }
          $type = _AU_FILE_IMAGE_GIF;
          if($scale)
            $upload = @imagecreatefromgif($_FILES[$fieldname]['tmp_name']);
          break;
        case 2:  // jpg
          if(_AU_FILE_IMAGE_JPEG & $type == 0) {
            $result['message'] = str_replace('%TYPE%', 'JPEG', _AU_FILE_UPLOAD_BADTYPE);
            return $result;
          }
          $type = _AU_FILE_IMAGE_JPEG;
          if($scale)
            $upload = @imagecreatefromjpeg($_FILES[$fieldname]['tmp_name']);
          break;
        case 3:  // png
          if(_AU_FILE_IMAGE_PNG & $type == 0) {
            $result['message'] = str_replace('%TYPE%', 'PNG', _AU_FILE_UPLOAD_BADTYPE);
            return $result;
          }
          if($scale)
            $upload = @imagecreatefrompng($_FILES[$fieldname]['tmp_name']);
          break;
        default:
          $result['message'] = str_replace('%TYPE%', 'unknown', _AU_FILE_UPLOAD_BADTYPE);
          return $result;
          break;
      }
      if(!$savename)
        $savename = str_replace(' ', '', strtolower($_FILES[$fieldname]['name']));
      $savename = explode('.', $savename);
      $savename[count($savename) - 1] = $type == _AU_FILE_IMAGE_PNG ? 'png' : ($type == _AU_FILE_IMAGE_JPEG ? 'jpg' : ($type == _AU_FILE_IMAGE_GIF ? 'gif' : $savename[count($savename) - 1]));
      $savename = auFile::NiceName(implode('.', $savename));
      $result['path'] = $savedir;
      $result['file'] = $savename;
      if(file_exists($savedir . $savename))
        @unlink($savedir . $savename);
      if($scale) {
        if(!$upload) {
          $result['message'] = _AU_FILE_UPLOAD_CANTREADIMAGE;
          return $result;
        }
        $image = imagecreatetruecolor($result['width'], $result['height']);
        if(!imagecopyresampled($image, $upload, 0, 0, 0, 0, $result['width'], $result['height'], $img[0], $img[1])) {
          $result['message'] = _AU_FILE_UPLOAD_CANTRESIZE;
          return $result;
        }
        if($type == _AU_FILE_IMAGE_PNG)
          $result['saved'] = @imagepng($image, $savedir . $savename);
        elseif($type == _AU_FILE_IMAGE_JPEG)
          $result['saved'] = @imagejpeg($image, $savedir . $savename);
        elseif($type == _AU_FILE_IMAGE_GIF)
          $result['saved'] = @imagegif($image, $savedir . $savename);
        @unlink($_FILES[$fieldname]['tmp_name']);
        if(!$result['saved'])
          $result['message'] = _AU_FILE_UPLOAD_ERROR;
        return $result;
      }
      if(!($result['saved'] = move_uploaded_file($_FILES[$fieldname]['tmp_name'], $savedir . $savename)))
        $result['message'] = _AU_FILE_UPLOAD_ERROR;
      return $result;
    }
  }
?>
