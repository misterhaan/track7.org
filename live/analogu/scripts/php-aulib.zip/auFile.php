<?
// History:
// 0.0.0 - Initial release
// 0.1.0 - Various fixes in SaveUploadImage
// 0.3.0 - Add phpDoc
// 0.3.0 - Check file uploads for errors
// 0.4.0 - Set extension correctly for PNG uploads
// 0.4.0 - Save GIF as PNG
// 0.4.0 - Support transparent backgrounds on resize

define('_AU_FILE_UPLOAD_BADTYPE', 'Files of type %TYPE% are not allowed here');
define('_AU_FILE_UPLOAD_TOOBIG', 'Uploaded file is %SIZE%, but the maximum allowed size is %MAX%');
define('_AU_FILE_UPLOAD_ERROR', 'Error trying to save file');
define('_AU_FILE_UPLOAD_NONE', 'No file uploaded');
define('_AU_FILE_UPLOAD_TOOWIDE', 'Uploaded image is %WIDTH% pixels wide, but the maximum allowed width is %MAX% pixels');
define('_AU_FILE_UPLOAD_TOOTALL', 'Uploaded image is %HEIGHT% pixels tall, but the maximum allowed height is %MAX% pixels');
define('_AU_FILE_UPLOAD_CANTREADIMAGE', 'Error reading uploaded image');
define('_AU_FILE_UPLOAD_CANTRESIZE', 'Unable to resize image');

define('_AU_FILE_IMAGE_PNG', 1);
define('_AU_FILE_IMAGE_JPEG', 2);
define('_AU_FILE_IMAGE_GIF', 4);
define('_AU_FILE_IMAGE_ANY', 7);

  /**
   * Provides functions for working with files.
   *
   * All functions in auFile are static, which means they can only be called in
   * the form auFile::Function().
   * @package auLib
   * @author misterhaan
   * @copyright © 2008 - 2011 track7.org
   * @tutorial http://wiki.track7.org/auFile
   */
  class auFile {
    /**
     * Formats the size of a file in an easy-to-read format.
     *
     * @param string $file Full path to the file.
     * @return string File size in easy-to-read format.
     */
    public static function Size($file) {
      if(!file_exists($file))
        return 'File not found';
      return auFile::NiceSize(filesize($file));
    }

    /**
     * Formats a number into the most reasonable unit of megs, k, or bytes.
     *
     * @param integer $size Size in bytes.
     * @return string Formatted size in megs, k, or bytes.
     */
    private static function NiceSize($size) {
      if($size > 2097152)  // 2097152 = 2^21 = 2 meg
        return round($size / 1048576, 1) . ' megs';
      if($size > 2048)  // 2048 = 2^11 = 2 k
        return round($size / 1024, 1) . ' k';
      return $size . ' bytes';
    }

    /**
     * Formats the size of an image file in an easy-to-read format.
     *
     * @param string $file Full path to the image file.
     * @return string Image file size in easy-to-read format.
     */
    public static function ImageSize($file) {
      if(!file_exists($file))
        return 'Image file not found';
      list($width, $height) = getimagesize($file);
      return $width . ' x ' . $height . ' pixels, ' . auFile::Size($file);
    }

    /**
     * Formats the size of an image file into a CSS style attribute.
     *
     * @param string $file Full path to the image file.
     * @return string CSS style attribute with image size.
     */
    public static function ImageSizeCSS($file) {
      if(!file_exists($file))
        return '';
      list($width, $height) = getimagesize($file);
      return 'style="width: ' . $width . 'px; height: ' . $height . 'px;" ';
    }

    /**
     * Makes sure a filename is fit for being on a web server.  Specifically,
     * this means anything not alphanumeric, underscores, dashes, or periods
     * will be removed.
     *
     * @param string $name Filename which may not be fit for a web server.
     * @return string Filename which definitely is fit for a web server.
     */
    public static function NiceName($name) {
      return strtolower(preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name));
    }

    /**
     * Saves an uploaded file.
     *
     * @param string $fieldname Name of the input field in the HTML form that submitted this file.
     * @param string $savedir Directory to save file in.
     * @param string|array $type MIME types allowed by this upload field.  Default is to allow all MIME types.
     * @param string $savename Filename to save file as.  Start with a dot to keep the uploaded name but change the extension.  End with a dot to keep the uploaded extension.  Filenames are always run through NiceName().  Default is to use the uploaded name and extension.
     * @param integer $maxsize Maximum size for uploaded file (in bytes).  Default is unlimited.
     * @return bool|string True if file was saved, or an error message.
     */
    public static function SaveUpload($fieldname, $savedir, $type = false, $savename = false, $maxsize = 0) {
      if(is_uploaded_file($_FILES[$fieldname]['tmp_name'])) {
        if($type !== false) {
          if(!is_array($type))
            $type = array($type);
          if(in_array('image/jpeg', $type) && !in_array('image/pjpeg', $type))  // IE bug sends mime type with an extra 'p' for jpeg
            $type[] = 'image/pjpeg';
          if(in_array('image/png', $type) && !in_array('image/x-png', $type))  // IE6 sends x-png since it doesn't fully support png or something
            $type[] = 'image/x-png';
          if(!in_array($_FILES[$fieldname]['type'], $type))
            return str_replace('%TYPE%', $_FILES[$fieldname]['type'], _AU_FILE_UPLOAD_BADTYPE);
        }
        if($maxsize > 0 && $_FILES[$fieldname]['size'] > $maxsize)
          return str_replace(array('%SIZE', '%MAX%'), array(auFile::Size($_FILES[$fieldname]['tmp_name']), auFile::NiceSize($maxsize)), _AU_FILE_UPLOAD_TOOBIG);
        if(!$savename)
          $savename = str_replace(' ', '', strtolower($_FILES[$fieldname]['name']));
        elseif(substr($savename, 0, 1) == '.') {
          $name = explode('.', $_FILES[$fieldname]['name']);
          $name[count($name) - 1] = substr($savename, 1);
          $savename = implode('.', $name);
        } elseif(substr($savename, -1) == '.') {
          $name = explode('.', $_FILES[$fieldname]['name']);
          $savename .= $name[count($name) - 1];
        }
        $savename = auFile::NiceName($savename);
        if(!move_uploaded_file($_FILES[$fieldname]['tmp_name'], $savedir . $savename))
          return _AU_FILE_UPLOAD_ERROR;
        return true;
      } else
        return _AU_FILE_UPLOAD_NONE;
    }

    /**
     * Saves an uploaded image file.
     *
     * @param string $fieldname Name of the input field in the HTML form that submitted this file.
     * @param string $savedir Directory to save file in.
     * @param integer|array $type Image types allowed by this upload field (see _AU_FILE_IMAGE_* constants).  Default is to allow all image types (PNG, JPEG, and GIF).
     * @param string $savename Filename to save file as.  Extensions are always set according to the type of the uploaded file.  Default is to use the uploaded name.
     * @param integer $maxwidth Maximum width of the image (in pixels).  Default is unlimited.
     * @param integer $maxheight Maximum height of the image (in pixels).  Default is unlimited.
     * @param bool $scale If maximum width and/or height are specified and this is true, the image will be scaled down so that it fits within the maximum(s).
     * @param integer $maxsize Maximum size for uploaded file (in bytes).  Default is unlimited.
     * @param bool $savegifaspng If true, GIF uploads will be converted to PNG.
     * @param bool $keepaspect If false, uploaded image will be resized to exactly the maximum width and height specified.
     * @return array Array with result information:
     * ['found'] = True if a file was uploaded.
     * ['saved'] = True if image was saved.
     * ['message'] = Why the image wasn't saved if it wasn't saved.
     * ['size'] = Size of the image if it was saved.
     * ['width'] = Width of the image if it was saved.
     * ['height'] = Height of the image if it was saved.
     * ['path'] = Path image was saved in.
     * ['file'] = Filename image was saved as.
     */
    public static function SaveUploadImage($fieldname, $savedir, $type = _AU_FILE_IMAGE_ANY, $savename = false, $maxwidth = 0, $maxheight = 0, $scale = false, $maxsize = 0, $savegifaspng = false, $keepaspect = true) {
      $result['saved'] = false;
      if(!($result['found'] = is_uploaded_file($_FILES[$fieldname]['tmp_name']))) {
        $result['message'] = auFile::GetUploadErrorMessage($fieldname);
        return $result;
      }
      if(!is_numeric($type))
        $type = _AU_FILE_IMAGE_ANY;
      switch($_FILES[$fieldname]['type']) {
        case 'image/jpeg':
        case 'image/pjpeg':  // IE bug sends mime type with an extra 'p' for jpeg
          $oktype = _AU_FILE_IMAGE_JPEG & $type;
          break;
        case 'image/png':
        case 'image/x-png':  // IE is old and sends x-png instead of png
          $oktype = _AU_FILE_IMAGE_PNG & $type;
          break;
        case 'image/gif':
          $oktype = _AU_FILE_IMAGE_GIF & $type;
          break;
        default:
          $oktype = false;
          break;
      }
      if(!$oktype) {
        $result['message'] = str_replace('%TYPE%', $_FILES[$fieldname]['type'], _AU_FILE_UPLOAD_BADTYPE);
        return $result;
      }
      if($maxsize > 0 && ($result['size'] = $_FILES[$fieldname]['size']) > $maxsize) {
        $result['message'] = str_replace(array('%SIZE', '%MAX%'), array(auFile::Size($_FILES[$fieldname]['tmp_name']), auFile::NiceSize($maxsize)), _AU_FILE_UPLOAD_TOOBIG);
        return $result;
      }
      $img = getimagesize($_FILES[$fieldname]['tmp_name']);
      $result['width'] = $img[0];
      $result['height'] = $img[1];
      if($maxwidth > 0 && $maxheight > 0 && !$keepaspect) {
        $result['height'] = $maxheight;
        $result['width'] = $maxwidth;
        $scale = true;  // scale controls whether a resize is done
      } else {
        if($maxwidth > 0 && $result['width'] > $maxwidth)
          if(!$scale) {
            $result['message'] = str_replace(array('%WIDTH%', '%MAX%'), array($result['width'], $maxwidth), _AU_FILE_UPLOAD_TOOWIDE);
            return $result;
          } else {
            $result['height'] = round($result['height'] * $maxwidth / $result['width']);
            $result['width'] = $maxwidth;
          }
        if($maxheight > 0 && $result['height'] > $maxheight)
          if(!$scale) {
            $result['message'] = str_replace(array('%HEIGHT%', '%MAX%'), array($result['height'], $maxheight), _AU_FILE_UPLOAD_TOOTALL);
            return $result;
          } else {
            $result['width'] = round($result['width'] * $maxheight / $result['height']);
            $result['height'] = $maxheight;
          }
      }
      $scale &= !($result['width'] == $img[0] && $result['height'] == $img[1]);
      switch($img[2]) {
        case 1:  // gif
          if(_AU_FILE_IMAGE_GIF & $type == 0) {
            $result['message'] = str_replace('%TYPE%', 'GIF', _AU_FILE_UPLOAD_BADTYPE);
            return $result;
          }
          $type = _AU_FILE_IMAGE_GIF;
          if($savegifaspng) {
            $type = _AU_FILE_IMAGE_PNG;
            $scale = true;  // scale makes a new file, which lets us save as png
          }
          if($scale)
            $upload = @imagecreatefromgif($_FILES[$fieldname]['tmp_name']);
          break;
        case 2:  // jpg
          if(_AU_FILE_IMAGE_JPEG & $type == 0) {
            $result['message'] = str_replace('%TYPE%', 'JPEG', _AU_FILE_UPLOAD_BADTYPE);
            return $result;
          }
          $type = _AU_FILE_IMAGE_JPEG;
          if($scale)
            $upload = @imagecreatefromjpeg($_FILES[$fieldname]['tmp_name']);
          break;
        case 3:  // png
          if(_AU_FILE_IMAGE_PNG & $type == 0) {
            $result['message'] = str_replace('%TYPE%', 'PNG', _AU_FILE_UPLOAD_BADTYPE);
            return $result;
          }
          $type = _AU_FILE_IMAGE_PNG;
          if($scale)
            $upload = @imagecreatefrompng($_FILES[$fieldname]['tmp_name']);
          break;
        default:
          $result['message'] = str_replace('%TYPE%', 'unknown', _AU_FILE_UPLOAD_BADTYPE);
          return $result;
          break;
      }
      if(!$savename)
        $savename = str_replace(' ', '', strtolower($_FILES[$fieldname]['name']));
      $savename = explode('.', $savename);
      $savename[count($savename) - 1] = $type == _AU_FILE_IMAGE_PNG ? 'png' : ($type == _AU_FILE_IMAGE_JPEG ? 'jpg' : ($type == _AU_FILE_IMAGE_GIF ? 'gif' : $savename[count($savename) - 1]));
      $savename = auFile::NiceName(implode('.', $savename));
      $result['path'] = $savedir;
      $result['file'] = $savename;
      if(file_exists($savedir . $savename))
        @unlink($savedir . $savename);
      if($scale) {
        if(!$upload) {
          $result['message'] = _AU_FILE_UPLOAD_CANTREADIMAGE;
          return $result;
        }
        $image = imagecreatetruecolor($result['width'], $result['height']);
        if($type != _AU_FILE_IMAGE_JPEG) {  // gif and png can be transparent
          imagealphablending($image, false);
          imagefill($image, 0, 0, imagecolorallocatealpha($image, 0, 0, 0, 127));
          imagesavealpha($image, true);
        }
        if(!imagecopyresampled($image, $upload, 0, 0, 0, 0, $result['width'], $result['height'], $img[0], $img[1])) {
          $result['message'] = _AU_FILE_UPLOAD_CANTRESIZE;
          return $result;
        }
        if($type == _AU_FILE_IMAGE_PNG)
          $result['saved'] = @imagepng($image, $savedir . $savename);
        elseif($type == _AU_FILE_IMAGE_JPEG)
          $result['saved'] = @imagejpeg($image, $savedir . $savename);
        elseif($type == _AU_FILE_IMAGE_GIF)
          $result['saved'] = @imagegif($image, $savedir . $savename);
        @unlink($_FILES[$fieldname]['tmp_name']);
        if(!$result['saved'])
          $result['message'] = _AU_FILE_UPLOAD_ERROR;
        return $result;
      }
      if(!($result['saved'] = move_uploaded_file($_FILES[$fieldname]['tmp_name'], $savedir . $savename)))
        $result['message'] = _AU_FILE_UPLOAD_ERROR;
      return $result;
    }

    /**
     * Looks up the appropriate error message based on the file upload error
     * code for the field.
     *
     * @param $fieldname Name of the file field from the HTML form
     * @return string Message for the type of upload error that occurred
     */
    private function GetUploadErrorMessage($fieldname) {
      switch($_FILES[$fieldname]['error']) {
        case UPLOAD_ERR_OK:
          return 'File uploaded successfully.';
          break;
        case UPLOAD_ERR_INI_SIZE:
          return 'File could not be uploaded because it is larger than the upload_max_filesize of ' . ini_get('upload_max_filesize');
          break;
        case UPLOAD_ERR_FORM_SIZE:
          return 'File could not be uploaded because it is larger than the MAX_FILE_SIZE of ' . $_POST['MAX_FILE_SIZE'];
          break;
        case UPLOAD_ERR_PARTIAL:
          return 'File was only partially uploaded.';
          break;
        case UPLOAD_ERR_NO_FILE:
          return _AU_FILE_UPLOAD_NONE;
          break;
        case UPLOAD_ERR_NO_TMP_DIR:
          return 'Files cannot be uploaded because there is no temporary folder.';
          break;
        case UPLOAD_ERR_CANT_WRITE:
          return 'Failed to write uploaded file to disk.';
          break;
        case UPLOAD_ERR_EXTENSION:
          return 'File upload stopped by extension.';
          break;
        default:
          return 'File upload failed for unknown reason';
          break;
      }
    }
  }
?>
