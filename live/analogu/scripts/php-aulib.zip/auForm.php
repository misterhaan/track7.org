<?
// History:
// 0.0.0 - Initial release
// 0.1.0 - Various typo fixes
// 0.3.0 - Support array field names
// 0.3.0 - Add defaultonly option to forms
// 0.3.0 - Add GetErrors function
// 0.3.0 - Add phpDoc
// 0.3.0 - Support Add() for any type of element
// 0.4.0 - Add contents parameter to auFormFieldset

  // options for AddField $type
  define('_AU_FORM_FIELD_NORMAL', 0);
  define('_AU_FORM_FIELD_NUMERIC', 1);
  define('_AU_FORM_FIELD_INTEGER', 2);
  define('_AU_FORM_FIELD_DATETIME', 3);
  define('_AU_FORM_FIELD_MULTILINE', 4);
  define('_AU_FORM_FIELD_BBCODE', 5);
  define('_AU_FORM_FIELD_PASSWORD', 6);
  define('_AU_FORM_FIELD_CHECKBOX', 7);
  define('_AU_FORM_FIELD_FILE', 8);

  // options for AddSelect $type
  define('_AU_FORM_SELECT_DROPDOWN', 0);
  define('_AU_FORM_SELECT_RADIO', 1);

  // options for AddMultiSelect $type
  define('_AU_FORM_MULTI_LIST', 0);
  define('_AU_FORM_MULTI_CHECK', 1);

  /**
   * Base class for {@link auForm} and everything that can be added to it.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormElement
   */
  abstract class auFormElement {
    /**
     * @var auForm The form object this element belongs to
     */
    protected $ownerForm;
    /**
     * @var auFormContainer The container that immediately contains this element
     */
    protected $parent;
    /**
     * @var string|bool The error message for this element, or false if no errors have been found
     */
    protected $error;

    /**
     * Checks the element value for errors.
     *
     * @return bool Whether there are errors with this element.
     */
    protected function CheckInput() {
      return true;
    }

    /**
     * Gets the error with the element, if any.
     *
     * @return string|bool Error text, or false.
     */
    protected function GetErrors() {
      return $this->error;
    }

    /**
     * Gets the label of the element, if any.
     *
     * @return string Label of the element.
     */
    protected function GetLabel() {
      return '';
    }

    /**
     * Writes out the HTML for the element.
     */
    protected abstract function WriteHTML();
  }

  /**
   * Base class for {@link auForm} and any other form elements that can contain
   * other form elements.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 - 2010 track7.org
   * @tutorial http://wiki.track7.org/auFormContainer
   */
  abstract class auFormContainer extends auFormElement {
    /**
     * @var array All elements this container contains
     */
    protected $elements;
    /**
     * @var bool Whether this container contains a file field
     */
    protected $hasfile;
    /**
     * @var string The name of the submit button(s) contained within this container
     */
    protected $submit;

    /**
     * Adds an element to this container.
     *
     * @param auFormElement $element Element to add to this container.
     * @return auFormElement Element that was added.
     */
    public function Add(auFormElement &$element) {
      if($element instanceof auForm)
        return false;  // can't add a form element
      $this->elements[] = $element;
      $element->parent = $this;
      if($this instanceof auForm)
        $element->ownerForm = $this;
      else
        $element->ownerForm = $this->ownerForm;
      if($element instanceof auFormFieldSet && is_array($element->elements))
        foreach($element->elements as $e)
          $e->ownerForm = $element->ownerForm;
      if(!$this->hasfile && $element instanceof auFormFile) {
        $this->hasfile = true;
        if(!($this instanceof auForm))
          $this->ownerForm->hasfile = true;
      }
      if($element instanceof auFormButtons && !$this->submit && $element->GetSubmit()) {
        $this->submit = $element->GetSubmit();
        for($e = $this->parent; $e && !$e->submit; $e = $e->parent)
          $e->submit = $this->submit;
      }
      if($element instanceof auFormFieldSet) {
        if(!$this->submit && $element->submit) {
          $this->submit = $element->submit;
          for($e = $this->parent; $e && !$e->submit; $e = $e->parent)
            $e->submit = $element->submit;
        }
        if(!$this->hasfile && $element->hasfile) {
          $this->hasfile = true;
          for($e = $this->parent; $e && !$e->hasfile; $e = $e->parent)
            $e->hasfile = true;
        }
      }
      return $element;
    }

    /**
     * Checks the container's element values for errors.
     *
     * @return bool Whether there are errors with any elements in this container.
     */
    protected function CheckInput() {
      $ret = true;
      for($i = 0; $i < count($this->elements); $i++)
        if(!$this->elements[$i]->CheckInput())
          $ret = false;
      return $ret;
    }
  }

  /**
   * Base class for any form elements that represent fields that both display
   * and send data back to the server.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormField
   */
  abstract class auFormField extends auFormElement {
    /**
     * @var string Name that the field data gets sent to the server under.
     */
    protected $name;
    /**
     * @var string Text to display in the label column to the left of the field.
     */
    protected $label;
    /**
     * @var string Text to pop up when the mouse cursor is over the label text.
     */
    protected $tooltip;

    /**
     * Gets the label of the field, if any.
     *
     * @return string Label of the element.
     */
    protected function GetLabel() {
      return $this->label;
    }
  }


  /**
   * Builds form objects that can be used to output HTML and validate user
   * input.  Also attempts to fool spammers using a couple methods which should
   * be undetectable to actual people.
   *
   * Create a form using new auForm(), then build it using Add(). Check
   * Submitted() to see if the form was submitted, or to find out which submit
   * button was used.  Use CheckInput() to automatically validate fields.  Use
   * WriteHTML() to write out HTML code for the form.  If any errors were found
   * during CheckInput(), they will display above the problematic field.
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 - 2010 track7.org
   * @tutorial http://wiki.track7.org/auForm
   */
  class auForm extends auFormContainer {
    private $id;
    private $action;
    public $method;
    public $defaultonly;

    // variables for display
    public $indent;
    public $intable;
    private $firstfield;

    /**
     * Creates a new form object.
     *
     * @param string $id CSS id of the form element.  Also the value of formid data field.
     * @param string $action Script to send form data to.  Defaults to the current page.
     * @param string $method How to send form data.  Defaults to HTTP POST -- can be overridden to GET.
     * @param bool $defaultonly Whether the fields should only use their default values and not the values present in POST or GET.  Defaults to using POST or GET values if present.
     * @return auForm
     */
    public function auForm($id, $action = null, $method = 'post', $defaultonly = false) {
      $this->id = $id;
      if($action)
        if(substr($action, 0, 1) == '?')
          $this->action = $_SERVER['PHP_SELF'] . $action;
        else
          $this->action = $action;
      else
        $this->action = $_SERVER['PHP_SELF'];
      $this->method = $method;
      $this->defaultonly = $defaultonly;
      $this->hasfile = false;
      if($this->id)
        $this->Add(new auFormData('formid', $id));
      $this->error = false;
    }

    /**
     * Adds a fieldset to the form.
     *
     * @param auFormFieldSet $fieldset An auFormFieldSet object, with all of its elements already added.
     */
    public function AddFieldSet(auFormFieldSet &$fieldset) {
      return $this->Add($fieldset);
    }

    /**
     * Adds data to the form that will not display but will be submitted.
     *
     * @param string $name Name to submit the data as.
     * @param string $value Value of the data.
     * @return unknown
     */
    public function AddData($name, $value) {
      return $this->Add(new auFormData($name, $value));
    }

    /**
     * Adds text to the form that will display but will not be submitted.
     *
     * @param string $title Title of the text, which displays like a field label.
     * @param string $text The text to display.
     * @return unknown
     */
    public function AddText($title, $text) {
      return $this->Add(new auFormText($title, $text));
    }

    /**
     * Adds html to the form that will display but will not be submitted.
     *
     * @param string $title Title of the text, which displays like a field label.
     * @param string $html The html to display.
     * @return unknown
     */
    public function AddHTML($title, $html) {
      return $this->Add(new auFormHTML($title, $html));
    }

    /**
     * Adds a field to the form.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.
     * @param unknown_type $default Default value for this field.
     * @param integer $type Type of field.
     * @param integer $width Width of the field in characters.
     * @param integer $maxlength The maximum number of characters the field can accept.
     * @return unknown
     */
    public function AddField($name, $label = '', $tooltip = '', $required = false, $default = '', $type = _AU_FORM_FIELD_NORMAL, $width = 0, $maxlength = 0) {
      switch($type) {
        case _AU_FORM_FIELD_NORMAL:
          return $this->Add(new auFormString($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_BBCODE:
        case _AU_FORM_FIELD_MULTILINE:
          return $this->Add(new auFormMultiString($name, $label, $tooltip, $required, $default, $type == _AU_FORM_FIELD_BBCODE, $width, $maxlength));
        case _AU_FORM_FIELD_PASSWORD:
          return $this->Add(new auFormPassword($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_NUMERIC:
          return $this->Add(new auFormNumber($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_INTEGER:
          return $this->Add(new auFormInteger($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_DATETIME:
          return $this->Add(new auFormInstant($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_CHECKBOX:
          return $this->Add(new auFormCheckbox($name, $label, $tooltip, $default));
        case _AU_FORM_FIELD_FILE:
          return $this->Add(new auFormFile($name, $label, $tooltip, $required, $width));
        default:
          return false;
      }
    }

    /**
     * Adds a one-value selection field to the form.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.
     * @param array $values Associative array of possible values (value => display text).
     * @param string|integer $default Default value for this field.
     * @param integer $type Type of field -- set to _AU_FORM_SELECT_RADIO to use radio buttons.
     * @return unknown
     */
    public function AddSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_SELECT_DROPDOWN) {
      return $this->Add(new auFormSelect($name, $label, $tooltip, false, $values, $default, $type));
    }

    /**
     * Adds a multiple-value selection field to the form.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.
     * @param array $values Associative array of possible values (value => display text).
     * @param array $default Array of default values for this field.
     * @param integer $type Type of field -- set to _AU_FORM_MULTI_LIST to use list box.
     * @return unknown
     */
    public function AddMultiSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_MULTI_CHECK) {
      return $this->Add(new auFormMultiSelect($name, $label, $tooltip, false, $values, $default, $type));
    }

    /**
     * Adds submit buttons to the form.
     *
     * @param string $text Text to display on the button.  Pass an array to have multiple buttons on one line.
     * @param string $tooltip Tooltip text to display when the mouse is over the button.  Pass an array parallel to $text if $text was an array.
     * @param string $name Name that should be used for the button.  Must be the same for all buttons.  Default is submit.
     * @return unknown
     */
    public function AddButtons($text, $tooltip = '', $name = 'submit') {
      return $this->Add(new auFormButtons($text, $tooltip, $name));
    }

    /**
     * Writes out the form in HTML format.  If any fields have failed their
     * check, error messages will be displayed above the field.
     *
     * @param bool $trusted Whether the submitter is trusted.  This essentially disables anti-spam measures and is intended to be set true for logged-in users.
     * @param string $indent A string of white space to help line the form up with the rest of the HTML.
     */
    public function WriteHTML($trusted = false, $indent = '      ') {
      echo $indent . '<form id="frm' . $this->id . '" method="' . htmlspecialchars($this->method) . '" action="' . htmlspecialchars($this->action);
      if($this->hasfile)
        echo '" enctype="multipart/form-data';
      echo '"><div>' . "\n";
      if($this->error)
        echo $indent . '  <p class="error">' . $this->error . "</p>\n";
      $this->indent = $indent . '  ';
      if(!$trusted && strtolower($this->method) != 'get') {
        echo $this->indent . '<input type="text" name="website" value="DO NOT CHANGE THIS" />' . "\n";
        echo $this->indent . '<textarea name="comment"></textarea>' . "\n";
      }
      $this->intable = false;
      if(is_array($this->elements))
        foreach($this->elements as $element)
          $element->WriteHTML();
      if($this->intable)
        $this->EndTable();
      $this->indent = substr($this->indent, 2);
      echo $this->indent . "</div></form>\n\n";
    }

    /**
     * Checks if the form has been submitted.
     *
     * @return string|bool Text of the button used to submit the form, or false if the form was not submitted.
     */
    public function Submitted() {
      if(strtolower($this->method) == 'get') {
        if($_GET['formid'] != $this->id)
          return false;
        if($_GET[$this->submit])
          return $_GET[$this->submit];
        return true;
      }
      if($_POST['formid'] != $this->id)
        return false;
      if($_POST[$this->submit])
        return $_POST[$this->submit];
      return true;
    }

    /**
     * Checks all the form fields for invalid input.
     *
     * @param bool $trusted Whether the submitter is trusted.  This essentially disables anti-spam measures and is intended to be set true for logged-in users.
     * @return bool True if all fields are valid.
     */
    public function CheckInput($trusted = false) {
      if(!$this->Submitted())
        return false;
      $method = strtolower($this->method);
      if(!$trusted && $method != 'get' && ($_POST['website'] != 'DO NOT CHANGE THIS' || $_POST['comment'] != '')) {
        $this->error = 'You changed the secret fields!&nbsp; The first two fields should not display for people and are only meant to fool spambots.&nbsp; This may also happen if your session expired before you submitted the form, so you may just need to log back in and try again.';
        return false;
      }
      $ret = true;
      for($i = 0; $i < count($this->elements); $i++)
        if(!$this->elements[$i]->CheckInput())
          $ret = false;  // don't return from here because we want to check all fields
      return $ret;
    }

    /**
     * Gets any error messages generated by the last CheckInput() call.
     *
     * @param bool $fields Whether to also return errors from fields on the form.  Default is to include form errors and field errors.
     * @return array Array of error messages.
     */
    public function GetErrors($fields = true) {
      $errors = array();
      if($this->error)
        $errors[] = $this->error;
      if($fields)
        for($i = 0; $i < count($this->elements); $i++) {
          $error = $this->elements[$i]->GetErrors();
          if(is_array($error))
            foreach($error as $e)
              $errors[] = $e;
          elseif($error)
            $errors[] = $this->elements[$i]->GetLabel() . ':  ' . $error;
        }
      return $errors;
    }

    /**
     * Starts a table so form fields can be displayed in a table layout.  Should
     * only be called by other classes within auForm.php.
     */
    public function StartTable() {
      echo $this->indent . '<table class="columns">' . "\n";
      $this->intable = true;
      $this->firstfield = true;
      $this->indent .= '  ';
    }

    /**
     * Ends the current table.  Should be paired with a call to {@link StartTable}().
     */
    public function EndTable() {
      $this->indent = substr($this->indent, 2);
      echo $this->indent . "</table>\n";
      $this->intable = false;
    }

    /**
     * Starts a new row in the table so that a field can display on its own row.
     * Should be called between {@link StartTable}() and {@link EndTable}().
     *
     * @param bool $required Whether the field on this row is required.
     * @param bool $th Whether to start a th tag.
     */
    public function StartRow($required = false, $th = true) {
      echo $this->indent . '<tr';
      if($this->firstfield || $required) {
        echo ' class="';
        if($this->firstfield)
          echo 'first';
        if($this->firstfield && $required)
          echo ' ';
        if($required)
          echo 'required';
        echo '"';
      }
      if($th)
        echo '><th>';
      else
        echo '>';
      $this->firstfield = false;
    }

    /**
     * Ends the current row in the table.  Should be paired with a call to
     * {@link StartRow}().
     */
    public function EndRow() {
      echo '</td></tr>' . "\n";
    }
  }

  /**
   * A field set can have a title and puts a border around the fields it
   * contains.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 - 2010 track7.org
   * @tutorial http://wiki.track7.org/auFormFieldSet
   */
  class auFormFieldSet extends auFormContainer {
    private $title;
    private $id;
    private $class;
    private $contents;

    /**
     * Create a new field set.
     *
     * @param string $title Text to display at the top of the field set.
     * @param string $id ID of the field set, for CSS and / or JavaScript.
     * @param string $class CSS class name of the field set.
     * @param string $contents HTML contents of the fieldset.  Any fields it contains will be written after the contents.
     * @return auFormFieldSet
     */
    public function auFormFieldSet($title= '', $id = '', $class = '', $contents = '') {
      $this->title = $title;
      $this->id = $id;
      $this->class = $class;
      $this->contents = $contents;
    }

    /**
     * Adds data to the field set that will not display but will be submitted.
     *
     * @param string $name Name to submit the data as.
     * @param string $value Value of the data.
     * @return unknown
     */
    public function AddData($name, $value) {
      return $this->Add(new auFormData($name, $value));
    }

    /**
     * Adds text to the field set that will display but will not be submitted.
     *
     * @param string $title Title of the text, which displays like a field label.
     * @param string $text The text to display.
     * @return unknown
     */
    public function AddText($title, $text) {
      return $this->Add(new auFormText($title, $text));
    }

    /**
     * Adds html to the field set that will display but will not be submitted.
     *
     * @param string $title Title of the text, which displays like a field label.
     * @param string $html The html to display.
     * @return unknown
     */
    public function AddHTML($title, $html) {
      return $this->Add(new auFormHTML($title, $html));
    }

    /**
     * Adds a field to the field set.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.
     * @param unknown_type $default Default value for this field.
     * @param integer $type Type of field.
     * @param integer $width Width of the field in characters.
     * @param integer $maxlength The maximum number of characters the field can accept.
     * @return unknown
     */
    public function AddField($name, $label = '', $tooltip = '', $required = false, $default = '', $type = _AU_FORM_FIELD_NORMAL, $width = 0, $maxlength = 0) {
      switch($type) {
        case _AU_FORM_FIELD_NORMAL:
          return $this->Add(new auFormString($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_BBCODE:
        case _AU_FORM_FIELD_MULTILINE:
          return $this->Add(new auFormMultiString($name, $label, $tooltip, $required, $default, $type == _AU_FORM_FIELD_BBCODE, $width, $maxlength));
        case _AU_FORM_FIELD_PASSWORD:
          return $this->Add(new auFormPassword($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_NUMERIC:
          return $this->Add(new auFormNumber($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_INTEGER:
          return $this->Add(new auFormInteger($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_DATETIME:
          return $this->Add(new auFormInstant($name, $label, $tooltip, $required, $default, $width, $maxlength));
        case _AU_FORM_FIELD_CHECKBOX:
          return $this->Add(new auFormCheckbox($name, $label, $tooltip, $default));
        case _AU_FORM_FIELD_FILE:
          return $this->Add(new auFormFile($name, $label, $tooltip, $required, $width));
        default:
          return false;
      }
    }

    /**
     * Adds a one-value selection field to the field set.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.
     * @param array $values Associative array of possible values (value => display text).
     * @param string|integer $default Default value for this field.
     * @param integer $type Type of field -- set to _AU_FORM_SELECT_RADIO to use radio buttons.
     * @return unknown
     */
    public function AddSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_SELECT_DROPDOWN) {
      return $this->Add(new auFormSelect($name, $label, $tooltip, false, $values, $default, $type));
    }

    /**
     * Adds a multiple-value selection field to the field set.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.
     * @param array $values Associative array of possible values (value => display text).
     * @param array $default Array of default values for this field.
     * @param integer $type Type of field -- set to _AU_FORM_MULTI_LIST to use list box.
     * @return unknown
     */
    public function AddMultiSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_MULTI_CHECK) {
      return $this->Add(new auFormMultiSelect($name, $label, $tooltip, false, $values, $default, $type));
    }

    /**
     * Adds submit buttons to the field set.
     *
     * @param string $text Text to display on the button.  Pass an array to have multiple buttons on one line.
     * @param string $tooltip Tooltip text to display when the mouse is over the button.  Pass an array parallel to $text if $text was an array.
     * @param string $name Name that should be used for the button.  Must be the same for all buttons.  Default is submit.
     * @return unknown
     */
    public function AddButtons($text, $tooltip = '', $name = 'submit') {
      return $this->Add(new auFormButtons($text, $tooltip, $name));
    }

    /**
     * Writes out the HTML for the field set.
     */
    protected function WriteHTML() {
      if($this->ownerForm->intable)
        $this->ownerForm->EndTable();
      echo $this->ownerForm->indent . '<fieldset';
      if($this->id)
        echo ' id="' . htmlspecialchars($this->id) . '"';
      if($this->class)
        echo ' class="' . htmlspecialchars($this->class) . '"';
      echo ">\n";
      $this->ownerForm->indent .= '  ';
      if($this->title)
        echo $this->ownerForm->indent . '<legend>' . htmlspecialchars($this->title) . '</legend>' . "\n";
      if($this->contents)
        echo $this->ownerForm->indent . $this->contents . "\n";
      if(is_array($this->elements))
        foreach($this->elements as $element)
          $element->WriteHTML($form);
      if($this->ownerForm->intable)
        $this->ownerForm->EndTable();
      $this->ownerForm->indent = substr($this->ownerForm->indent, 2);
      echo $this->ownerForm->indent . '</fieldset>' . "\n";
    }

    /**
     * Gets the label of the element, if any.
     *
     * @return string Label of the element.
     */
    protected function GetLabel() {
      return $this->title;
    }
  }

  /**
   * A data element that will not display but will be submitted.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormData
   */
  class auFormData extends auFormElement {
    private $name;
    private $value;

    /**
     * Creates a data element that will not display but will be submitted.
     *
     * @param string $name Name to submit the data under.
     * @param string $value Value of the data.
     * @return auFormData
     */
    public function auFormData($name, $value) {
      $this->name = $name;
      $this->value = $value;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if($this->ownerForm->intable)
        $this->ownerForm->EndTable();
      echo $form->indent . '<input type="hidden" name="' . htmlspecialchars($this->name) . '" value="' . htmlspecialchars($this->value) . '" />' . "\n";
    }
  }

  /**
   * A text element that will display but will not be submitted.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormText
   */
  class auFormText extends auFormElement {
    private $title;
    private $text;

    /**
     * Creates a text element that will display but will not be submitted.
     *
     * @param string $title Short text to display in the label column.
     * @param string $text Text to display in the field column.
     * @return auFormText
     */
    public function auFormText($title, $text) {
      $this->title = $title;
      $this->text = $text;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow(false);
      echo htmlspecialchars($this->title) . '</th><td>' . htmlspecialchars($this->text);
      $this->ownerForm->EndRow();
    }

    /**
     * Gets the label (title) of the element.
     *
     * @return string The title of the element.
     */
    protected function GetLabel() {
      return $this->title;
    }
  }

  /**
   * An HTML element that will display but will not be submitted.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormHTML
   */
  class auFormHTML extends auFormElement {
    private $title;
    private $html;

    /**
     * Creates an HTML element that will display but will not be submitted.
     *
     * @param string $title Short text to display in the label column.
     * @param string $html HTML to display in the field column.
     * @return auFormHTML
     */
    public function auFormHTML($title, $html) {
      $this->title = $title;
      $this->html = $html;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow(false);
      echo htmlspecialchars($this->title) . '</th><td>' . $this->html;
      $this->ownerForm->EndRow();
    }

    /**
     * Gets the label (title) of the element.
     *
     * @return string The title of the element.
     */
    protected function GetLabel() {
      return $this->title;
    }
  }

  /**
   * A one-line text field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormString
   */
  class auFormString extends auFormField {
    private $required;
    private $default;
    private $width;
    private $maxlength;

    /**
     * Creates a one-line text field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.
     * @param string $default Default value for this field.
     * @param integer $width Width of the field in characters.
     * @param integer $maxlength The maximum number of characters the field can accept.
     * @return auFormString
     */
    public function auFormString($name, $label = '', $tooltip = '', $required = false, $default = '', $width = 0, $maxlength = 0) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->default = $default;
      if(is_numeric($width))
        $this->width = $width;
      else
        $this->width = 0;
      if(is_numeric($maxlength))
        $this->maxlength = $maxlength;
      else
        $this->maxlength = 0;
      $this->error = false;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if($pos = strpos($this->name, '[')) {
          list($i, $remain) = explode('[', $this->name, 2);
          if(strtolower($this->ownerForm->method) == 'get')
            $default = $_GET[$i];
          else
            $default = $_POST[$i];
          $remain = explode('[', str_replace(']', '', $remain));
          foreach($remain as $i)
            $default = $default[$i];
        } elseif(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      echo '<input class="string" type="text" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
      if($this->width)
        echo '" size="' . $this->width;
      if($this->maxlength)
        echo '" maxlength="' . $this->maxlength;
      if($default)
        echo '" value="' . htmlspecialchars($default);
      echo '" />';
      $this->ownerForm->EndRow();
    }

    /**
     * Checks the field value for errors.
     *
     * @return bool Whether there are errors with this field.
     */
    protected function CheckInput() {
      if($pos = strpos($this->name, '[')) {
        $var = '[' . substr($this->name, 0, $pos) . ']' . substr($this->name, $pos);
        $var = preg_replace('/\[([^\]]*[^0-9\]][^\]]*)\]/', '[\'$1\']', $var);
        if($this->ownerForm->method == 'get')
          $var = '$_GET' . $var;
        else
          $var = '$_POST' . $var;
        $set = false;
        eval('$set = isset(' . $var . ');');
        if($set)
          eval('$val = ' . $var . ' = trim(' . $var . ');');
      } elseif($this->ownerForm->method == 'get') {
        if(isset($_GET[$this->name]))
          $val = $_GET[$this->name] = trim($_GET[$this->name]);
      } elseif(isset($_POST[$this->name]))
        $val = $_POST[$this->name] = trim($_POST[$this->name]);
      if($this->required && strlen($val) < 1) {
        $this->error = 'This field is required.';
        return false;
      }
      if(strpos($val, '\n') !== false) {
        $this->error = 'This field may not contain line breaks.';
        return false;
      }
      return true;
    }
  }

  /**
   * A multiple-line text field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormMultiString
   */
  class auFormMultiString extends auFormField {
    private $required;
    private $default;
    private $bbcode;
    private $width;
    private $maxlength;

    /**
     * Creates a multiple-line text field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.
     * @param string $default Default value for this field.
     * @param integer $width Width of the field in characters.
     * @param integer $maxlength The maximum number of characters the field can accept.
     * @return auFormMultiString
     */
    public function auFormMultiString($name, $label = '', $tooltip = '', $required = false, $default = '', $bbcode = false, $width = 0, $maxlength = 0) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->default = $default;
      $this->bbcode = $bbcode;
      if(is_numeric($width))
        $this->width = $width;
      else
        $this->width = 0;
      if(is_numeric($maxlength))
        $this->maxlength = $maxlength;
      else
        $this->maxlength = 0;
      $this->error = false;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if($pos = strpos($this->name, '[')) {
          list($i, $remain) = explode('[', $this->name, 2);
          if(strtolower($this->ownerForm->method) == 'get')
            $default = $_GET[$i];
          else
            $default = $_POST[$i];
          $remain = explode('[', str_replace(']', '', $remain));
          foreach($remain as $i)
            $default = $default[$i];
        } elseif(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      // DO:  put in bbcode buttons if bbcode requested
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      echo '<textarea class="';
      if($this->bbcode)
        echo 'bbcode';
      else
        echo 'multistring';
      echo '" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '" rows="12" cols="';
      if($this->width)
        echo $this->width;
      else
        echo 70;
      if($this->maxlength)
        echo '" maxlength="' . $this->maxlength;
      echo '">' . htmlspecialchars($default) . '</textarea>';
      $this->ownerForm->EndRow();
    }

    /**
     * Checks the field value for errors.
     *
     * @return bool Whether there are errors with this field.
     */
    protected function CheckInput() {
      if($pos = strpos($this->name, '[')) {
        $var = '[' . substr($this->name, 0, $pos) . ']' . substr($this->name, $pos);
        $var = preg_replace('/\[([^\]]*[^0-9\]][^\]]*)\]/', '[\'$1\']', $var);
        if($this->ownerForm->method == 'get')
          $var = '$_GET' . $var;
        else
          $var = '$_POST' . $var;
        $set = false;
        eval('$set = isset(' . $var . ');');
        if($set)
          eval('$val = ' . $var . ' = trim(' . $var . ');');
      } elseif($this->ownerForm->method == 'get') {
        if(isset($_GET[$this->name]))
          $val = $_GET[$this->name] = trim($_GET[$this->name]);
      } elseif(isset($_POST[$this->name]))
        $val = $_POST[$this->name] = trim($_POST[$this->name]);
      if($this->required && strlen($val) < 1) {
        $this->error = 'This field is required.';
        return false;
      }
      return true;
    }
  }

  /**
   * A password field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormPassword
   */
  class auFormPassword extends auFormField {
    private $required;
    private $default;
    private $width;
    private $maxlength;

    /**
     * Creates a password field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.
     * @param string $default Default value for this field.
     * @param integer $width Width of the field in characters.
     * @param integer $maxlength The maximum number of characters the field can accept.
     * @return auFormPassword
     */
    public function auFormPassword($name, $label = '', $tooltip = '', $required = false, $default = '', $width = 0, $maxlength = 0) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->default = $default;
      if(is_numeric($width))
        $this->width = $width;
      else
        $this->width = 0;
      if(is_numeric($maxlength))
        $this->maxlength = $maxlength;
      else
        $this->maxlength = 0;
      $this->error = false;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if($pos = strpos($this->name, '[')) {
          list($i, $remain) = explode('[', $this->name, 2);
          if(strtolower($this->ownerForm->method) == 'get')
            $default = $_GET[$i];
          else
            $default = $_POST[$i];
          $remain = explode('[', str_replace(']', '', $remain));
          foreach($remain as $i)
            $default = $default[$i];
        } elseif(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      echo '<input type="password" class="password" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
      if($this->width)
        echo '" size="' . $this->width;
      if($this->maxlength)
        echo '" maxlength="' . $this->maxlength;
      echo '" />';
      $this->ownerForm->EndRow();
    }

    /**
     * Checks the field value for errors.
     *
     * @return bool Whether there are errors with this field.
     */
    protected function CheckInput() {
      if($pos = strpos($this->name, '[')) {
        $var = '[' . substr($this->name, 0, $pos) . ']' . substr($this->name, $pos);
        $var = preg_replace('/\[([^\]]*[^0-9\]][^\]]*)\]/', '[\'$1\']', $var);
        if($this->ownerForm->method == 'get')
          $var = '$_GET' . $var;
        else
          $var = '$_POST' . $var;
        $set = false;
        eval('$set = isset(' . $var . ');');
        if($set)
          eval('$val = ' . $var . ' = trim(' . $var . ');');
      } elseif($this->ownerForm->method == 'get') {
        if(isset($_GET[$this->name]))
          $val = $_GET[$this->name] = trim($_GET[$this->name]);
      } elseif(isset($_POST[$this->name]))
        $val = $_POST[$this->name] = trim($_POST[$this->name]);
      if($this->required && strlen($val) < 1) {
        $this->error = 'This field is required.';
        return false;
      }
      return true;
    }
  }

  /**
   * A numeric input field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormNumber
   */
  class auFormNumber extends auFormField {
    protected $required;
    protected $default;
    protected $width;
    protected $maxlength;

    /**
     * Creates a numeric input field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.
     * @param float $default Default value for this field.
     * @param integer $width Width of the field in characters.
     * @param integer $maxlength The maximum number of characters the field can accept.
     * @return auFormNumber
     */
    public function auFormNumber($name, $label = '', $tooltip = '', $required = false, $default = '', $width = 0, $maxlength = 0) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->default = $default;
      if(is_numeric($width))
        $this->width = $width;
      else
        $this->width = 0;
      if(is_numeric($maxlength))
        $this->maxlength = $maxlength;
      else
        $this->maxlength = 0;
      $this->error = false;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if($pos = strpos($this->name, '[')) {
          list($i, $remain) = explode('[', $this->name, 2);
          if(strtolower($this->ownerForm->method) == 'get')
            $default = $_GET[$i];
          else
            $default = $_POST[$i];
          $remain = explode('[', str_replace(']', '', $remain));
          foreach($remain as $i)
            $default = $default[$i];
        } elseif(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      echo '<input type="text" class="number" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
      if($this->width)
        echo '" size="' . $this->width;
      if($this->maxlength)
        echo '" maxlength="' . $this->maxlength;
      if($default)
        echo '" value="' . htmlspecialchars($default);
      echo '" />';
      $this->ownerForm->EndRow();
    }

    /**
     * Checks the field value for errors.
     *
     * @return bool Whether there are errors with this field.
     */
    protected function CheckInput() {
      if($pos = strpos($this->name, '[')) {
        $var = '[' . substr($this->name, 0, $pos) . ']' . substr($this->name, $pos);
        $var = preg_replace('/\[([^\]]*[^0-9\]][^\]]*)\]/', '[\'$1\']', $var);
        if($this->ownerForm->method == 'get')
          $var = '$_GET' . $var;
        else
          $var = '$_POST' . $var;
        $set = false;
        eval('$set = isset(' . $var . ');');
        if($set)
          eval('$val = ' . $var . ' = trim(' . $var . ');');
      } elseif($this->ownerForm->method == 'get') {
        if(isset($_GET[$this->name]))
          $val = $_GET[$this->name] = trim($_GET[$this->name]);
      } elseif(isset($_POST[$this->name]))
        $val = $_POST[$this->name] = trim($_POST[$this->name]);
      if($this->required && strlen($val) < 1) {
        $this->error = 'This field is required.';
        return false;
      }
      if(strlen($val) && !is_numeric($val)) {
        $this->error = 'This field requires a numeric value.';
        return false;
      }
      return true;
    }
  }

  /**
   * An integer input field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormInteger
   */
  class auFormInteger extends auFormNumber {
    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if($pos = strpos($this->name, '[')) {
          list($i, $remain) = explode('[', $this->name, 2);
          if(strtolower($this->ownerForm->method) == 'get')
            $default = $_GET[$i];
          else
            $default = $_POST[$i];
          $remain = explode('[', str_replace(']', '', $remain));
          foreach($remain as $i)
            $default = $default[$i];
        } elseif(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      echo '<input type="text" class="integer" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
      if($this->width)
        echo '" size="' . $this->width;
      if($this->maxlength)
        echo '" maxlength="' . $this->maxlength;
      if($default)
        echo '" value="' . htmlspecialchars($default);
      echo '" />';
      $this->ownerForm->EndRow();
    }

    /**
     * Checks the field value for errors.
     *
     * @return bool Whether there are errors with this field.
     */
    protected function CheckInput() {
      if(!parent::CheckInput())
        return false;
      // checks out fine as a number, so round it off
      if($pos = strpos($this->name, '[')) {
        $var = '[' . substr($this->name, 0, $pos) . ']' . substr($this->name, $pos);
        $var = preg_replace('/\[([^\]]*[^0-9\]][^\]]*)\]/', '[\'$1\']', $var);
        if($this->ownerForm->method == 'get')
          $var = '$_GET' . $var;
        else
          $var = '$_POST' . $var;
        eval($var . ' = round(' . $var . ');');
      } elseif($this->ownerForm->method == 'get')
        $_GET[$this->name] = round($_GET[$this->name]);
      else
        $_POST[$this->name] = round($_POST[$this->name]);
      return true;
    }
  }

  /**
   * A date / time input field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormInstant
   */
  class auFormInstant extends auFormField {
    private $required;
    private $default;
    private $width;
    private $maxlength;

    /**
     * Creates a date / time input field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.
     * @param unknown_type $default Default value for this field.
     * @param integer $width Width of the field in characters.
     * @param integer $maxlength The maximum number of characters the field can accept.
     * @return auFormInstant
     */
    public function auFormInstant($name, $label = '', $tooltip = '', $required = false, $default = '', $width = 0, $maxlength = 0) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->default = $default;
      if(is_numeric($width))
        $this->width = $width;
      else
        $this->width = 0;
      if(is_numeric($maxlength))
        $this->maxlength = $maxlength;
      else
        $this->maxlength = 0;
      $this->error = false;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if($pos = strpos($this->name, '[')) {
          list($i, $remain) = explode('[', $this->name, 2);
          if(strtolower($this->ownerForm->method) == 'get')
            $default = $_GET[$i];
          else
            $default = $_POST[$i];
          $remain = explode('[', str_replace(']', '', $remain));
          foreach($remain as $i)
            $default = $default[$i];
        } elseif(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      echo '<input type="text" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
      if($this->width)
        echo '" size="' . $this->width;
      if($this->maxlength)
        echo '" maxlength="' . $this->maxlength;
      if($default)
        echo '" value="' . htmlspecialchars($default);
      echo '" />';
      $this->ownerForm->EndRow();
    }

    /**
     * Checks the field value for errors.
     *
     * @return bool Whether there are errors with this field.
     */
    protected function CheckInput() {
      if($pos = strpos($this->name, '[')) {
        $var = '[' . substr($this->name, 0, $pos) . ']' . substr($this->name, $pos);
        $var = preg_replace('/\[([^\]]*[^0-9\]][^\]]*)\]/', '[\'$1\']', $var);
        if($this->ownerForm->method == 'get')
          $var = '$_GET' . $var;
        else
          $var = '$_POST' . $var;
        $set = false;
        eval('$set = isset(' . $var . ');');
        if($set)
          eval('$val = ' . $var . ' = trim(' . $var . ');');
      } elseif($this->ownerForm->method == 'get') {
        if(isset($_GET[$this->name]))
          $val = $_GET[$this->name] = trim($_GET[$this->name]);
      } elseif(isset($_POST[$this->name]))
        $val = $_POST[$this->name] = trim($_POST[$this->name]);
      if($this->required && strlen($val) < 1) {
        $this->error = 'This field is required.';
        return false;
      }
      return true;
    }
  }

  /**
   * A yes/no or true/false input field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormCheckbox
   */
  class auFormCheckbox extends auFormField {
    private $default;

    /**
     * Creates a yes/no or true/false input field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $description Text to display next to the checkbox to explain what it means.
     * @param bool $default Default value for this field.
     * @return auFormCheckbox
     */
    public function auFormCheckbox($name, $label = '', $description = '', $default = false) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $description;
      $this->default = $default;
      $this->error = false;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow(false);
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if($pos = strpos($this->name, '[')) {
          list($i, $remain) = explode('[', $this->name, 2);
          if(strtolower($this->ownerForm->method) == 'get')
            $default = $_GET[$i];
          else
            $default = $_POST[$i];
          $remain = explode('[', str_replace(']', '', $remain));
          foreach($remain as $i)
            $default = $default[$i];
        } elseif(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      echo $this->label . '</th><td><input type="checkbox" class="checkbox" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '" value="' . htmlspecialchars($this->name);
      if($default)
        echo '" checked="checked';
      echo '" /> ';
      if($this->tooltip)
        echo '<label for="fld' . htmlspecialchars($this->name) . '">' . htmlspecialchars($this->tooltip) . '</label>';
      $this->ownerForm->EndRow();
    }
  }

  /**
   * A file input field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormFile
   */
  class auFormFile extends auFormField {
    private $required;
    private $width;

    /**
     * Creates a file input field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.  For checkbox fields, the tooltip displays next to the checkbox itself.
     * @param bool $required Whether a value is required in this field.  This is display only — see {@link auFile} for checking if a file has been uploaded.
     * @param integer $width Width of the field in characters.
     * @return auFormFile
     */
    public function auFormFile($name, $label = '', $tooltip = '', $required = false, $width = 0) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      if(is_numeric($width))
        $this->width = $width;
      else
        $this->width = 0;
      $this->error = false;
    }

    /**
     * Writes out the HTML for this form element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      echo '</th><td><input type="file" class="file" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
      if($this->width)
        echo '" size="' . $this->width;
      echo '" />';
      $this->ownerForm->EndRow();
    }
  }


  /**
   * A one-value selection field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormSelect
   */
  class auFormSelect extends auFormField {
    private $required;
    private $values;
    private $default;
    private $type;

    /**
     * Creates a one-value selection field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.
     * @param bool $required Whether a value is required in this field.
     * @param array $values Associative array of possible values (value => display text).
     * @param string|integer $default Default value for this field.
     * @param integer $type Type of field -- set to _AU_FORM_SELECT_RADIO to use radio buttons.
     * @return auFormSelect
     */
    public function auFormSelect($name, $label = '', $tooltip = '', $required = false, $values = '', $default = null, $type = _AU_FORM_SELECT_DROPDOWN) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->values = $values;
      $this->default = htmlspecialchars($default);
      $this->type = $type;
      $this->error = false;
    }

    /**
     * Takes a numeric-indexed array and turns it into an associative array.
     * This is helpful for the values parameter when the actual values should be
     * displayed.
     *
     * @param array $array Numeric-indexed array to convert.
     * @return array Associative array.
     */
    public static function ArrayIndex($array) {
      foreach($array as $item)
        $ret[$item] = null;
      return $ret;
    }

    /**
     * Writes out the HTML for the element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
        if(strtolower($this->ownerForm->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      switch($this->type) {
        case _AU_FORM_SELECT_DROPDOWN:
          echo '<select id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '">' . "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              echo $this->ownerForm->indent . '  <option';
              if($default == $value)
                echo ' selected="selected"';
              if($text)
                echo ' value="' . htmlspecialchars($value) . '">' . htmlspecialchars($text);
              else
                echo '>' . htmlspecialchars($value);
              echo '</option>' . "\n";
            }
          echo $this->ownerForm->indent . '</select>';
          break;
        case _AU_FORM_SELECT_RADIO:
          echo "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              echo $this->ownerForm->indent . '  <div><input type="radio" name="' . htmlspecialchars($this->name) . '" value="' . htmlspecialchars($value) . '" id="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value);
              if($default == $value)
                echo '" checked="checked';
              echo '" /><label for="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value) . '">';
              if($text)
                echo htmlspecialchars($text);
              else
                echo htmlspecialchars($value);
              echo "</label></div>\n";
            }
          echo $this->ownerForm->indent;
          break;
      }
      $this->ownerForm->EndRow();
    }

    /**
     * Checks the field value for errors.
     *
     * @return bool Whether there are errors with this field.
     */
    protected function CheckInput() {
      $val = $this->ownerForm->method == 'get' ? $_GET[$this->name] : $_POST[$this->name];
      if(!array_key_exists($val, $this->values)) {
        $this->error = 'One of the options must be selected.';
        return false;
      }
      if($val = '' && $this->required) {
        $this->error = 'This field may not be left blank.';
      }
      return true;
    }
  }

  /**
   * A multiple-value selection field.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormMultiSelect
   */
  class auFormMultiSelect extends auFormField {
    private $required;
    private $values;
    private $default;
    private $type;

    /**
     * Creates a multiple-value selection field.
     *
     * @param string $name Name to submit the field as.
     * @param string $label Label to display with the field.
     * @param string $tooltip Tooltip text to display when the mouse is over the label.
     * @param bool $required Whether a value is required in this field.  This is display only.
     * @param array $values Associative array of possible values (value => display text).
     * @param array $default Array of default values for this field.
     * @param integer $type Type of field -- set to _AU_FORM_MULTI_LIST to use list box.
     * @return auFormMultiSelect
     */
    public function auFormMultiSelect($name, $label = '', $tooltip = '', $required = false, $values = '', $default = null, $type = _AU_FORM_MULTI_CHECK) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->values = $values;
      $this->default = $default;
      $this->type = $type;
    }

    /**
     * Writes out the HTML for the element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      switch($this->type) {
        case _AU_FORM_MULTI_LIST:
          if($this->ownerForm->Submitted() && !$this->ownerForm->defaultonly)
            if(strtolower($this->ownerForm->method) == 'get')
              $default = $_GET[$this->name];
            else
              $default = $_POST[$this->name];
          else
            $default = $this->default;
          echo '</th><td><select id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '[]" size="';
          if(count($this->values) > 7)
            echo 7;
          else
            echo count($this->values);
          echo '" multiple="multiple">' . "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              echo $this->ownerForm->indent . '  <option';
              if(in_array($value, $default))
                echo ' selected="selected"';
              if($text)
                echo ' value="' . htmlspecialchars($value) . '">' . htmlspecialchars($text);
              else
                echo '>' . htmlspecialchars($value);
              echo '</option>' . "\n";
            }
          echo $this->ownerForm->indent . '</select>' . "\n";
          break;
        case _AU_FORM_MULTI_CHECK:
          $isArray = strpos($this->name, '[');
          if($this->ownerForm->Submitted())
            if($isArray) {
              list($i, $remain) = explode('[', $this->name, 2);
              if(strtolower($this->ownerForm->method) == 'get')
                $chk = $_GET[$i];
              else
                $chk = $_POST[$i];
              $remain = explode('[', str_replace(']', '', $remain));
              foreach($remain as $i)
                $chk = $chk[$i];
              foreach($this->values as $value => $text)
                if($chk[$value])
                  $default[] = $value;
            } else
              if(strtolower($this->ownerForm->method) == 'get') {
                foreach($this->values as $value => $text)
                  if($_GET[$this->name . '_' . $value] || $_GET[$this->name . '_' . str_replace(' ', '_', $value)])
                    $default[] = $value;
              } else {
                foreach($this->values as $value => $text)
                  if($_POST[$this->name . '_' . $value] || $_POST[$this->name . '_' . str_replace(' ', '_', $value)])
                    $default[] = $value;
              }
          else
            $default = $this->default;
          echo '</th><td>' . "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              if($isArray)
                echo $this->ownerForm->indent . '  <div><input type="checkbox" name="' . htmlspecialchars($this->name) . '[' . htmlspecialchars($value) . ']" value="' . htmlspecialchars($value) . '" id="fld' . htmlspecialchars($this->name) . '[' . htmlspecialchars($value) . ']';
              else
                echo $this->ownerForm->indent . '  <div><input type="checkbox" name="' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value) . '" value="' . htmlspecialchars($value) . '" id="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value);
              if(is_array($default) && in_array($value, $default))
                echo '" checked="checked';
              if($isArray)
                echo '" /><label for="fld' . htmlspecialchars($this->name) . '[' . htmlspecialchars($value) . ']">';
              else
                echo '" /><label for="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value) . '">';
              if($text)
                echo htmlspecialchars($text);
              else
                echo htmlspecialchars($value);
              echo "</label></div>\n";
            }
          echo $this->ownerForm->indent;
          break;
      }
      $this->ownerForm->EndRow();
    }
  }

  /**
   * A submit button or multiple submit buttons.
   *
   * @package auLib
   * @subpackage auForm
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auFormButtons
   */
  class auFormButtons extends auFormElement {
    private $text;
    private $tooltip;
    private $name;

    /**
     * Creates a submit button or multiple submit buttons.
     *
     * @param string $text Text to display on the button.  Pass an array to have multiple buttons on one line.
     * @param string $tooltip Tooltip text to display when the mouse is over the button.  Pass an array parallel to $text if $text was an array.
     * @param string $name Name that should be used for the button.  Must be the same for all buttons.  Default is submit.
     * @return auFormButtons
     */
    public function auFormButtons($text, $tooltip = '', $name = 'submit') {
      $this->text = $text;
      $this->tooltip = $tooltip;
      $this->name = $name;
    }

    /**
     * Gets the name that submit buttons are sent to the server as.
     *
     * @return string Name that submit buttons are sent to the server as.
     */
    public function GetSubmit() {
      return $this->name;
    }

    /**
     * Writes out the HTML for the element.
     */
    protected function WriteHTML() {
      if(!$this->ownerForm->intable)
        $this->ownerForm->StartTable();
      $this->ownerForm->StartRow(false, false);
      echo '<td></td><td>';
      if(is_array($this->text)) {
        echo "\n";
        for($i = 0; $i < count($this->text); $i++) {
          echo $this->ownerForm->indent . '  <input type="submit" name="' . $this->name . '" value="' . htmlspecialchars($this->text[$i]);
          if($this->tooltip[$i])
            echo '" title="' . htmlspecialchars($this->tooltip[$i]);
          echo '" />' . "\n";
        }
        echo $this->ownerForm->indent;
      } else {
        echo '<input type="submit" name="' . $this->name . '" value="' . htmlspecialchars($this->text);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '" />';
      }
      $this->ownerForm->EndRow();
    }
  }
?>
