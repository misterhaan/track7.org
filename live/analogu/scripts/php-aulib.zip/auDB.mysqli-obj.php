<?
/******************************************************************************\
 * Title:    Database class for MySQL using PHP's mysqli class.
 * Purpose:  Interacts with a MySQL database through PHP's mysqli class.
 * History:  0.2.0 - Initial release
\******************************************************************************/

require_once 'auDB.base.php';

/*==============================================================[ auDB class ]==
  Create an auDB object using new auDB(), then run queries against it with
  Get(), GetRecord(), GetValue(), GetLimit(), GetSplit(), Put(), and Change().
  NumQueries() will tell you how many queries have been run since the object
  was created.
*/
  class auDB extends auDBBase {
    private $mysqli;  // mysqli connection object

/*--------------------------------------------------------[ auDB constructor ]--
  Creates a new database object.
  $user = Username for database account.
  $pass = Password for database account.
  $host = Name of server hosting the database (often 'localhost' works).
  $name = Name of database to work with.
  $report = Object with Error($, $) and Info($) methods for displaying error
    and information messages.  Defaults to built-in object which simply writes
    HTML messages.
*/
    public function auDB($user, $pass, $host, $name, &$report = null) {
      $this->mysqli = new mysqli($host, $user, $pass, $name);
      parent::auDBBase($user, $pass, $host, $name, $report);
    }
    
/*-----------------------------------------------------------[ auDB.GetLimit ]--
  Runs an SQL SELECT query against the database and gets back a limited number
    of records in the results.
  $query = SQL SELECT query to run.
  $skip = Number of result records to skip.
  $show = Number of result records to show.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  $emptymsg = Message to report if the query does not return any results.
    Default is to return the results without checking to see if there are any
    results.
  $emptyerror = Whether empty results should be reported as an error.
    Default is to report empty results as information.
  @return = The results as an auDBResult object, or false.
*/
    public function GetLimit($query, $skip, $show, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      return $this->Get($query . ' limit ' . $skip . ', ' . $show, $errormsg, $emptymsg, $emptyerror);
    }

/*----------------------------------------------------------------[ auDB.Put ]--
  Runs an SQL INSERT or REPLACE query against the database.
  $query = SQL INSERT/REPLACE query to run.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  @return = The ID of the inserted record, or false on failure.
*/
    public function Put($query, $errormsg = null) {
      if(parent::Put($query, $errormsg))
        return $this->mysqli->insert_id;
      return false;
    }

    protected function Query($sql) {
      $this->queries++;
      return new auDBResult($sql, $this->mysqli);
    }
  }

/*========================================================[ auDBResult class ]==
  Provides access to results of an SQL query.  This class is instantiated and
  returned by methods in the auDB class.
*/
  class auDBResult extends auDBResultBase {

/*--------------------------------------------------[ auDBResult constructor ]--
  Runs an SQL query against the database and provides access to the results.
  $query = SQL query to run.
*/
    public function auDBResult($query, &$mysqli) {
      if($mysqli->real_query($query) && $this->result = $mysqli->store_result()) {
        $this->error = false;
        $this->message = '';
        if(strtolower(substr(trim($query), 0, 6)) == 'select')
          $this->affected = $this->result->num_rows;
        else
          $this->affected = $mysqli->affected_rows;
      } else {
        $this->error = true;
        $this->message = htmlspecialchars($mysqli->errno . ' ' . $mysqli->error);
        $this->affected = 0;
      }
    }

/*---------------------------------------------------[ auDBResult.NextRecord ]--
  Returns the next record returned by the query.
  $object = Set to false to return the record as an array.
  @return = The next record returned by the query, or false if no more records.
*/
    public function NextRecord($object = true) {
      if(!$object)
        return $this->result->fetch_row();
      return $this->result->fetch_object();
    }
  }
?>
