<?
/******************************************************************************\
 * Title:    Timer class
 * Purpose:  Stopwatch functions for timing code execution.
 * History:  0.0.0 - Initial release
 *           0.2.0 - Avoid time rounding errors
\******************************************************************************/

/*===========================================================[ auTimer class ]==
  Create a timer using new auTimer, then check the elapsed time with
  CheckTime() or CheckElapsedTime().
*/
  class auTimer {
    private $begintime;
    private $lasttime;

/*-----------------------------------------------------[ auTimer constructor ]--
  Creates a new timer object and resets the time.
*/
    public function auTimer() {
      $this->begintime = $this->lasttime = explode(' ', microtime()); 
    }

/*------------------------------------------------[ auTimer.CheckElapsedTime ]--
  Checks the time since the timer was last checked.
  @return = Elapsed time in seconds.
*/
    public function CheckElapsedTime() {
      $time = explode(' ', microtime());
      $last = $this->lasttime;
      $this->lasttime = $time;
      $time[0] -= $last[0];
      $time[1] -= $last[1];
      return $time[0] + $time[1];
    }

/*-------------------------------------------------------[ auTimer.CheckTime ]--
  Checks the time since the timer was created.
  @return = Elapsed time in seconds.
*/
    public function CheckTime() {
      $time = $this->lasttime = explode(' ', microtime());
      $time[0] -= $this->begintime[0];
      $time[1] -= $this->begintime[1];
      return $time[0] + $time[1];
    }
  }
?>