<?
// History:
// 0.0.0 - Initial release
// 0.2.0 - Avoid time rounding errors
// 0.3.0 - Add phpDoc

  /**
   * Timer class containing stopwatch functions for timing code execution.
   *
   * Create a timer using new auTimer, then check the elapsed time with
   * CheckTime() or CheckElapsedTime().
   * @package auLib
   * @author misterhaan
   * @copyright © 2008 track7.org
   * @tutorial http://wiki.track7.org/auTimer
   */
  class auTimer {
    private $begintime;
    private $lasttime;

    /**
     * Creates a new timer object and resets the time.
     *
     * @return auTimer
     */
    public function auTimer() {
      $this->begintime = $this->lasttime = explode(' ', microtime()); 
    }

    /**
     * Checks the time since the timer was last checked.
     *
     * @return float Elapsed time in seconds.
     */
    public function CheckElapsedTime() {
      $time = explode(' ', microtime());
      $last = $this->lasttime;
      $this->lasttime = $time;
      $time[0] -= $last[0];
      $time[1] -= $last[1];
      return $time[0] + $time[1];
    }

    /**
     * Checks the time since the timer was created.
     *
     * @return float Elapsed time in seconds.
     */
    public function CheckTime() {
      $time = $this->lasttime = explode(' ', microtime());
      $time[0] -= $this->begintime[0];
      $time[1] -= $this->begintime[1];
      return $time[0] + $time[1];
    }
  }
?>