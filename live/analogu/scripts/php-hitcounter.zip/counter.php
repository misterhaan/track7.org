<?php
  // start/continue a php session--we only count one hit per session
  session_start();

  // change the ip address on the next line to your ip if you don't want to
  // count hits from yourself checking your pages
  if ($_SERVER['REMOTE_ADDR'] != '127.0.0.1') {

    // hitcount.txt should be in your server root
    $counterfile = $_SERVER['DOCUMENT_ROOT'] . '/hitcount.txt';

    // check to see if we already counted this session
    if (!session_is_registered('counted')) {

      // get the current count
      $counter = @fopen($counterfile,rw);
      $count = @fgets($counter);
      @fclose($counter);

      // rewrite the file with a count of one more
      $counter = @fopen($counterfile,w);
      @fputs($counter,$count + 1);
      @fclose($counter);

      // mark the session as counted so we won't count it again
      session_register('counted');
    }
  }
?>