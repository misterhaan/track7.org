<?
/**==========================================================================**\
 ||  this file contains the following classes:                               ||
 ||    instantiable:  ENGINE                                                 ||
 ||    static:  GPC, SIZE, URL, DATE                                         ||
\**==========================================================================**/


/*----------------------------------------------------------------------------*\
 | title:    engine                                                           |
 | purpose:  handles all the common back-end stuff for the site.  when this   |
 |           file is required or included it creates an object $engine from   |
 |           the ENGINE class defined in this file.                           |
 | notes:    all functions should be called through the $engine object.  see  |
 |           the individual functions for more details on what they do.       |
\*----------------------------------------------------------------------------*/

  require_once '.consts.php';  // get a bunch of constants for later

  class ENGINE {
    var $db;            // the PEAR::DB object

    var $split_count;   // the row count from the last time splitquery() was used
    var $split_skip;    // the GET variable name for skip, set when splitquery() is used
    var $split_show;    // the GET variable name for show, set when splitquery() is used
    var $split_dskip;   // the default number of rows to skip, usually 0
    var $split_dshow;   // the default number of rows to show

    //----------------------------[ connect ]-----------------------------\\
    // sets up the db object using PEAR.  completely stops execution of   \\
    // the script if unable to connect.  may be called externally but is  \\
    // also called by many functions within this class that need to use   \\
    // the database.                                                      \\
    function connect() {
      require_once 'DB.php';  // get the PEAR::DB class
      $this->db = DB::connect(_DB_ENGINE . '://' . _DB_USER . ':' . _DB_PASS . '@' . _DB_HOST . '/' . _DB_NAME);
      if(DB::isError($this->db))
        die('unable to connect to the database!<br>' . $this->db->getMessage());
      $this->db->setFetchMode(DB_FETCHMODE_OBJECT);
    }

    //----------------------------[ godmode ]-----------------------------\\
    // check if a user is the administrator                               \\
    // @return:  true if user has god mode, false otherwise               \\
    function godmode() {
      // change this to return true for administrative mode
      // some options are to check ip address or check for a special cookie
      return false;
    }

    //----------------------------[ fake404 ]-----------------------------\\
    // fakes a page not found error.  this is used by scripts that        \\
    // require some sort of GET variable that is missing, or by scripts   \\
    // only accessible with administrator priveleges.                     \\
    function fake404() {
      header('HTTP/1.0 404 Not Found');
      include $_SERVER['DOCUMENT_ROOT'] . '/404.php';
      die();
    }

    //--------------------------[ querystring ]---------------------------\\
    // builds a querystring from existing http get variables.             \\
    // @param getvars:  the http get variables to include (array format)  \\
    // @param sep:  the separator to use between get variables            \\
    // @return:  a querystring, or an empty string if getvars is empty    \\
    function querystring($getvars, $sep = '&amp;') {
      if(count($getvars) <= 0)
        return '';
      $qs = '';
      foreach($getvars as $var)
        if(isset($_GET[$var]))
          $qs .= $sep . $var . '=' . $_GET[$var];
      return '?' . substr($qs, strlen($sep));
    }

    //--------------------------[ splitquery ]----------------------------\\
    // gets rows for a single page of a query.                            \\
    // @param sql:  the sql query to run.                                 \\
    // @param defshow:  the default number of rows to return.             \\
    // @param defskip:  the default number of rows to skip                \\
    // @param skip:  the index to $_GET to use for 'skip'                 \\
    // @param show:  the index to $_GET to use for 'show'                 \\
    // @param errormsg:  the message to display if an error occurs        \\
    // @param emptymsg:  the message to display if there are no results   \\
    // @param emptyerror:  if set to true, the empty message will be an   \\
    //                     error instead of just information              \\
    // @param numrows:  if set to true, use ->numRows to get count        \\
    // @return:  a query reult, which may be an error.                    \\
    function splitquery($sql, $defshow, $defskip = 0, $skip = '', $show = '', $errormsg = null, $emptymsg = null, $emptyerror = false, $numrows = false) {
      global $layout;
      if(strlen($skip) <= 0) $skip = 'skip';
      if(strlen($show) <= 0) $show = 'show';
      $this->split_skip = $skip;
      $this->split_show = $show;
      $this->split_dskip = $defskip;
      $this->split_dshow = $defshow;
      if($numrows)
        $this->split_count = $this->query($sql);
      else {
        $this->split_count = 'select count(1)' . stristr($sql, ' from ');
        $this->split_count = $this->getOne($this->split_count);
      }
      if(DB::isError($this->split_count)) {
        if($errormsg === null || !isset($layout))
          return $this->split_count;
        $layout->error($errormsg . $this->split_count->getMessage());
        return false;
      }
      if($numrows)
        $this->split_count = $this->split_count->numRows();
      if(!isset($_GET[$show]))
        $_GET[$show] = $defshow;
      if($defskip === 'last')
        $defskip = $this->split_count - ($this->split_count % $_GET[$show] ? $this->split_count % $_GET[$show] : $_GET[$show]);
      if($defskip < 1) $defskip = 0;
      if(!isset($_GET[$skip]))
        $_GET[$skip] = $defskip;
      if(!isset($layout) || $errormsg === null && $emptymsg === null)
        return $this->limitQuery($sql, $_GET[$skip], $_GET[$show]);
      $query = $this->limitQuery($sql, $_GET[$skip], $_GET[$show]);
      if(DB::isError($query)) {
        if($errormsg === null)
          return $query;
        $layout->error($errormsg . $query->getMessage());
        return false;
      }
      if($query->numRows() <= 0) {
        if($emptymsg === null)
          return $query;
        if($emptyerror)
          $layout->error($emptymsg);
        else
          $layout->info($emptymsg);
        return false;
      }
      return $query;
    }

// the rest are all wrapped functions from PEAR::DB -- see PEAR documentation for details
    function getOne($sql, $errormsg = null) {
      global $layout;
      if(!isset($this->db))
        $this->connect();
      $this->num_queries++;
      if(!isset($layout) || $errormsg === null)
        return $this->db->getOne($sql);
      $query = $this->db->getOne($sql);
      if(!DB::isError($query))
        return $query;
      $layout->error($errormsg . $query->getMessage());
      return false;
    }

    function query($sql, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      global $layout;
      if(!isset($this->db))
        $this->connect();
      $this->num_queries++;
      if(!isset($layout) || $errormsg === null && $emptymsg === null)
        return $this->db->query($sql);
      $query = $this->db->query($sql);
      if(DB::isError($query)) {
        if($errormsg === null)
          return $query;
        $layout->error($errormsg . $query->getMessage());
        return false;
      }
      if(strtolower(substr($sql, 0, 6)) == 'select' && $query->numRows() <= 0) {
        if($emptymsg === null)
          return $query;
        if($emptyerror)
          $layout->error($emptymsg);
        else
          $layout->info($emptymsg);
        return false;
      }
      return $query;
    }

    function limitQuery($sql, $start, $limit, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      global $layout;
      if(!isset($this->db))
        $this->connect();
      $this->num_queries++;
      if(!isset($layout) || $errormsg === null && $emptymsg === null)
        return $this->db->limitQuery($sql, $start, $limit);
      $query = $this->db->limitQuery($sql, $start, $limit);
      if(DB::isError($query)) {
        if($errormsg === null)
          return $query;
        $layout->error($errormsg . $query->getMessage());
        return false;
      }
      if($query->numRows() <= 0) {
        if($emptymsg === null)
          return $query;
        if($emptyerror)
          $layout->error($emptymsg);
        else
          $layout->info($emptymsg);
        return false;
      }
      return $query;
    }

    function nextId($sequence, $errormsg = null) {
      global $layout;
      if(!isset($this->db))
        $this->connect();
      $this->num_queries++;
      if(!isset($layout) || $errormsg === null)
        return $this->db->nextId($sequence);
      $query = $this->db->nextId($sequence);
      if(!DB::isError($query))
        return $query;
      $layout->error($errormsg . $query->getMessage());
      return false;
    }
  }
  
  // create the $engine object
  $engine = new ENGINE;

/*----------------------------------------------------------------------------*\
 | title:    get / post / cookie function library                             |
 | purpose:  a collection of functions for use with user-entered data (such   |
 |           as data coming from get, post, or cookies).                      |
 | notes:    all functions may be called statically.  see the individual      |
 |           functions for more details on what they do.                      |
\*----------------------------------------------------------------------------*/
  class GPC {

    //-----------------------------[ slash ]------------------------------\\
    // this function is used instead of addslashes() in order to make     \\
    // sure that we don't add slashes if magic_quotes_gpc is on.          \\
    // @param text:  the text to (possibly) add slashes to                \\
    // @return:  the text, ready to be used in a mysql query              \\
    function slash($text) {
      return get_magic_quotes_gpc() ? $text : addslashes($text);
    }

    //----------------------------[ unslash ]-----------------------------\\
    // this function is used instead of stripslashes() in order to make   \\
    // sure that we only strip slashes if magic_quotes_gpc is on.         \\
    // @param text:  the text to (possibly) strip slashes from            \\
    // @return:  the text, ready to be echoed as html                     \\
    function unslash($text) {
      return get_magic_quotes_gpc() ? stripslashes($text) : $text;
    }
  }


/*----------------------------------------------------------------------------*\
 | title:    size function library                                            |
 | purpose:  provides functions to easily get file or image sizes.            |
 | notes:    all functions should be called statically.  see the individual   |
 |           functions for more details on what they do.                      |
\*----------------------------------------------------------------------------*/
  class SIZE {

    //------------------------------[ file ]------------------------------\\
    // gives the size of a file in an easy-to-read format.                \\
    // @param thefile:  the file to find the size of                      \\
    // @return:  nicely formatted file size, or file not found if no file \\
    function file($thefile) {
      $kb = 1024;
      $mb = 1024 * $kb;
      if(!file_exists($thefile))
        return 'file not found';
      $size = filesize($thefile);
      if ($size > 2 * $mb) {
        $size = round($size / $mb, 1) . ' megs';
      } elseif($size > 2 * $kb) {
        $size = round($size / $kb, 1) . ' k';
      } else {
        $size .= ' bytes';
      }
      return $size;
    }

    //-----------------------------[ image ]------------------------------\\
    // gives the pixel and file size of an image in an easy-to-read       \\
    // format.                                                            \\
    // @param theimage:  the image to find the size of                    \\
    // @return:  nice-format image size, or file not found if no file     \\
    function image($theimage) {
      $kb = 1024;
      $mb = $kb * $kb;
      if(!file_exists($theimage))
        return 'image file not found';
      list($width, $height) = getimagesize($theimage);
      return $width . ' x ' . $height . ' pixels, ' . SIZE::file($theimage);
    }

    //----------------------------[ imagecss ]----------------------------\\
    // gives the css style="" string for an image.                        \\
    // @param url:  the image to get the css string for                   \\
    // @return:  css style width and height of the image, or empty string \\
    function imagecss($url) {
      if(file_exists($url)) {
        $res = getimagesize($url);
        return 'style="width: ' . $res[0] . 'px; height: ' . $res[1] . 'px;" ';
      }
      return '';
    }
  }


/*----------------------------------------------------------------------------*\
 | title:    url function library                                             |
 | purpose:  provides functions to manipulate urls.                           |
 | notes:    all functions should be called statically.  see the individual   |
 |           functions for more details on what they do.                      |
\*----------------------------------------------------------------------------*/
  class URL {
    
    //-----------------------------[ strip ]------------------------------\\
    // strips both the querystring and any index.* from the end of a url. \\
    // @param url:  the url to strip                                      \\
    // @return:  the url, stripped of index.* and querystring             \\
    function strip($url) {
      return URL::stripindex(URL::stripquery($url));
    }
    
    //---------------------------[ stripquery ]---------------------------\\
    // strips the querystring from the end of a url.                      \\
    // @param url:  the url to strip                                      \\
    // @return:  the url, stripped of querystring                         \\
    function stripquery($url) {
      if($i = strpos($url, '?'))
        return substr($url, 0, $i);
      return $url;
    }

    //---------------------------[ stripindex ]---------------------------\\
    // strips any index.* from the end of a url.                          \\
    // @param url:  the url to strip                                      \\
    // @return:  the url, stripped of index.*                             \\
    function stripindex($url) {
      return preg_replace('/(index\.((p|s)?html?|php3?)|(default\.asp))/i','',$url);
    }

    //----------------------------[ shorten ]-----------------------------\\
    // shortens a url to a given length, with ... inserted in the middle. \\
    // @param url:  the url to shorten                                    \\
    // @param length:  the maximum length of the url                      \\
    // @return:  the url, shortened                                       \\
    function shorten($url, $length) {
      if(strlen($url) > $length + 3)
        return substr($url, 0, $length / 2) . '...' . substr($url, -$length / 2);
      return $url;
    }
  }


/*----------------------------------------------------------------------------*\
 | title:    date function library                                            |
 | purpose:  provides functions to manipulate dates.                          |
 | notes:    all functions should be called statically.  see the individual   |
 |           functions for more details on what they do.                      |
\*----------------------------------------------------------------------------*/
  class DATE {

    //----------------------------[ tomorrow ]----------------------------\\
    // gets the unix timestamp for the day following the day passed in.   \\
    // @param today:  the current day, unix timestamp format              \\
    // @return:  the unix timestamp for the day after $today              \\
    function tomorrow($today) {
      return strtotime(date('Y-m-d',$today + 115200));  // 32 hours--helps for daylight savings
    }

    //---------------------------[ formatday ]----------------------------\\
    // formats a date.                                                    \\
    // @param d:  the date which should be formatted -- yyyy-mm-dd        \\
    // @param fmt:  the format to use (see php date function)             \\
    // @return:  a lowercase, formatted date                              \\
    function formatday($d, $fmt) {
      return strtolower(date($fmt, strtotime($d)));
    }

    //--------------------------[ formatmonth ]---------------------------\\
    // formats a month.                                                   \\
    // @param m:  the month which should be formatted -- yyyy-mm          \\
    // @param fmt:  the format to use (see php date function)             \\
    // @return:  a lowercase, formatted date                              \\
    function formatmonth($m, $fmt) {
      return strtolower(date($fmt, strtotime($m . '-01')));
    }

    //--------------------------[ daysinmonth ]---------------------------\\
    // gets the number of days in a month.                                \\
    // @param month:  the month -- yyyy-mm                                \\
    // @return:  the number of days in the month                          \\
    function daysinmonth($month) {
      list($y, $m) = explode($month, '-', 2);  // split out the year and month
      $y += 0;
      $m += 0;
      switch($m) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
          return 31;
          break;
        case 4:
        case 6:
        case 9:
        case 11:
          return 30;
          break;
        case 2:
          // for february we need to look at leap year
          return $y % 4 ? ($y % 100 ? ($y % 400 ? 29 : 28) : 29) : 28;
          break;
      }
    }
  }
?>
