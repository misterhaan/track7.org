<?
  // used to connect to the database -- MODIFY THESE TO YOUR CORRECT VALUES
  define('_DB_ENGINE', 'mysql');
  define('_DB_USER', 'username');
  define('_DB_PASS', 'password');
  define('_DB_HOST', 'localhost');
  define('_DB_NAME', 'database');

  // field types for forms
  define('_FORM_NORMAL', 0);
  define('_FORM_MULTILINE', 1);
  define('_FORM_PASSWORD', 2);
  define('_FORM_CHECKBOX', 3);
?>
