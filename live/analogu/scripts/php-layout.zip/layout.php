<?
/**==========================================================================**\
 ||  this file contains the following classes:                               ||
 ||    instantiable:  LAYOUT, FORM                                           ||
 ||    static:                                                               ||
\**==========================================================================**/


/*----------------------------------------------------------------------------*\
 | title:    track7 layout                                                    |
 | purpose:  handles all the common front-end stuff for the site.  when this  |
 |           file is required or included it creates an object $layout from   |
 |           the LAYOUT class defined in this file.  it will also require     |
 |           t7engine.php which creates the $engine object.                   |
 | notes:    all functions should be called through the $layout object.  see  |
 |           the individual functions for more details on what they do.       |
\*----------------------------------------------------------------------------*/

  class LAYOUT {
    var $started;    // set to false until start() has been called, at which point it is set to true
    var $ended;      // set to false until end() has been called, at which point it is set to true
    var $errortext;  // error text to be written once the page starts
    var $infotext;   // info text to be written once the page starts

    //-----------------------------[ LAYOUT ]-----------------------------\\
    // the constructor makes sure we have $engine set up.  also clears    \\
    // the started flag and sets the ended flag.                          \\
    function LAYOUT() {
      global $engine;
      require_once 'engine.php';
      $this->started = false;
      $this->ended = true;
    }

    //-----------------------------[ error ]------------------------------\\
    // displays an error message.  if the page hasn't been started yet,   \\
    // the message is saved and displayed then.                           \\
    // @param message:  the error message to display                      \\
    function error($message) {
      if(strlen($message) <= 0) return;
      if($this->started)
        echo '      <p class="error">' . $message . '</p>' . "\n\n";
      else
        $this->errortext = $message;  // save it for later
    }

    //------------------------------[ info ]------------------------------\\
    // displays an info message.  if the page hasn't been started yet,    \\
    // the message is saved and displayed then.                           \\
    // @param message:  the info message to display                       \\
    function info($message) {
      if(strlen($message) <= 0) return;
      if($this->started)
        echo '      <p class="info">' . $message . '</p>' . "\n\n";
      else
        $this->infotext = $message;  // save it for later
    }

    //--------------------------[ splitqlinks ]---------------------------\\
    // shows links to further pages if splitquery has been used and there \\
    // are more pages to show.                                            \\
    // @param getvars:  an array of http get variables that should be     \\
    //                  included in the links to be written out           \\
    function splitqlinks($getvars = array()) {
      global $engine;
      if($_GET[$engine->split_skip] !== 0 || $engine->split_count > $_GET[$engine->split_show]) {
        $querystring = $engine->querystring($getvars);
        if(strlen($querystring) > 0)
          $qcontinue = '&amp;';
        else
          $qcontinue = '?';
?>
      <div class="pagelinks">
        page:&nbsp;
<?
        $thispage = round($_GET[$engine->split_skip] / $_GET[$engine->split_show]);
        $pages = round($engine->split_count / $_GET[$engine->split_show] + .49);
        for($page = 0; $page < $pages; $page++)
          if($page == $thispage)
            echo '        <span class="active">' . ($page + 1) . '</span>' . "\n";
          else {
            echo '        <a href="' . $_SERVER['PHP_SELF'] . $querystring;
            $skip = $page * $_GET[$engine->split_show];
            if($skip != $engine->split_dskip) {
              echo $qcontinue . $engine->split_skip . '=' . $skip;
              if($_GET[$engine->split_show] != $engine->split_dshow)
                echo '&amp;' . $engine->split_show . '=' . $_GET[$engine->split_show];
            } elseif($_GET[$engine->split_show] != $engine->split_dshow)
              echo '&amp;' . $engine->split_show . '=' . $_GET[$engine->split_show];
            echo '">' . ($page + 1) . '</a>' . "\n";
          }
?>
      </div>
<?
      }
    }

    //-----------------------------[ start ]------------------------------\\
    // writes out everything needed to start a page.                      \\
    // @param title:  the title to display at the top of the page         \\
    // @param subtitle:  the subtitle to display underneath the title     \\
    // @param pretitle:  the 'subtitle' to display above the title        \\
    // @param windowtitle:  the text that will go inside <title>          \\
    //        (optional -- will use title by default)                     \\
    // @param extrahead:  extra information to put inside <head>          \\
    // @param getvars:  array of important get variables                  \\
    // @param linktext:  an array of titles for links to further down the \\
    //        page -- linked to #$linktext[$i] unless overidden           \\
    // @param linkname:  an array that goes with linktext and overrides   \\
    //        where the link should go                                    \\
    function start($title, $subtitle = '', $pretitle = '', $windowtitle = null, $extrahead = '', $getvars = null, $linktext = null, $linkname = null) {
      global $engine;
      // don't do this again
      if($this->started)
        return;
      $this->started = true;
      // default window title to the title
      if(strlen($windowtitle) < 1)
        $windowtitle = $title;
      if(strpos($windowtitle, 'track7') === false)
        $windowtitle .= ' - track7';
      header('Content-Type: text/html; charset=iso-8859-1');
      header('X-Sven: look out for the fruits of life');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta name="distribution" content="global" />
    <meta name="resource-type" content="document" />
    <meta name="language" content="en" />
    <link rel="stylesheet" href="style.css" type="text/css" />
    <title><?=$windowtitle; ?></title>
<?=$extrahead; ?>
  </head>
  <body>
<?
      // show the title(s), and the major line if there are any titles
      if(strlen($pretitle) > 0)
        echo '      <h1 class="sub">' . $pretitle . '</h1>' . "\n";
      if(strlen($title) > 0)
        echo '      <h1>' . $title . '</h1>' . "\n";
      if(strlen($subtitle) > 0)
        echo '      <h1 class="sub">' . $subtitle . '</h1>' . "\n";
      // show jump links if there are any
      if(count($linktext)) {
?>
      <ul class="elements">
<?
        for($i = 0; $i < count($linktext); $i++)
          echo '        <li><a href="#' . (strlen($linkname[$i]) > 0 ? $linkname[$i] : $linktext[$i]) . '">' . $linktext[$i] . '</a></li>' . "\n";
?>
      </ul>
<?
      }
      if(strlen($pretitle) + strlen($title) + strlen($subtitle) > 0)
        echo '      <hr class="major" />' . "\n\n";
      // show an error if there is one
      if(strlen($this->errortext))
        $this->error($this->errortext);
      // show information if there is any
      if(strlen($this->infotext ))
        $this->info($this->infotext);
      // clear ended flag so that we can end the page
      $this->ended = false;
    }

    //------------------------------[ end ]-------------------------------\\
    // writes out everything needed to end a page                         \\
    function end() {
      global $engine;
      // don't do this again
      if($this->ended)
        return;
?>
  </body>
</html>
<?
      // make sure the page doesn't get ended a second time
      $this->ended = true;
    }

  }

  // create the $layout object
  $layout = new LAYOUT;

  
/*----------------------------------------------------------------------------*\
 | title:    form builder                                                     |
 | purpose:  handles all common tasks for building a track7 form.             |
 | notes:    all functions should be called through a FORM object.  see the   |
 |           individual functions for more details on what they do.           |
\*----------------------------------------------------------------------------*/
  class FORM {
    var $indent;  // a string of spaces, used to make sure the html looks nice

    //------------------------------[ FORM ]------------------------------\\
    // the constructor opens the form tag and saves the indent.           \\
    // @param action:  the script to send the form to -- default is the   \\
    //                 current script                                     \\
    // @param method:  should be either get or post                       \\
    // @param indent:  a string of spaces used to indent the form tag     \\
    // @param id:  the css id to use for the form                         \\
    function FORM($action = null, $method = 'post', $indent = '      ', $id = '') {
      if($action === null)
        $action = $_SERVER['PHP_SELF'];
      echo $indent . '<form action="' . $action . '" method="' . $method . (strlen($id) ? '" id="' . $id : '') . '"><div>' . "\n";
      $this->indent = $indent;
    }

    //------------------------------[ end ]-------------------------------\\
    // closes the form tag, possibly printing out a submit button.        \\
    // @param buttontext:  the value to put on the submit button          \\
    function end($buttontext = '') {
      if(is_array($buttontext)) {
        echo $this->indent . '  <div class="buttons">' . "\n";
        foreach($buttontext as $text)
          echo $this->indent . '    <input type="submit" name="submit" value="' . $text . '" />' . "\n";
        echo $this->indent . '  </div>' . "\n";
      } elseif(strlen($buttontext) > 0)
        echo $this->indent . '  <div class="buttons"><input type="submit" name="submit" value="' . $buttontext . '" /></div>' . "\n";
      echo $this->indent . '</div></form>' . "\n\n";
    }

    //----------------------------[ startset ]----------------------------\\
    // opens a fieldset tag, possibly with a title.                       \\
    // @param title:  the title to display on the top of the fieldset     \\
    // @param class:  the css class to use for the fieldset               \\
    // @param id:  the css id to use for the fieldset                     \\
    function startset($title = '', $class = '', $id = '') {
      if(strlen($class) > 0)
        $class = ' class="' . $class . '"';
      if(strlen($id) > 0)
        $id = ' id="' . $id . '"';
      $this->indent .= '  ';
      echo $this->indent . '<fieldset' . $class . $id . '>' . "\n";
      if(strlen($title) > 0)
        echo $this->indent . '  <legend>' . $title . '</legend>' . "\n";
    }

    //-----------------------------[ endset ]-----------------------------\\
    // ends a fieldset tag, possibly with a submit button.                \\
    // @param buttontext:  the value to put on the submit button          \\
    function endset($buttontext = '') {
      if(is_array($buttontext)) {
        echo $this->indent . '  <div class="buttons">' . "\n";
        foreach($buttontext as $text)
          echo $this->indent . '    <input type="submit" name="submit" value="' . $text . '" />' . "\n";
        echo $this->indent . '  </div>' . "\n";
      } elseif(strlen($buttontext) > 0)
        echo $this->indent . '  <div class="buttons"><input type="submit" name="submit" value="' . $buttontext . '" /></div>' . "\n";
      echo $this->indent . '</fieldset>' . "\n";
      $this->indent = substr($this->indent, 2);
    }

    //-----------------------------[ field ]------------------------------\\
    // adds a field (with a label) to a form.                             \\
    // @param label:  the text to show as a label for this field          \\
    // @param name:  the name to use for this field                       \\
    // @param type:  the type of field this should be                     \\
    // @param default:  the default value for the field                   \\
    // @param maxlen:  the maximum length for the field                   \\
    // @param ovrid:  override the id (default is 'fld' plus the name)    \\
    function field($label, $name, $type = _FORM_NORMAL, $default = '', $maxlen = 0, $ovrid = '') {
      if(strlen($ovrid) < 1)
        $ovrid = 'fld' . $name;
      if($type != _FORM_CHECKBOX) {
        echo $this->indent . '  <label for="' . $ovrid . '">' . $label . '</label>' . "\n";
        switch($type) {
          case _FORM_MULTILINE:
            echo $this->indent . '  <textarea name="' . $name . '" id="' . $ovrid . '" rows="" cols=""' . ($maxlen > 0 ? ' maxlength="' . $maxlen . '"' : '') . (strlen($default) > 0 ? '>' . $default : '>') . '</textarea>' . "\n";
            break;
          case _FORM_PASSWORD:
            echo $this->indent . '  <input name="' . $name . '" id="' . $ovrid . '" type="password" class="field"' . ($maxlen > 0 ? ' maxlength="' . $maxlen . '"' : '') . (strlen($default) > 0 ? ' value="' . $default . '"' : '') . ' />' . "\n";
            break;
          case _FORM_NORMAL:
          default:
            echo $this->indent . '  <input name="' . $name . '" id="' . $ovrid . '" class="field"' . ($maxlen > 0 ? ' maxlength="' . $maxlen . '"' : '') . (strlen($default) > 0 ? ' value="' . $default . '"' : '') . ' />' . "\n";
            break;
        }
      } else {
        echo $this->indent . '  <input type="checkbox" name="' . $name . '" id="' . $ovrid . '" class="checkbox"' . ($default ? ' checked="checked"' : '') . ' />' . "\n";
        echo $this->indent . '  <label for="' . $ovrid . '">' . $label . '</label>' . "\n";
      }
    }

    //------------------------------[ data ]------------------------------\\
    // add hidden data to a form.                                         \\
    // @param name:  the name for this data                               \\
    // @param value:  the value to include                                \\
    function data($name, $value) {
      echo $this->indent . '  <input type="hidden" name="' . $name . '" value="' . $value . '" />' . "\n";
    }

    //-----------------------------[ label ]------------------------------\\
    // prints a form label.                                               \\
    // @param text:  the text to show on the label                        \\
    // @param for:  the field this label belongs to                       \\
    function label($text, $for = '') {
      echo $this->indent . '  <label' . (strlen($for) > 0 ? ' for="fld' . $for . '"' : '') . '>' . $text . '</label>' . "\n";
    }

    //-----------------------------[ input ]------------------------------\\
    // prints a textbox input field.                                      \\
    // @param name:  the name of the field                                \\
    // @param value:  the default value of the field                      \\
    // @param maxlength:  the maximum number of characters to accept      \\
    function input($name, $value = null, $maxlength = null) {
      echo $this->indent . '  <input id="fld' . $name . '" name="' . $name . '" class="field"' . ($maxlength === null ? '' : ' maxlength="' . $maxlength . '"') . ($value === null ? '' : ' value="' . $value . '"') . ' />' . "\n";
    }

    //----------------------------[ password ]----------------------------\\
    // prints a password input field.                                     \\
    // @param name:  the name of the field                                \\
    // @param maxlength:  the maximum number of characters to accept      \\
    function password($name, $maxlength = null) {
      echo $this->indent . '  <input id="fld' . $name . '" name="' . $name . '" class="field" type="password"' . ($maxlength === null ? '' : ' maxlength="' . $maxlength . '"') . ' />' . "\n";
    }

    //-----------------------------[ hidden ]-----------------------------\\
    // adds a hiden field.                                                \\
    // @param name:  the name of the field                                \\
    // @param value:  the value of the field                              \\
    function hidden($name, $value) {
      $this->data($name, $value);
    }

    //----------------------------[ textarea ]----------------------------\\
    // adds a multiline textbox input field.                              \\
    // @param name:  the name of the field                                \\
    // @param value:  the default value of the field                      \\
    // @param maxlength:  the maximum number of characters to accept      \\
    function textarea($name, $value = '', $maxlength = null) {
      echo $this->indent . '  <textarea name="' . $name . '" id="fld' . $name . '"' . ($maxlength !== null ? ' maxlength="' . $maxlength . '"' : '') . ' rows="" cols="">' . $value . '</textarea>' . "\n";
    }

    //-----------------------------[ select ]-----------------------------\\
    // adds a dropdown selection box field.                               \\
    // @param name:  the name of the field                                \\
    // @param values:  array of possible values                           \\
    // @param text:  array of labels for the values                       \\
    // @param default:  the default value for the field                   \\
    function select($name, $values, $text, $default = null) {
      echo $this->indent . '  <select id="fld' . $name . '" name="' . $name . '" class="field">' . "\n";
      for($i = 0; $i < count($values); $i++)
        echo $this->indent . '    <option' . ($values[$i] === $default ? ' selected="selected"' : '') . ($text[$i] === null ? '>' . $values[$i] : ' value="' . $values[$i] . '">' . $text[$i]) . '</option>' . "\n";
      echo $this->indent . '  </select>' . "\n";
    }

    //----------------------------[ checkbox ]----------------------------\\
    // adds a checkbox field.                                             \\
    // @param name:  the name of the field                                \\
    // @param checked:  set to true if the checkbox should be checked     \\
    function checkbox($name, $checked = false) {
      echo $this->indent . '  <input type="checkbox" id="fld' . $name . '" name="' . $name . '" class="checkbox"' . ($checked ? ' checked="checked"' : '') . ' />' . "\n";
    }
  }
?>
