<?
/******************************************************************************\
 * Title:    Timer class
 * Purpose:  Stopwatch functions for timing code execution.
 * History:  0.0.0 - Initial release
\******************************************************************************/

/*===========================================================[ auTimer class ]==
  Create a timer using new auTimer, then check the elapsed time with
  CheckTime() or CheckElapsedTime().
*/
  class auTimer {
    private $begintime;
    private $lasttime;

/*-----------------------------------------------------[ auTimer constructor ]--
  Creates a new timer object and resets the time.
*/
    public function auTimer() {
      $time = explode(' ', microtime());
      $this->begintime = $this->lasttime = $time[0] + $time[1]; 
    }

/*------------------------------------------------[ auTimer.CheckElapsedTime ]--
  Checks the time since the timer was last checked.
  @return = Elapsed time in seconds.
*/
    public function CheckElapsedTime() {
      $time = microtime(true);
      $last = $this->lasttime;
      $this->lasttime = $time;
      return $this->lasttime - $last;
    }

/*-------------------------------------------------------[ auTimer.CheckTime ]--
  Checks the time since the timer was created.
  @return = Elapsed time in seconds.
*/
    public function CheckTime() {
      $this->lasttime = microtime(true);
      return $this->lasttime - $this->begintime;
    }
  }
?>