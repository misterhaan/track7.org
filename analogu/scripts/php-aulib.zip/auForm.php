<?
/******************************************************************************\
 * Title:    Form class
 * Purpose:  Builds form objects that can be used to output HTML and validate
 *           user input.  Also attempts to fool spammers using a couple 
 *           methods which should be undetectable to actual people.
 * History:  0.0.0 - Initial release
\******************************************************************************/

  // options for AddField $type
  define('_AU_FORM_FIELD_NORMAL', 0);
  define('_AU_FORM_FIELD_NUMERIC', 1);
  define('_AU_FORM_FIELD_INTEGER', 2);
  define('_AU_FORM_FIELD_DATETIME', 3);
  define('_AU_FORM_FIELD_MULTILINE', 4);
  define('_AU_FORM_FIELD_BBCODE', 5);
  define('_AU_FORM_FIELD_PASSWORD', 6);
  define('_AU_FORM_FIELD_CHECKBOX', 7);
  define('_AU_FORM_FIELD_FILE', 8);

  // options for AddSelect $type
  define('_AU_FORM_SELECT_DROPDOWN', 0);
  define('_AU_FORM_SELECT_RADIO', 1);

  // options for AddMultiSelect $type
  define('_AU_FORM_MULTI_LIST', 0);
  define('_AU_FORM_MULTI_CHECK', 1);

/*============================================================[ auForm class ]==
  Create a form using new auForm, then build it using AddFieldSet, AddData,
  AddText, AddField, AddSelect, AddMultiSelect, and AddButtons.
  Check Submitted() to see if the form was submitted, or to find out which
  submit button was used.
  Use CheckInput() to automatically validate fields.
  Use WriteHTML() to write out HTML code for the form.  If any errors were
  found during CheckInput(), they will display above the problematic field.
*/
  class auForm {
    private $id;
    private $action;
    public $method;
    private $elements;
    private $hasfile;
    private $submit;

    // variables for display
    public $indent;
    public $intable;
    private $firstfield;

    private $error;

/*------------------------------------------------------[ auForm constructor ]--
  Creates a new form object.
  $id = CSS id of the form element.  Also the value of formid data field.
  $action = Script to send form data to.  Defaults to the current page.
  $method = How to send form data.  Defaults to HTTP POST -- can be overridden
    to GET.
*/
    public function auForm($id, $action = null, $method = 'post') {
      $this->id = $id;
      if($action)
        if(substr($action, 0, 1) == '?')
          $this->action = $_SERVER['PHP_SELF'] . $action;
        else
          $this->action = $action;
      else
        $this->action = $_SERVER['PHP_SELF'];
      $this->method = $method;
      $this->hasfile = false;
      if($this->id)
        $this->AddData('formid', $id);
      $this->error = false;
    }

/*------------------------------------------------------[ auForm.AddFieldSet ]--
  Adds a fieldset to the form.
  $fieldset = An auFormFieldSet object, with all of its elements already added.
*/
    public function AddFieldSet(&$fieldset) {
      $this->elements[] = $fieldset;
      if(!$this->submit && $fieldset->submit)
        $this->submit = $fieldset->submit;
      if(!$this->hasfile && $fieldset->hasfile)
        $this->hasfile = true;
    }

/*----------------------------------------------------------[ auForm.AddData ]--
  Adds data to the form that will not display but will be submitted.
  $name = Name to submit the data as.
  $value = Value of the data.
*/
    public function AddData($name, $value) {
      $d = new auFormData($name, $value);
      $this->elements[] = $d;
      return $d;
    }

/*----------------------------------------------------------[ auForm.AddText ]--
  Adds text to the form that will display but will not be submitted.
  $title = Title of the text, which displays like a field label.
  $text = The text to display.
*/
    public function AddText($title, $text) {
      $t = new auFormText($title, $text);
      $this->elements[] = $t;
      return $t;
    }

/*----------------------------------------------------------[ auForm.AddHTML ]--
  Adds html to the form that will display but will not be submitted.
  $title = Title of the text, which displays like a field label.
  $html = The html to display.
*/
    public function AddHTML($title, $html) {
      $h = new auFormHTML($title, $html);
      $this->elements[] = $h;
      return $h;
    }

/*---------------------------------------------------------[ auForm.AddField ]--
  Adds a field to the form.
  $name = Name to submit the field as.
  $label = Label to display with the field.
  $tooltip = Tooltip text to display when the mouse is over the label.  For
    checkbox fields, the tooltip displays next to the checkbox itself.
  $required = Whether a value is required in this field.
  $default = Default value for this field.
  $type = Type of field.
  $width = Width of the field in characters.
  $maxlength = The maximum number of characters the field can accept.
*/
    public function AddField($name, $label = '', $tooltip = '', $required = false, $default = '', $type = _AU_FORM_FIELD_NORMAL, $width = 0, $maxlength = 0) {
      if($type == _AU_FORM_FIELD_FILE)
        $this->hasfile = true;
      $f = new auFormField($name, $label, $tooltip, $required, $default, $type, $width, $maxlength);
      $this->elements[] = $f;
      return $f;
    }

/*--------------------------------------------------------[ auForm.AddSelect ]--
  Adds a one-value selection field to the form.
  $name = Name to submit the field as.
  $label = Label to display with the field.
  $tooltip = Tooltip text to display when the mouse is over the label.
  $values = Associative array of possible values (value => display text).
  $default = Default value for this field.
  $type = Type of field -- set to _AU_FORM_SELECT_RADIO to use radio buttons.
*/
    public function AddSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_SELECT_DROPDOWN) {
      $s = new auFormSelect($name, $label, $tooltip, $values, $default, $type);
      $this->elements[] = $s;
      return $s;
    }

/*---------------------------------------------------[ auForm.AddMultiSelect ]--
  Adds a multiple-value selection field to the form.
  $name = Name to submit the field as.
  $label = Label to display with the field.
  $tooltip = Tooltip text to display when the mouse is over the label.
  $values = Associative array of possible values (value => display text).
  $default = Array of default values for this field.
  $type = Type of field -- set to _AU_FORM_MULTI_LIST to use list box.
*/
    public function AddMultiSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_MULTI_CHECK) {
      $ms = new auFormMultiSelect($name, $label, $tooltip, $values, $default, $type);
      $this->elements[] = $ms;
      return $ms;
    }

/*-------------------------------------------------------[ auForm.AddButtons ]--
  Adds submit buttons to the form.
  $text = Text to display on the button.  Pass an array to have multiple
    buttons on one line.
  $tooltip = Tooltip text to display when the mouse is over the button.  Pass
    an array parallel to $text if $text was an array.
  $name = Name that should be used for the button.  Must be the same for all
    buttons.  Default is submit.
*/
    public function AddButtons($text, $tooltip = '', $name = 'submit') {
      $this->submit = $name;
      $b = new auFormButtons($text, $tooltip, $name);
      $this->elements[] = $b;
      return $b;
    }

/*--------------------------------------------------------[ auForm.WriteHTML ]--
  Writes out the form in HTML format.  If any fields have failed their check,
    error messages will be displayed above the field.
  $trusted = Whether the submitter is trusted.  This essentially disables
    anti-spam measures and is intended to be set true for logged-in users.
  $indent = A string of white space to help line the form up with the rest of
    the HTML.
*/
    public function WriteHTML($trusted = false, $indent = '      ') {
      echo $indent . '<form id="frm' . $this->id . '" method="' . htmlspecialchars($this->method) . '" action="' . htmlspecialchars($this->action);
      if($this->hasfile)
        echo '" enctype="multipart/form-data';
      echo '"><div>' . "\n";
      if($this->error)
        echo $indent . '  <p class="error">' . $this->error . "</p>\n";
      $this->indent = $indent . '  ';
      if(!$trusted && strtolower($this->method) != 'get') {
        echo $this->indent . '<input type="text" name="website" value="DO NOT CHANGE THIS" />' . "\n";
        echo $this->indent . '<textarea name="comment"></textarea>' . "\n";
      }
      $this->intable = false;
      if(is_array($this->elements))
        foreach($this->elements as $element)
          $element->WriteHTML($this);
      if($this->intable)
        $this->EndTable();
      $this->indent = substr($this->indent, 2);
      echo $this->indent . "</div></form>\n\n";
    }

/*--------------------------------------------------------[ auForm.Submitted ]--
  Checks if the form has been submitted.
  @return = Text of the button used to submit the form, or false if the form
    was not submitted.
*/
    public function Submitted() {
      if(strtolower($this->method) == 'get') {
        if($_GET['formid'] != $this->id)
          return false;
        if($_GET[$this->submit])
          return $_GET[$this->submit];
        return true;
      }
      if($_POST['formid'] != $this->id)
        return false;
      if($_POST[$this->submit])
        return $_POST[$this->submit];
      return true;
    }

/*-------------------------------------------------------[ auForm.CheckInput ]--
  Checks all the form fields for invalid input.
  $trusted = Whether the submitter is trusted.  This essentially disables
    anti-spam measures and is intended to be set true for logged-in users.
  @return = True if all fields are valid.
*/
    public function CheckInput($trusted = false) {
      if(!$this->Submitted())
        return false;
      $method = strtolower($this->method);
      if(!$trusted && $method != 'get' && ($_POST['website'] != 'DO NOT CHANGE THIS' || $_POST['comment'] != '')) {
        $this->error = 'You changed the secret fields!&nbsp; The first two fields should not display for people and are only meant to fool spambots.';
        return false;
      }
      $ret = true;
      for($i = 0; $i < count($this->elements); $i++)
        if(!$this->elements[$i]->CheckInput($method))
          $ret = false;
      return $ret;
    }

    public function StartTable() {
      echo $this->indent . '<table class="columns" cellspacing="0">' . "\n";
      $this->intable = true;
      $this->firstfield = true;
      $this->indent .= '  ';
    }

    public function EndTable() {
      $this->indent = substr($this->indent, 2);
      echo $this->indent . "</table>\n";
      $this->intable = false;
    }

    public function StartRow($required = false, $th = true) {
      echo $this->indent . '<tr';
      if($this->firstfield || $required) {
        echo ' class="';
        if($this->firstfield)
          echo 'first';
        if($this->firstfield && $required)
          echo ' ';
        if($required)
          echo 'required';
        echo '"';
      }
      if($th)
        echo '><th>';
      else
        echo '>';
      $this->firstfield = false;
    }

    public function EndRow() {
      echo '</td></tr>' . "\n";
    }
  }

/*====================================================[ auFormFieldSet class ]==
*/
  class auFormFieldSet {
    private $title;
    private $id;
    private $class;

    private $elements;
    public $hasfile;
    public $submit;

    public function auFormFieldSet($title= '', $id = '', $class = '') {
      $this->title = $title;
      $this->id = $id;
      $this->class = $class;
    }

    public function AddData($name, $value) {
      $d = new auFormData($name, $value);
      $this->elements[] = $d;
      return $d;
    }

    public function AddText($title, $text) {
      $t = new auFormText($title, $text);
      $this->elements[] = $t;
      return $t;
    }

    public function AddHTML($title, $html) {
      $h = new auFormHTML($title, $html);
      $this->elements[] = $h;
      return $h;
    }

    public function AddField($name, $label = '', $tooltip = '', $required = false, $default = '', $type = _AU_FORM_FIELD_NORMAL, $width = 0, $maxlength = 0) {
      if($type == _AU_FORM_FIELD_FILE)
        $this->hasfile = true;
      $f = new auFormField($name, $label, $tooltip, $required, $default, $type, $width, $maxlength);
      $this->elements[] = $f;
      return $f;
    }

    public function AddSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_SELECT_DROPDOWN) {
      $s = new auFormSelect($name, $label, $tooltip, $values, $default, $type);
      $this->elements[] = $s;
      return $s;
    }

    public function AddMultiSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_MULTI_CHECK) {
      $ms = new auFormMultiSelect($name, $label, $tooltip, $values, $default, $type);
      $this->elements[] = $ms;
      return $ms;
    }

    public function AddButtons($text, $tooltip = '', $name = 'submit') {
      $this->submit = $name;
      $b = new auFormButtons($text, $tooltip, $name);
      $this->elements[] = $b;
      return $b;
    }

    public function WriteHTML(&$form) {
      if($form->intable)
        $form->EndTable();
      echo $form->indent . '<fieldset';
      if($this->id)
        echo ' id="' . htmlspecialchars($this->id) . '"';
      if($this->class)
        echo ' class="' . htmlspecialchars($this->class) . '"';
      echo ">\n";
      $form->indent .= '  ';
      if($this->title)
        echo $form->indent . '<legend>' . htmlspecialchars($this->title) . '</legend>' . "\n";
      if(is_array($this->elements))
        foreach($this->elements as $element)
          $element->WriteHTML($form);
      if($form->intable)
        $form->EndTable();
      $form->indent = substr($form->indent, 2);
      echo $form->indent . '</fieldset>' . "\n";
    }

    public function CheckInput($method) {
      $ret = true;
      for($i = 0; $i < count($this->elements); $i++)
        if(!$this->elements[$i]->CheckInput($method))
          $ret = false;
      return $ret;
    }
  }

/*========================================================[ auFormData class ]==
*/
  class auFormData {
    private $name;
    private $value;

    public function auFormData($name, $value) {
      $this->name = $name;
      $this->value = $value;
    }

    public function WriteHTML(&$form) {
      if($form->intable)
        $form->EndTable();
      echo $form->indent . '<input type="hidden" name="' . htmlspecialchars($this->name) . '" value="' . htmlspecialchars($this->value) . '" />' . "\n";
    }

    public function CheckInput($method) {
      return true;
    }
  }

/*========================================================[ auFormText class ]==
*/
  class auFormText {
    private $title;
    private $text;

    public function auFormText($title, $text) {
      $this->title = $title;
      $this->text = $text;
    }
    
    public function WriteHTML(&$form) {
      if(!$form->intable)
        $form->StartTable();
      $form->StartRow(false);
      echo htmlspecialchars($this->title) . '</th><td>' . htmlspecialchars($this->text);
      $form->EndRow();
    }

    public function CheckInput($method) {
      return true;
    }
  }

/*========================================================[ auFormHTML class ]==
*/
  class auFormHTML {
    private $title;
    private $html;

    public function auFormHTML($title, $html) {
      $this->title = $title;
      $this->html = $html;
    }
    
    public function WriteHTML(&$form) {
      if(!$form->intable)
        $form->StartTable();
      $form->StartRow(false);
      echo htmlspecialchars($this->title) . '</th><td>' . $this->html;
      $form->EndRow();
    }

    public function CheckInput($method) {
      return true;
    }
  }

/*=======================================================[ auFormField class ]==
*/
  class auFormField {
    private $name;
    private $label;
    private $tooltip;
    private $required;
    private $default;
    public $type;
    private $width;
    private $maxlength;
    private $error;

    public function auFormField($name, $label = '', $tooltip = '', $required = false, $default = '', $type = _AU_FORM_FIELD_NORMAL, $width = 0, $maxlength = 0) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->required = $required;
      $this->default = $default;
      $this->type = $type;
      if(is_numeric($width))
        $this->width = $width;
      else
        $this->width = 0;
      if(is_numeric($maxlength))
        $this->maxlength = $maxlength;
      else
        $this->maxlength = 0;
      $this->error = false;
    }

    public function WriteHTML(&$form) {
      if(!$form->intable)
        $form->StartTable();
      $form->StartRow($this->required);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      if($form->Submitted())
        if(strtolower($form->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      switch($this->type) {
        case _AU_FORM_FIELD_NORMAL:
        case _AU_FORM_FIELD_NUMERIC:
        case _AU_FORM_FIELD_INTEGER:
        case _AU_FORM_FIELD_DATETIME:
          echo '</th><td>';
          if($this->error)
            echo '<p class="error">' . $this->error . '</p>';
          echo '<input type="text" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
          if($this->width)
            echo '" size="' . $this->width;
          if($this->maxlength)
            echo '" maxlength="' . $this->maxlength;
          if($default)
            echo '" value="' . htmlspecialchars($default);
          echo '" />';
          break;
        case _AU_FORM_FIELD_MULTILINE:
          echo '</th><td>';
          if($this->error)
            echo '<p class="error">' . $this->error . '</p>';
          echo '<textarea id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '" rows="12" cols="';
          if($this->width)
            echo $this->width;
          else
            echo 70;
          if($this->maxlength)
            echo '" maxlength="' . $this->maxlength;
          echo '">' . htmlspecialchars($default) . '</textarea>';
          break;
        case _AU_FORM_FIELD_BBCODE:
          // DO:  put in bbcode buttons
          echo '</th><td>';
          if($this->error)
            echo '<p class="error">' . $this->error . '</p>';
          echo '<textarea id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '" rows="12" cols="';
          if($this->width)
            echo $this->width;
          else
            echo 70;
          if($this->maxlength)
            echo '" maxlength="' . $this->maxlength;
          echo '">' . htmlspecialchars($default) . '</textarea>';
          break;
        case _AU_FORM_FIELD_PASSWORD:
          echo '</th><td>';
          if($this->error)
            echo '<p class="error">' . $this->error . '</p>';
          echo '<input type="password" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
          if($this->width)
            echo '" size="' . $this->width;
          if($this->maxlength)
            echo '" maxlength="' . $this->maxlength;
          echo '" />';
          break;
        case _AU_FORM_FIELD_CHECKBOX:
          echo $label . '</th><td><input type="checkbox" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '" value="' . htmlspecialchars($this->name);
          if($default)
            echo '" checked="checked';
          echo '" /> ';
          if($this->tooltip)
            echo '<label for="fld' . htmlspecialchars($this->name) . '">' . htmlspecialchars($this->tooltip) . '</label>';
          break;
        case _AU_FORM_FIELD_FILE:
          echo '</th><td><input type="file" id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name);
          if($this->width) 
            echo '" size="' . $this->width;
          echo '" />';
          break;
      }
      $form->EndRow();
    }

    public function CheckInput($method) {
      if($method == 'get') {
        if(isset($_GET[$this->name]))
          $_GET[$this->name] = trim($_GET[$this->name]);
      } elseif(isset($_POST[$this->name]))
        $_POST[$this->name] = trim($_POST[$this->name]);
      if($this->required && $this->type != _AU_FORM_FIELD_CHECKBOX && $this->type != _AU_FORM_FIELD_FILE)
        if($method == 'get' && !$_GET[$this->name] || !$_POST[$this->name]) {
          $this->error = 'This field is required.';
          return false;
        }
      if($this->type == _AU_FORM_FIELD_NUMERIC || $this->type == _AU_FORM_FIELD_INTEGER) {
        if($method == 'get' && strlen($_GET[$this->name]) && !is_numeric($_GET[$this->name]) || strlen($_POST[$this->name]) && !is_numeric($_POST[$this->name])) {
          $this->error = 'This field requires a numeric value.';
          return false;
        }
        if($this->type == _AU_FORM_FIELD_INTEGER)
          if($method == 'get')
            $_GET[$this->name] = round($_GET[$this->name]);
          else
            $_POST[$this->name] = round($_POST[$this->name]);
      }
      return true;
    }
  }

/*======================================================[ auFormSelect class ]==
*/
  class auFormSelect {
    private $name;
    private $label;
    private $tooltip;
    private $values;
    private $default;
    private $type;
    private $error;

    public function auFormSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_SELECT_DROPDOWN) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->values = $values;
      $this->default = htmlspecialchars($default);
      $this->type = $type;
      $this->error = false;
    }

/*-------------------------------------------------[ auFormSelect.ArrayIndex ]--
  Takes an numeric-indexed array and turns it into an associative array where
  each element's index is the same as the element's value.  This is helpful
  for the values parameter when the actual values should be displayed.
  $array = Numeric-indexed array to convert.
  @return = Associative array.
*/
    public static function ArrayIndex($array) {
      foreach($array as $item)
        $ret[$item] = null;
      return $ret;
    }

    public function WriteHTML(&$form) {
      if(!$form->intable)
        $form->StartTable();
      $form->StartRow();
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      echo '</th><td>';
      if($this->error)
        echo '<p class="error">' . $this->error . '</p>';
      if($form->Submitted())
        if(strtolower($form->method) == 'get')
          $default = $_GET[$this->name];
        else
          $default = $_POST[$this->name];
      else
        $default = $this->default;
      switch($this->type) {
        case _AU_FORM_SELECT_DROPDOWN:
          echo '<select id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '">' . "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              echo $form->indent . '  <option';
              if($default == $value)
                echo ' selected="selected"';
              if($text)
                echo ' value="' . htmlspecialchars($value) . '">' . htmlspecialchars($text);
              else
                echo '>' . htmlspecialchars($value);
              echo '</option>' . "\n";
            }
          echo $form->indent . '</select>';
          break;
        case _AU_FORM_SELECT_RADIO:
          echo "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              echo $form->indent . '  <div><input type="radio" name="' . htmlspecialchars($this->name) . '" value="' . htmlspecialchars($value) . '" id="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value);
              if($default == $value)
                echo '" checked="checked';
              echo '" /><label for="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value) . '">';
              if($text)
                echo htmlspecialchars($text);
              else
                echo htmlspecialchars($value);
              echo "</label></div>\n";
            }
          echo $form->indent;
          break;
      }
      $form->EndRow();
    }

    public function CheckInput($method) {
      if(method == 'get' && !array_key_exists($_GET[$this->name], $this->values) || !array_key_exists($_POST[$this->name], $this->values)) {
        $this->error = 'One of the options must be selected.';
        return false;
      }
      return true;
    }
  }
  
/*=================================================[ auFormMultiSelect class ]==
*/
  class auFormMultiSelect {
    private $name;
    private $label;
    private $tooltip;
    private $values;
    private $default;
    private $type;

    public function auFormMultiSelect($name, $label = '', $tooltip = '', $values = '', $default = null, $type = _AU_FORM_MULTI_CHECK) {
      $this->name = $name;
      $this->label = $label;
      $this->tooltip = $tooltip;
      $this->values = $values;
      $this->default = $default;
      $this->type = $type;
    }

    public function WriteHTML(&$form) {
      if(!$form->intable)
        $form->StartTable();
      $form->StartRow(false);
      if($this->label) {
        echo '<label for="fld' . htmlspecialchars($this->name);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '">' . htmlspecialchars($this->label) . '</label>';
      }
      switch($this->type) {
        case _AU_FORM_MULTI_LIST:
          if($form->Submitted())
            if(strtolower($form->method) == 'get')
              $default = $_GET[$this->name];
            else
              $default = $_POST[$this->name];
          else
            $default = $this->default;
          echo '</th><td><select id="fld' . htmlspecialchars($this->name) . '" name="' . htmlspecialchars($this->name) . '[]" size="';
          if(count($this->values) > 7)
            echo 7;
          else
            echo count($this->values);
          echo '" multiple="multiple">' . "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              echo $form->indent . '  <option';
              if(in_array($value, $default))
                echo ' selected="selected"';
              if($text)
                echo ' value="' . htmlspecialchars($value) . '">' . htmlspecialchars($text);
              else
                echo '>' . htmlspecialchars($value);
              echo '</option>' . "\n";
            }
          echo $form->indent . '</select>' . "\n";
          break;
        case _AU_FORM_MULTI_CHECK:
          if($form->Submitted())
            if(strtolower($form->method) == 'get') {
              foreach($this->values as $value => $text)
                if($_GET[$this->name . '_' . $value])
                  $default[] = $value;
            } else {
              foreach($this->values as $value => $text)
                if($_POST[$this->name . '_' . $value])
                  $default[] = $value;
            }
          else
            $default = $this->default;
          echo '</th><td>' . "\n";
          if(is_array($this->values))
            foreach($this->values as $value => $text) {
              echo $form->indent . '  <div><input type="checkbox" name="' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value) . '" value="' . htmlspecialchars($value) . '" id="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value);
              if(is_array($default) && in_array($value, $default))
                echo '" checked="checked';
              echo '" /><label for="fld' . htmlspecialchars($this->name) . '_' . htmlspecialchars($value) . '">';
              if($text)
                echo htmlspecialchars($text);
              else
                echo htmlspecialchars($value);
              echo "</label></div>\n";
            }
          echo $form->indent;
          break;
      }
      $form->EndRow();
    }

    public function CheckInput($method) {
      return true;
    }
  }

/*=====================================================[ auFormButtons class ]==
*/
  class auFormButtons {
    private $text;
    private $tooltip;
    private $name;

    public function auFormButtons($text, $tooltip = '', $name = 'submit') {
      $this->text = $text;
      $this->tooltip = $tooltip;
      $this->name = $name;
    }

    public function WriteHTML(&$form) {
      if(!$form->intable)
        $form->StartTable();
      $form->StartRow(false, false);
      echo '<td></td><td>';
      if(is_array($this->text)) {
        echo "\n";
        for($i = 0; $i < count($this->text); $i++) {
          echo $form->indent . '  <input type="submit" name="' . $this->name . '" value="' . htmlspecialchars($this->text[$i]);
          if($this->tooltip[$i])
            echo '" title="' . htmlspecialchars($this->tooltip[$i]);
          echo '" />' . "\n";
        }
        echo $form->indent;
      } else {
        echo '<input type="submit" name="' . $this->name . '" value="' . htmlspecialchars($this->text);
        if($this->tooltip)
          echo '" title="' . htmlspecialchars($this->tooltip);
        echo '" />';
      }
      $form->EndRow();
    }

    public function CheckInput($method) {
      return true;
    }
  }
?>
