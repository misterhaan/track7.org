<?
/******************************************************************************\
 * Title:    Text class
 * Purpose:  Static class grouping together functions dealing with text.
 * History:  0.0.0 - Initial release
\******************************************************************************/

  if(!defined('_HOST')) {  // used to strip the local domain off link URLs
    list($host) = split(':', strtolower($_SERVER['HTTP_HOST']), 2);  // put domain in lowercase, and strip off port number if there is one
    $host = preg_replace('/^(web|www[0-9]*|secure)\./', '', $host);  // remove the www. if there is one, so that the same cookie will work for both with and without the www
    define('_HOST', $host);
    unset($host);
  }

/*============================================================[ auText class ]==
  auText is a static class -- all functions should be called using
  auText::function.
*/
  class auText {

/*------------------------------------------------------------[ auText.YesNo ]--
  Translates a true/false value into yes/no.
  $bool = True/false value to translate.
  @return = Yes or no.
*/
    public static function YesNo($bool) {
      return $bool ? 'yes' : 'no';
    }

/*----------------------------------------------------------[ auText.FixLink ]--
  Takes a contact address (e-mail or website) and forms it into a valid URL.
  $link = User-entered contact address.
  $htmlspecialchars = If false, the return value will not be made safe for HTML.
  @return = Contact address formed into a valid URL.
*/
    public static function FixLink($link, $htmlspecialchars = true) {
      if(strlen($link) <= 0)
        return '';
      if($htmlspecialchars)
        $link = htmlspecialchars($link);
      if(substr($link, 0, 1) == '/')  // links to the root of this site are okay
        return $link;
      if(substr($link, 0, 7) != 'mailto:' && strpos($link, '//') === false)
        if(strpos($link, '@') !== false)
          return 'mailto:' . $link;
        else
          $link = 'http://' . $link;
      return preg_replace('/^https?:\/\/((web|www[0-9]*|secure)\.)?' . str_replace('.', '\.', _HOST) . '/i', '', $link);
    }

/*---------------------------------------------------------[ auText.StripURL ]--
  Strips both the querystring and any index.* from the end of a URL.
  $url = URL to strip.
  @return = URL with querystring and index.* removed.
*/
    public static function StripURL($url) {
      return auText::StripIndex(auText::StripQuery($url));
    }

/*-------------------------------------------------------[ auText.StripQuery ]--
  Strips the querystring from the end of a URL.
  $url = URL to strip.
  @return = URL with querystring removed.
*/
    public static function StripQuery($url) {
      $url = explode('?', $url);
      return $url[0];
    }

/*-------------------------------------------------------[ auText.StripIndex ]--
  Strips any index.* from the end of a URL.
  $url = URL to strip.
  @return = URL with index.* removed.
*/
    public static function StripIndex($url) {
      return preg_replace('/(index\.((p|s)?html?|php3?)|(default\.asp))/i', '', $url);
    }

/*--------------------------------------------------------[ auText.SafeEmail ]--
  Takes an e-mail address and randomly chooses an obfuscation method to avoid
  spambot harvests.
  $email = E-mail address to obfuscate.
  @return = Obfuscated e-mail address.
*/
    public static function SafeEmail($email) {
      if(!preg_match('/(.+)@(.*?)\.(.+)/', $email, $mailarr))
        return $email;
      if($extratext = rand(0,1)) {
        $specific = array(
          'EINSTEIN',
          'SOCRATES',
          'LINCOLN',
          'CARROT',
          'ZEBRA',
          'POLAND'
        );
        $general = array(
          'physicist',
          'philosopher',
          'ex-president',
          'vegetable',
          'animal',
          'country'
        );
        $index = rand(0, count($specific) - 1);
        $char = round(strlen($mailarr[2]) / 2);
        $mailarr[2] = substr($mailarr[2], 0, $char) . $specific[$index] . substr($mailarr[2], $char);
        $mailarr[3] .= ' minus ' . $general[$index];
      }
      if(!$extratext || rand(0,1))
        return $mailarr[1] . '{at}' . $mailarr[2] . '[DOT]' . $mailarr[3];
      return $mailarr[1] . '@' . $mailarr[2] . '.' . $mailarr[3];
    }

/*----------------------------------------------------------[ auText.EOL2pbr ]--
  Converts end-of-line (EOL) characters to HTML equivalents of p and br tags.
  It is assumed that the end result will be contained within a p tag.  It
  properly recognizes the three EOL forms of \r\n, \r, and \n.  Multiple
  spaces are converted to a non-breaking space followed by a normal space.  An
  odd number of spaces greater than 2 will get rounded down to the next even
  number of spaces.
  $text = User-entered text that may contain EOL characters or multiple spaces.
  @return = Text converted to HTML.
*/
    public static function EOL2pbr($text) {
      return str_replace(array("\r\n", "\n", "\r"), '<br />',
             str_replace(array("\r\n\r\n", "\n\n", "\r\r"), '</p><p>',
             str_replace('  ', '&nbsp; ', $text)));
    }

/*-----------------------------------------------------------[ auText.EOL2br ]--
  Converts end-of-line (EOL) characters to HTML equivalent of br tags.  It
  properly recognizes the three EOL forms of \r\n, \r, and \n.  Multiple
  spaces are converted to a non-breaking space followed by a normal space.  An
  odd number of spaces greater than 2 will get rounded down to the next even
  number of spaces.
  $text = User-entered text that may contain EOL characters or multiple spaces.
  @return = Text converted to HTML.
*/
    public static function EOL2br($text) {
      return str_replace(array("\r\n", "\n", "\r"), '<br />',
             str_replace('  ', '&nbsp; ', $text));
    }

/*----------------------------------------------------------[ auText.pbr2EOL ]--
  Undoes what EOL2pbr does.  Generally this should be used when the user wants
  to edit something they previously entered.  It can also be used to undo
  EOL2br as it simply wouldn't contain any p tags in that case.
  $text = HTML-formatted text.
  @return = Text converted back to what the user entered.
*/
    public static function pbr2EOL($text) {
      return str_replace(array('</p>', '<p>', '<br />', '&nbsp;'), array("\n\n", '', "\n", ' '), $text);
    }
    public static function br2EOL($text) { return auText::pbr2EOL($text); }  // included since it makes more sense to have a function named this way to go with EOL2br.

/*----------------------------------------------------------[ auText.BB2HTML ]--
  Converts user-entered text that may contain BBcode into HTML.
  $bb = User-entered BBcode text.
  $head = Allows [head] and [subhead] BBcode tags if true.  Default is to not
    allow these tags.
  @return = Text converted to HTML.
*/
    public static function BB2HTML($bb, $head = false) {
      $html = htmlspecialchars($bb);
      $html = str_replace('  ', '&nbsp; ', $html);
      while(preg_match('/\[code\](.+?)\[\/code\]/', $html, $code))
        $html = str_replace($code[0], '<code>' . str_replace(array('[', ']'), array('\[', '\]'), $code[1]) . '</code>', $html);
      while(preg_match('/(\r\n|\r|\n){0,2}\[code\](.+?)\[\/code\](\r\n|\r|\n){0,2}/s', $html, $code))
        $html = str_replace($code[0], '</p><samp>' . auText::EOL2br(str_replace(array('[', ']'), array('\[', '\]'), $code[2])) . '</samp><p>', $html);
      if($head) {
        $html = preg_replace('/(\r\n|\r|\n){0,2}\[head\](.+?)\[\/head\](\r\n|\r|\n){0,2}/is', '<h2>$1</h2>', $html);
        $html = preg_replace('/(\r\n|\r|\n){0,2}\[subhead\](.+?)\[\/subhead\](\r\n|\r|\n){0,2}/is', '<h3>$1</h3>', $html);
      }
      while(preg_match('/(\r\n|\r|\n){0,2}\[bullets\](\r\n|\r|\n)?(.+?)(\r\n|\r|\n)?\[\/bullets\](\r\n|\r|\n){0,2}/is', $html, $bullets))
        $html = str_replace($bullets[0], '<ul><li>' . str_replace(array("\r\n", "\r", "\n"), '</li><li>', $bullets[3]) . '</li></ul>', $html);
      while(preg_match('/(\r\n|\r|\n){0,2}\[numbers\](\r\n|\r|\n)?(.+?)(\r\n|\r|\n)?\[\/numbers\](\r\n|\r|\n){0,2}/is', $html, $numbers))
        $html = str_replace($numbers[0], '<ol><li>' . str_replace(array("\r\n", "\r", "\n"), '</li><li>', $numbers[3]) . '</li></ol>', $html);
      while(preg_match('/\[(link|url)=(.+?)](.+?)\[\/(link|url)]/', $html, $link))
        $html = str_replace($link[0], '<a href="' . auText::FixLink($link[2]) . '">' . $link[3] . '</a>', $html);
      while(preg_match('/(\r\n|\r|\n)?\[q](.+?)\[\/q](\r\n|\r|\n)?/s', $html, $quote))
        $html = str_replace($quote[0], '<q><p>' . $quote[2] . '</p></q>', $html);
      while(preg_match('/(\r\n|\r|\n)?\[q=([^\]]+)](.+?)\[\/q](\r\n|\r|\n)?/s', $html, $quote))
        $html = str_replace($quote[0], '<cite>' . $quote[2] . ' said:</cite><q><p>' . $quote[3] . '</p></q>', $html);
      $html = preg_replace('/\[i\](.+?)\[\/i\]/s', '<i>$1</i>', $html);
      $html = preg_replace('/\[b\](.+?)\[\/b\]/s', '<b>$1</b>', $html);
      $html = str_replace(array('\[', '\]'), array('[', ']'), $html);
      if(strpos($html, '<samp>') === false)
        return auText::EOL2pbr($html);
      $array = explode('<samp>', $html);
      $html = auText::EOL2pbr($array[0]);
      for($i = 1; $i < count($array); $i++) {
        $pieces = explode('</samp>', $array[$i]);
        $html .= '<samp>' . $pieces[0] . '</samp>' . auText::EOL2pbr($pieces[1]);
      }
      return $html;
    }

/*----------------------------------------------------------[ auText.HTML2BB ]--
  Converts HTML generated from BBcode back to BBcode.  This should only need
  to be used when a user is editing text they previously entered, or quoting
  text entered by another user.
  $html = HTML code to convert back to BBcode.
  @return = Text converted to BBcode.
*/
    public static function HTML2BB($html) {
      $bb = auText::pbr2EOL($html);
      $bb = str_replace(array('<i>', '</i>', '<b>', '</b>'), array('[i]', '[/i]', '[b]', '[/b]'), $bb);
      $bb = preg_replace('/<cite>(.+?) said:<\/cite><q>/', "\n" .'[q=$1]', $bb);
      $bb = str_replace(array('<q><p>', '<q>', '</p></q>', '</q>'), array("\n[q]", "\n[q]", "[/q]\n", "[/q]\n"), $bb);
      $bb = preg_replace('/<a href="([^"]*)">([^<].*)<\/a>/', '[link=$1]$2[/link]', $bb);
      $bb = str_replace(array('<ol><li>', '</li></ol>', '<ul><li>', '</li></ul>', '</li><li>'), array("\n[numbers]", "[/numbers]\n", "\n[bullets]", "[/bullets]\n", "\n"), $bb);
      $bb = str_replace(array('<h3>', '</h3>', '<h2>', '</h2>'), array("\n[subhead]", "[/subhead]\n", "\n[head]", "[/head]\n"), $bb);
      $bb = str_replace(array('</p><samp>', '<code>', '</samp><p>', '</code>'), array("\n[code]", '[code]', "[/code]\n", '[/code]'), $bb);
      $bb = auText::pbr2EOL($bb);
      return strtr($bb, array_flip(get_html_translation_table(HTML_SPECIALCHARS)));
    }

/*-------------------------------------------------------[ auText.HowLongAgo ]--
  Takes a unix timestamp and determines how long before now it occurred.
  $timestamp = Unix timestamp.
  @return = How long ago the timestamp was, in the form <value> <units>.
*/
    public static function HowLongAgo($timestamp) {
      $seconds = time() - $timestamp;
      if($seconds <= 90)
        return $seconds . ' second' . ($seconds != 1 ? 's' : '');
      $minutes = round($seconds / 60);
      if($minutes <= 90)
        return $minutes . ' minutes';
      $hours = round($minutes / 60);
      if($hours <= 36)
        return $hours . ' hours';
      $days = round($hours / 24);
      if($days <= 12)
        return $days . ' days';
      $weeks = round($days / 7);
      if($weeks <=6)
        return $weeks . ' weeks';
      $months = round($days * 12 / 365);
      if($months <= 18)
        return $months . ' months';
      $years = round($days / 365);
      return $years . ' years';
    }

/*--------------------------------------------------------[ auText.SmartTime ]--
  Takes a Unix timestamp and intelligently converts it to a human-readable
  time format with an appropriate level of detail.
  $timestamp = Unix timestamp to convert.
  $tz = Object that can handle timezones, providing a tzdate function.  The
    standard php date function is used by default.
  @return = Human-readable time.
*/
    public static function SmartTime($timestamp, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      $diff = time() - $timestamp;
      if($diff < 86400 && date('Y-m-d') == date('Y-m-d', $timestamp)) // 86400 s == 1 day
        return $tz->tzdate('g:i a', $timestamp);
      if($diff < 518400) // 518400 s == 6 days
        return $tz->tzdate('l', $timestamp);
      if(date('Y') == date('Y', $timestamp))
        return $tz->tzdate('M d<\s\u\p>S</\s\u\p>', $timestamp);
      return $tz->tzdate('M Y', $timestamp);
    }

/*--------------------------------------------------------[ auText.SmartDate ]--
  Takes a Unix timestamp and intelligently converts it to a human-readable
  date format with an appropriate level of detail.
  $timestamp = Unix timestamp to convert.
  $tz = Object that can handle timezones, providing a tzdate function.  The
    standard php date function is used by default.
  @return = Human-readable date.
*/
    public static function SmartDate($timestamp, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      if(time() - $timestamp < 518400) // 518400 s == 6 days
        return $tz->tzdate('l', $timestamp);
      if(date('Y') == date('Y', $timestamp))
        return $tz->tzdate('M d<\s\u\p>S</\s\u\p>', $timestamp);
      return $tz->tzdate('M Y', $timestamp);
    }

/*---------------------------------------------------------[ auText.Tomorrow ]--
  Takes a Unix timestamp and finds the timestamp for the following day.
  $today = Unix timestamp of current day.
  @return = Unix timestamp of following day.
*/
    public static function Tomorrow($today) {
      return strtotime(date('Y-m-d', $today + 115200));  // 32 hours--helps for daylight savings
    }

/*--------------------------------------------------------[ auText.FormatDay ]--
  Takes a formatted date and converts it to a different format.
  $day = Date in yyyy-mm-dd format (or something strtotime() understands).
  $format = Format string -- see php date() for options.
  $tz = Object that can handle timezones, providing a tzdate function.  The
    standard php date function is used by default.
  @return = Formatted date.
*/
    public static function FormatDay($day, $format, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      return $tz->tzdate($format, strtotime($day));
    }

/*------------------------------------------------------[ auText.FormatMonth ]--
  Takes a formatted date and converts it to a different format.
  $month = Month in yyyy-mm format.
  $format = Format string -- see php date() for options.
  $tz = Object that can handle timezones, providing a tzdate function.  The
    standard php date function is used by default.
  @return = Formatted date.
*/
    public static function formatmonth($month, $format, &$tz = null) {
      if(!$tz || !method_exists($tz, 'tzdate'))
        $tz = new auTextDefaultTZ();
      return $tz->tzdate($format, strtotime($month . '-01'));
    }
  }

/*===================================================[ auTextDefaultTZ class ]==
  This class is used by date and time functions if a different object with
  tzdate() or tzstrtotime() has not been provided.  It really shouldn't be
  used other than that since it just duplicates date() and strtotime().
*/
  class auTextDefaultTZ {
    
    public function tzdate($fmt, $timestamp = false) {
      if($timestamp === false)
        $timestamp = time();
      return date($fmt, $timestamp);
    }
  }
?>