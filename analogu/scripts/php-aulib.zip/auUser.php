<?
/******************************************************************************\
 * Title:    User class
 * Purpose:  Provides common functions for users.  This class needs to be
 *           extended in order to work with a site's specific users table.
 * History:  0.0.0 - Initial release
\******************************************************************************/

  if(!defined('_AU_USER_SESS_TIMEOUT'))
    define('_AU_USER_SESS_TIMEOUT', 3600);  // session timeout - 1 hour
  if(!defined('_AU_USER_COOKIE_LIFE'))
    define('_AU_USER_COOKIE_LIFE', 2592000);  // login cookie lifetime - 30 days
  if(!defined('_AU_USER_COOKIE_NAME'))
    define('_AU_USER_COOKIE_NAME', 'autologin');  // login cookie name

  if(!defined('_HOST')) {  // used as the domain for cookies (put a '.' in front) and e-mail
    list($host) = split(':', strtolower($_SERVER['HTTP_HOST']), 2);  // put domain in lowercase, and strip off port number if there is one
    $host = preg_replace('/^(web|www[0-9]*|secure)\./', '', $host);  // remove the www. if there is one, so that the same cookie will work for both with and without the www
    define('_HOST', $host);
    unset($host);
  }

  define('_AU_USER_LOGIN_REGISTER', 'User information read from registration form');
  define('_AU_USER_LOGIN_FORM', 'User information read from login form');
  define('_AU_USER_LOGIN_SESSION', 'User information read from session');
  define('_AU_USER_LOGIN_COOKIE', 'User information read from cookie');
  define('_AU_USER_LOGIN_NONE', 'User information not found');
  define('_AU_USER_LOGIN_WRONGIP', 'Cannot continue session from different IP than the one that started it');
  define('_AU_USER_LOGIN_TIMEOUT', 'Session timed out');
  define('_AU_USER_LOGIN_DBERROR', 'Error looking up user');
  define('_AU_USER_LOGIN_WRONGPASSWORD', 'Incorrect username or password');
  define('_AU_USER_LOGIN_BADPASSWORD', 'Password missing or corrupt');

/*============================================================[ auUser class ]==
  auUser implements some functions that are most likely useful to any site's
  user system.  Since different sites will usually have different needs for
  their user systems, this class does not implement any specifics and should
  be extended by each site in order to do so. 
*/
  class auUser {
    protected $db;  // database connection (auDB object)

    public $Valid = false;  // set to true if the object represents a valid user
    public $LoginMessage;  // results of trying to log in
    public $ID;  // logged-in users's ID, if user is valid
    public $Name;  // logged-in users's display name, if user is valid

/*------------------------------------------------------[ auUser constructor ]--
  Creates a new user object.
  $db = Database connection for looking up user information.
*/
    public function auUser(&$db) {
      $this->db = $db;
      $this->LoginMessage = _AU_USER_LOGIN_NONE;
      // check for logout
      if(isset($_GET['userlogout'])) {
        $this->LoginMessage = _AU_USER_LOGIN_LOGGEDOUT;
        @session_unset();
        @session_destroy();
        setcookie(_AU_USER_COOKIE_NAME, '', time() - 60, '/', '.' . _HOST);
        if($_GET['userlogout'])
          header('Location: http' . (strtolower($_SERVER['HTTPS']) == 'on' ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_GET['userlogout']);
        else
          header('Location: http' . (strtolower($_SERVER['HTTPS']) == 'on' ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . str_replace('userlogout', '', $_SERVER['REQUEST_URI']));
        die;
      }
      // check for registration form
      if($_POST['formid'] == 'userregister') {
        if($this->ProcessRegistrationForm())
          return;
      }
      // check for login form
      if($_POST['formid'] == 'userlogin') {
        if($this->GetUserInfo(trim($_POST['login']), true, trim($_POST['password']))) {
          $this->LoginMessage = _AU_USER_LOGIN_FORM;
          // redirect to this same page now that the session has been set, to avoid warnings about the page containing post data.
          header('Location: http' . (strtolower($_SERVER['HTTPS']) == 'on' ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
          die;
        }
      }
      // check for session data
      if(isset($_SESSION['uid'])) {
        if($_SESSION['ip'] != $_SERVER['REMOTE_ADDR'])
          $this->LoginMessage = _AU_USER_LOGIN_WRONGIP;
        elseif(time() - $_SESSION['time'] > _AU_USER_SESS_TIMEOUT)
          $this->LoginMessage = _AU_USER_LOGIN_TIMEOUT;
        elseif($this->GetUserInfo($_SESSION['uid'])) {
          $this->LoginMessage = _AU_USER_LOGIN_SESSION;
          return;
        }
        // there was a problem with the session, so get rid of it
        @session_unset();
        @session_destroy();
      }
      // check for cookie data
      if(isset($_COOKIE[_AU_USER_COOKIE_NAME])) {
        list($id, $passhash) = explode('|', $_COOKIE[_AU_USER_COOKIE_NAME], 2);
        if($this->GetUserInfo($id, true, $passhash, true)) {
          $this->LoginMessage = _AU_USER_LOGIN_COOKIE;
          return;
        }
        // there was a problem with the cookie, so get rid of it
        setcookie(_AU_USER_COOKIE_NAME, '', time() - 86400, '/', '.' . _HOST);
      }
      $this->GetGuestInfo();
    }

/*------------------------------------------[ auUser.ProcessRegistrationForm ]--
  Attempts to process the user registration form (must be overridden to use
  site-specific user data).
  @return = True if user was successfully registered and logged in.
*/
    protected function ProcessRegistrationForm() {
      $this->GetUserInfo(1);
    }

/*------------------------------------------------------[ auUser.GetUserInfo ]--
  Gets user information from the database (must be overridden to get 
  site-specific user data).
  $id = Look up information for user with this ID.
  $login = Set this to true if the user is logging in.
  $password = If present, this password is checked against the user's password
    stored in the database.
  $hashed = Set this to true if $password is set to the hashed version of the
    user's password.
  @return = True if user information was retrieved.
*/
    protected function GetUserInfo($id, $login = false, $password = false, $hashed = false) {
      $this->ID = $id;
      $this->Valid = true;
      $this->Name = 'User';
      $_SESSION['uid'] = $id;
      $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
      $_SESSION['time'] = time();
      return true;
    }

/*-----------------------------------------------------[ auUser.GetGuestInfo ]--
  Gets user information for a guest user (should be overridden to get
  site-specific user data).
*/
    protected function GetGuestInfo() {
      $this->ID = 0;
      $this->Valid = false;
      $this->Name = 'Guest';
    }

/*--------------------------------------------------[ auUser.EncryptPassword ]--
  Encrypts a plain-text password for storing in a cookie or the database.
  $password = Plain-text password to encrypt.
  @return = Encrypted password.
*/
    public function EncryptPassword($password) {
      for($salt = ''; strlen($salt) < 8; $salt .= dechex(mt_rand(0, 15)));
      return $salt. sha1($password . $salt);
    }

/*----------------------------------------------------[ auUser.CheckPassword ]--
  Checks a plain-text password against an encrypted password.
  $password = Plain-text password.
  $hash = Encrypted password.
  @return = True if passwords match.
*/
    public function CheckPassword($password, $hash) {
      $password .= substr($hash, 0, 8);  // add the salt value used to encrypt the password
      return sha1($password) == substr($hash, 8);
    }
  }
?>