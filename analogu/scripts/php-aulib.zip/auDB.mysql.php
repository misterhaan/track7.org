<?
/******************************************************************************\
 * Title:    Database class for MySQL
 * Purpose:  Interacts with a MySQL database.
 * History:  0.0.0 - Initial release
\******************************************************************************/

/*==============================================================[ auDB class ]==
  Create an auDB object using new auDB(), then run queries against it with
  Get(), GetRecord(), GetValue(), GetLimit(), GetSplit(), Put(), and Change().
  NumQueries() will tell you how many queries have been run since the object
  was created.
*/
  class auDB {
    private $queries;
    private $report;

    var $split_count;   // the row count from the last time splitquery() was used
    var $split_skip;    // the GET variable name for skip, set when splitquery() is used
    var $split_show;    // the GET variable name for show, set when splitquery() is used
    var $split_dskip;   // the default number of rows to skip, usually 0
    var $split_dshow;   // the default number of rows to show

/*--------------------------------------------------------[ auDB constructor ]--
  Creates a new database object.
  $user = Username for database account.
  $pass = Password for database account.
  $host = Name of server hosting the database (often 'localhost' works).
  $name = Name of database to work with.
  $report = Object with Error($, $) and Info($) methods for displaying error
    and information messages.  Defaults to built-in object which simply writes
    HTML messages.
*/
    public function auDB($user, $pass, $host, $name, &$report = null) {
      mysql_connect($host, $user, $pass);
      mysql_select_db($name);
      $this->queries = 0;
      if($report && method_exists($report, 'Error') && method_exists($report, 'Info'))
        $this->report = $report;
      else
        $this->report = new auDBReport();
    }
    
/*----------------------------------------------------------[ auDB.SetReport ]--
  Sets the object to be used for reporting errors and information.
  $report = Object with Error($, $) and Info($) methods for displaying error
    and information messages.  Defaults to built-in object which simply writes
    HTML messages.
  @return = True if $report had the required methods and is going to be used.
*/
    public function SetReport(&$report) {
      if(method_exists($report, 'Error') && method_exists($report, 'Info')) {
        $this->report = $report;
        return true;
      }
      return false;
    }

/*---------------------------------------------------------[ auDB.NumQueries ]--
  Gets the number of queries run against the database.
  @return = Number of queries run against the database.
*/
    public function NumQueries() {
      return $this->queries;
    }

/*----------------------------------------------------------------[ auDB.Get ]--
  Runs an SQL SELECT query against the database.
  $query = SQL SELECT query to run.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  $emptymsg = Message to report if the query does not return any results.
    Default is to return the results without checking to see if there are any
    results.
  $emptyerror = Whether empty results should be reported as an error.
    Default is to report empty results as information.
  @return = The results as an auDBResult object, or false.
*/
    public function Get($query, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      $result = $this->Query($query);
      if($errormsg !== null && $result->IsError()) {
        if(strlen($errormsg))
          $this->report->Error($errormsg, $result->GetMessage());
        return false;
      }
      if($emptymsg !== null && $result->NumRecords() <= 0) {
        if(strlen($emptymsg))
          if($emptyerror)
            $this->report->Error($emptymsg);
          else
            $this->report->Info($emptymsg);
        return false;
      }
      return $result;
    }

/*----------------------------------------------------------[ auDB.GetRecord ]--
  Runs an SQL SELECT query against the database and gets back just the first
    record of the results.
  $query = SQL SELECT query to run.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  $emptymsg = Message to report if the query does not return any results.
    Default is to return the results without checking to see if there are any
    results.
  $emptyerror = Whether empty results should be reported as an error.
    Default is to report empty results as information.
  @return = The first record of the results as an object, or false.
*/
    public function GetRecord($query, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      $result = $this->GetLimit($query, 0, 1, $errormsg, $emptymsg, $emptyerror);
      if(!$result)
        return false;
      return $result->NextRecord();
    }

/*-----------------------------------------------------------[ auDB.GetValue ]--
  Runs an SQL SELECT query against the database and gets back just the first
    value from the first record of the results.
  $query = SQL SELECT query to run.
  $errormsg = Error message to report if the query results in an error.
    Default is to not write an error message.
  $emptymsg = Message to report if the query does not return any results.
    Default is to not write a message.
  $emptyerror = Whether empty results should be reported as an error.
    Default is to report empty results as information.
  @return = The first value from the first record of the results, or false.
*/
    public function GetValue($query, $errormsg = '', $emptymsg = '', $emptyerror = false) {
      $result = $this->GetLimit($query, 0, 1, $errormsg, $emptymsg, $emptyerror);
      if(!$result)
        return false;
      $result = $result->NextRecord(false);
      return $result[0];
    }

/*-----------------------------------------------------------[ auDB.GetLimit ]--
  Runs an SQL SELECT query against the database and gets back a limited number
    of records in the results.
  $query = SQL SELECT query to run.
  $skip = Number of result records to skip.
  $show = Number of result records to show.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  $emptymsg = Message to report if the query does not return any results.
    Default is to return the results without checking to see if there are any
    results.
  $emptyerror = Whether empty results should be reported as an error.
    Default is to report empty results as information.
  @return = The results as an auDBResult object, or false.
*/
    public function GetLimit($query, $skip, $show, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      return $this->Get($query . ' limit ' . $skip . ', ' . $show, $errormsg, $emptymsg, $emptyerror);
    }

/*-----------------------------------------------------------[ auDB.GetSplit ]--
  Runs an SQL SELECT query against the database and gets back a page of
    results.
  $query = SQL SELECT query to run.
  $defshow = Default number of records to return.
  $defskip = Default number of records to skip.
  $skip = Index to $_GET to use for 'skip.'
  $show = Index to $_GET to use for 'show.'
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  $emptymsg = Message to report if the query does not return any results.
    Default is to return the results without checking to see if there are any
    results.
  $emptyerror = Whether empty results should be reported as an error.
    Default is to report empty results as information.
  $numrecords = If true, use ->NumRecords to get count.
  @return = The results as an auDBResult object, or false.
*/
    public function GetSplit($query, $defshow, $defskip = 0, $skip = '', $show = '', $errormsg = null, $emptymsg = null, $emptyerror = false, $numrecords = false) {
      if(!$skip) $skip = 'skip';
      if(!$show) $show = 'show';
      $this->split_skip = $skip;
      $this->split_show = $show;
      $this->split_dskip = $defskip;
      $this->split_dshow = $defshow;
      if($numrecords)
        if($this->split_count = $this->Get($query, $errormsg, $emptymsg, $emptyerror))
          $this->split_count = $this->split_count->NumRecords();
        else
          return false;
      else
        if(false === $this->split_count = $this->GetValue('select count(1)' . stristr($query, ' from ')))
          return false;
      if(!isset($_GET[$show]))
        $_GET[$show] = $defshow;
      if($defskip === 'last')
        $defskip = $this->split_count - ($this->split_count % $_GET[$show] ? $this->split_count % $_GET[$show] : $_GET[$show]);
      if($defskip < 1) $defskip = 0;
      if(!isset($_GET[$skip]))
        $_GET[$skip] = $defskip;
      return $this->GetLimit($query, $_GET[$skip], $_GET[$show], $errormsg, $emptymsg, $emptyerror);
    }

/*-----------------------------------------------------[ auDB.SplitPageLinks ]--
  Write out links to other pages of a split query.
  $get = Beginning of the query string that page variables will be added onto.
    Default is '?' which means no additional variables.  This value should
    always start with a question mark.  If there are other query string
    variables, the value should end with &amp; so page variables can be added
    directly.
  $indent = Base indentation level -- a number of spaces or tabs.  Default
    is 6 spaces, which should mean 3 levels of indentation.
*/
    public function SplitPageLinks($get = '?', $indent = '      ') {
      if($_GET[$this->split_skip] !== 0 || $this->split_count > $_GET[$this->split_show]) {
        echo $indent . '<div class="pagelinks">' . "\n"
           . $indent . "  page:&nbsp;\n";
        $show = isset($_GET[$this->split_show]) ? $_GET[$this->split_show] : $this->split_dshow;
        $thispage = round($_GET[$this->split_skip] / $show);
        $pages = round($this->split_count / $show + .49);
        for($page = 0; $page < $pages; $page++)
          if($page == $thispage)
            echo $indent . '  <span class="active">' . ($page + 1) . "</span>\n";
          else {
            echo $indent . '  <a href="' . $get;
            $skip = $page * $show;
            if($skip != $this->split_dskip) {
              echo $this->split_skip . '=' . $skip;
              if($show != $this->split_dshow)
                echo '&amp;' . $this->split_show . '=' . $show;
            } elseif($show != $this->split_dshow)
              echo $this->split_show . '=' . $show;
            echo '">' . ($page + 1) . "</a>\n";
          }
        echo $indent . "</div>\n";
      }
    }

/*----------------------------------------------------------------[ auDB.Put ]--
  Runs an SQL INSERT or REPLACE query against the database.
  $query = SQL INSERT/REPLACE query to run.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  @return = The ID of the inserted record, or false on failure.
*/
    public function Put($query, $errormsg = null) {
      $result = $this->Query($query);
      if($errormsg !== null && $result->IsError()) {
        if(strlen($errormsg))
          $this->report->Error($errormsg, $result->GetMessage());
        return false;
      }
      return mysql_insert_id();
    }

/*-------------------------------------------------------------[ auDB.Change ]--
  Runs an SQL UPDATE or DELETE query against the database.
  $query = SQL UPDATE/DELETE query to run.
  $errormsg = Error message to report if the query results in an error.
    Default is to return the results without checking for errors.
  $emptymsg = Message to report if the query does not affect any records.
    Default is to return the number of records without checking it.
  $emptyerror = Whether affecting no records should be reported as an error.
    Default is to report as information.
  @return = The number of records affected, or false.
*/
    public function Change($query, $errormsg = null, $emptymsg = null, $emptyerror = false) {
      $result = $this->Query($query);
      if($errormsg !== null && $result->IsError()) {
        if(strlen($errormsg))
          $this->report->Error($errormsg, $result->GetMessage());
        return false;
      }
      $result = $result->NumRecords();
      if($emptymsg !== null && $result <= 0) {
        if(strlen($emptymsg))
          if($emptyerror)
            $this->report->Error($emptymsg);
          else
            $this->report->Info($emptymsg);
        return false;
      }
      return $result;
    }

    private function Query($sql) {
      $this->queries++;
      return new auDBResult($sql);
    }
  }

/*========================================================[ auDBReport class ]==
  Default way of writing error and information messages, which is just to write
  them out in classed paragraph tags.
*/
  class auDBReport {
    public function Error($message, $detail = '') {
      echo '<p class="error">' . $message;
      if($detail)
        echo ':&nbsp; ' . $detail;
      echo '</p>';
    }

    public function Info($message) {
      echo '<p class="info">' . $message;
    }
  }

/*========================================================[ auDBResult class ]==
  Provides access to results of an SQL query.  This class is instantiated and
  returned by methods in the auDB class.
*/
  class auDBResult {
    private $result;
    private $error;
    private $message;
    private $affected;

/*--------------------------------------------------[ auDBResult constructor ]--
  Runs an SQL query against the database and provides access to the results.
  $query = SQL query to run.
*/
    public function auDBResult($query) {
      if($this->result = mysql_query($query)) {
        $this->error = false;
        $this->message = '';
        if(strtolower(substr(trim($query), 0, 6)) == 'select')
          $this->affected = mysql_num_rows($this->result);
        else
          $this->affected = mysql_affected_rows();
      } else {
        $this->error = true;
        $this->message = htmlspecialchars(mysql_error());
        $this->affected = 0;
      }
    }

/*------------------------------------------------------[ auDBResult.IsError ]--
  Returns whether the query resulted in an error.
  @return = True if the query resulted in an error.
*/
    public function IsError() {return $this->error;}

/*---------------------------------------------------[ auDBResult.GetMessage ]--
  Returns the error message returned by the query.
  @return = Error message returned by the query, or an empty string if the
    query did not result in an error.
*/
    public function GetMessage() {return $this->message;}

/*---------------------------------------------------[ auDBResult.NumRecords ]--
  Returns the number of records affected or returned by the query.
  @return = Number of records affected or returned by the query.
*/
    public function NumRecords() {return $this->affected;}

/*---------------------------------------------------[ auDBResult.NextRecord ]--
  Returns the next record returned by the query.
  $object = Set to false to return the record as an array.
  @return = The next record returned by the query, or false if no more records.
*/
    public function NextRecord($object = true) {
      if(!$object)
        return mysql_fetch_array($this->result, MYSQL_NUM);
      return mysql_fetch_object($this->result);
    }
  }
?>
