// ==UserScript==
// @name           MoreSPORE
// @namespace      http://www.spore.com/view/profile/misterhaan
// @description    Adds more information and links to spore.com profile and sporepedia pages
// @include        http://www.spore.com/view/profile
// @include        http://www.spore.com/view/profile/*
// @include        http://www.spore.com/sporepedia*
// ==/UserScript==

if(document.location.pathname.substring(0, 13) == "/view/profile") {
  var username = getUsername();
  if(username) {
    var uploaded = document.getElementById("user-asset-count").parentNode;
    if(uploaded) {
      showSubscribers();
      showAchievements();
    }
    addQualitySporeLink();
  }
}

function showSubscribers() {
  var subs = document.createTextNode("(counting...)");
  addUserStat("user-subscriber-count", "Subscribers: ", subs);
  getAsync("http://www.spore.com/rest/users/subscribers/" + username + "/0/100000", gotSubscriberXml, subs);
}
function gotSubscriberXml(req, subs) {
	var response = req.responseXML.documentElement;
	var count = response.getElementsByTagName("count");
	count = count[0].firstChild.data;
	subs.data = count;
}

function showAchievements() {
  var achs = document.createTextNode("(counting...)");
  addUserStat("user-achievement-count", "Achievements: ", achs);
  getAsync("http://www.spore.com/rest/achievements/" + username + "/0/10000", gotAchievementXml, achs);
}
function gotAchievementXml(req, achs) {
	var response = req.responseXML.documentElement;
	var count = response.getElementsByTagName("length");
	count = count[0].firstChild.data;
	achs.data = count;
}

function addUserStat(id, label, value) {
  var span = document.createElement("span");
  span.id = id;
  span.className = "userstats";
  span.appendChild(value);
  var div = document.createElement("div");
  div.className = "field";
  div.appendChild(document.createTextNode(label));
  div.appendChild(span);
  uploaded.parentNode.insertBefore(div, uploaded);
}

function addQualitySporeLink() {
	var userCreations = document.getElementById("user-creations");
	if(userCreations) {
		var divs = userCreations.getElementsByTagName("div");
		if(divs.length) {
			var qslink = document.createElement("a");
			qslink.href = "http://www.qualityspore.com/ProfileViewer.htm?profile=" + username;
			qslink.appendChild(document.createTextNode("See " + username + "'s QualitySPORE profile"));
			var span = document.createElement("span");
			span.style.width = "440px";
			span.style.textAlign = "center";
			span.appendChild(qslink);
			var thumbdiv = null;
			for(var i in divs)
				if(divs[i].className == "thumbnails")
					thumbdiv = divs[i];
			if(thumbdiv)
				if(thumbdiv.nextSibling) {
					thumbdiv.parentNode.insertBefore(span, thumbdiv.nextSibling);
					thumbdiv.parentNode.insertBefore(document.createElement("br"), span.nextSibling);
				} else
					thumbdiv.parentNode.appendChild(span);
		}
	}
}

function getUsername() {
	if(document.location.pathname == '/view/profile') {
		var h3 = document.getElementsByTagName("h3");
		for(var i in h3)
			if(h3[i].className == "profileUsertitle")
				return h3[i].firstChild.data.split("'")[0];
	} else {
		var username = document.location.pathname.split("/");
		return username[username.length - 1];
	}
}

function getAsync(url, finished, args) {
	var req = new XMLHttpRequest();
	req.onreadystatechange = function() {
		if(req.readyState == 4)
			finished(req, args);
	}
	req.open("GET", url, true);
	req.send(null);
	return true;
}

