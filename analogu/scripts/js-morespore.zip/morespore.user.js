// ==UserScript==
// @name           MoreSPORE
// @namespace      http://www.spore.com/view/myspore/misterhaan
// @description    Adds more information and links to spore.com profile pages
// @include        http://www.spore.com/view/myspore
// @include        http://www.spore.com/view/myspore/*
// @include        http://www.spore.com/view/profile
// @include        http://www.spore.com/view/profile/*
// ==/UserScript==

var subsXml = false;
var publicProfile = document.location.pathname != "/view/myspore" && document.location.pathname != "/view/profile";
var username = getUsername(publicProfile);
if(publicProfile && username) {
  var uploaded = document.getElementById("creationsUpLabel");
  if(uploaded) {
    showSubscribers();
    showAchievements();
  }
  addQualitySporeLink();
}
if(!publicProfile) {
	hideSporeIslands();
	showSubscribers();
}


function showSubscribers() {
  var subs = document.createTextNode("(counting...)");
  var subRow = false;
 	if(publicProfile)
 		addUserStat("subscribers", "Subscribers: ", subs);
 	else {
 		var content = document.getElementById("sporeTabContentInner");
 		if(content) {
 			var div = document.createElement("div");
 			content.appendChild(div);
 			div.id = "subscribersHeaderDiv";
 			div.className = "headerDiv";
 			var h4 = document.createElement("h4");
 			div.appendChild(h4);
 			h4.id = "subscribersHdr";
 			h4.className = "tabHeader";
 			h4.appendChild(document.createTextNode("SUBSCRIBERS"));
 			var icon = document.createElement("div");
 			div.appendChild(icon);
 			icon.id = "subscribersIcon";
 			icon.className = "headerIcon";
 			icon.style.background = "transparent url(/static/war/images/sporepedia/adv/mySporeSprite.png) no-repeat scroll -101px -6px";
 			icon.style.marginTop = "-20px";
 			div = document.createElement("div");
 			content.appendChild(div);
 			div.id = "subscriberCount";
 			div.className = "graySubHead";
 			div.style.marginTop = "10px";
 			div.appendChild(document.createTextNode("YOU HAVE "));
 			var span = document.createElement("span");
 			div.appendChild(span);
 			span.id = "numSubscribers";
 			span.appendChild(subs);
 			div.appendChild(document.createTextNode(" SUBSCRIBERS: "));
 			var a = document.createElement("a");
 			div.appendChild(a);
 			a.href = "javascript:null";
 			a.id = "subscriberSPDLink";
 			a.className = "sporepediaLink";
 			a.appendChild(document.createTextNode("(See all of your subscribers)"));
			a.addEventListener("click", viewSubscribers, false);  // greasemonkey won't work with .onclick
 			subRow = document.createElement("div");
 			content.appendChild(subRow);
 			subRow.id = "subscriberRow";
 			subRow.className = "buddyRow";
 			subRow.style.visibility = "visible";
 		}
 	}
  getAsync("http://www.spore.com/rest/users/subscribers/" + username + "/0/100000", gotSubscriberXml, new Array(subs, subRow));
}
function gotSubscriberXml(req, args) {
	subsXml = req.responseXML.documentElement;
	var count = subsXml.getElementsByTagName("count");
	count = count[0].firstChild.data;
	args[0].data = count;
	if(args[1]) {
		var subs = subsXml.getElementsByTagName("buddy");
		for(var s = 0; s < 4 && s < subs.length; s++) {
			var subName = subs[s].getElementsByTagName("name")[0].firstChild.nodeValue;
			var div = createSubscriberDiv(subName);
			args[1].appendChild(div);
			div.id = "subscriberDiv" + (s + 1);
		}
	}
}

function createSubscriberDiv(subName) {
	var div = document.createElement("div");
	div.className = "buddyDiv";
	var div2 = document.createElement("div");
	div.appendChild(div2);
	div2.className = "avatarframe"
	var link = document.createElement("a");
	div2.appendChild(link);
	link.href = "/view/myspore/" + subName;
	var img = document.createElement("img");
	link.appendChild(img);
	img.className = "header-avatar js-avatar-thumbnail PNG avatarimg";
	img.src = "/static/war/images/header/avatar_frame_transparent.png";
	div2 = document.createElement("div");
	div.appendChild(div2);
	div2.className = "buddyData";
	var div3 = document.createElement("div");
	div2.appendChild(div3);
	div3.className = "buddyName";
	link = document.createElement("a");
	div3.appendChild(link);
	link.href = "/view/myspore/" + subName;
	link.appendChild(document.createTextNode(subName));
	div3 = document.createElement("div");
	div2.appendChild(div3);
	div3.className = "buddyTagline";
	div3.appendChild(document.createTextNode("(looking up " + subName + "...)"));
	getAsync("http://www.spore.com/rest/user/" + subName, gotSingleSubInfo, new Array(img, div3));
	return div;
}

function gotSingleSubInfo(req, args) {
	var response = req.responseXML.documentElement;
	var avatar = response.getElementsByTagName("image")[0].firstChild.nodeValue;
	if(avatar.substring(0, 33) == "http://www.spore.com/static/thumb")
		args[0].src = avatar;
	else {
		// need to adjust structure for uploaded image
		args[0].className = null;
		args[0].parentNode.className = "myCustomAvatarFrame";
		var avtframe = args[0].parentNode.parentNode
		avtframe.className = "myAvatarcustomframe";
		var img = document.createElement("img");
		avtframe.parentNode.insertBefore(img, avtframe.nextSibling);
		img.className = "avatarcustomimg";
		img.src = avatar;
		img.style.cssFloat = "left";
		img.style.margin = "8px 5px 0";
	}
	var tagline = response.getElementsByTagName("tagline")[0];
	if(tagline.firstChild)
		args[1].firstChild.nodeValue = "“" + tagline.firstChild.nodeValue + "”";
	else
		args[1].removeChild(args[1].firstChild);
}

function viewSubscribers() {
	var profileInfo = document.getElementById("profile-info");
	var content = document.createElement("div");
	profileInfo.parentNode.replaceChild(content, profileInfo);
	scroll(0, 0);
	content.id = "subscribersContentDiv";
	var hdr = document.createElement("div");
	content.appendChild(hdr);
	hdr.id = "subscribersHeaderDiv"
	hdr.className = "headerDiv";
	hdr.style.width = "1000px";
	var h4 = document.createElement("h4");
	hdr.appendChild(h4);
	h4.id = "subscribersHdr";
	h4.className = "tabHeader";
	h4.appendChild(document.createTextNode("SUBSCRIBERS"));
	var div = document.createElement("div");
	hdr.appendChild(div);
	div.id = "buddiesIcon";
	div.className = "headerIcon";
	div = document.createElement("div");
	hdr.appendChild(div);
	div.className = "outerpod-header-right";
	div.style.top = "-12px";
	div.style.right = "12px";
	var span = document.createElement("span");
	div.appendChild(span);
	span.className = "js-close-button";
	var img = document.createElement("img");
	span.appendChild(img);
	img.className = "closedetail";
	img.alt = "close";
	img.src = "/static/war/images/global/button_close.png";
	img.addEventListener("click", function() { content.parentNode.replaceChild(profileInfo, content); }, false);

	div = document.createElement("div");
	content.appendChild(div);
	div.id = "buddyCount";
	div.className = "graySubHead";
	div.appendChild(document.createTextNode("My "));
	span = document.createElement("span");
	div.appendChild(span);
	span.id = "numSubscribers";
	span.appendChild(document.createTextNode(subsXml.getElementsByTagName("count")[0].firstChild.data));
	div.appendChild(document.createTextNode(" SUBSCRIBERS:"));

	var subs = subsXml.getElementsByTagName("buddy");
	var row = false;
	for(var s = 0; s < subs.length; s++) {
		if(s % 2 == 0) {  // only do a new row for every other subscriber
			row = document.createElement("div");
			content.appendChild(row);
			row.className = "buddyRow";
			row.style.height = "100px";
			row.style.width = "1000px";
			row.style.visibility = "visible";
			row.style.textAlign = "left";
		}
		div = createSubscriberDiv(subs[s].getElementsByTagName("name")[0].firstChild.data);
		row.appendChild(div);
		div.style.width = "500px";
	}
}

function showAchievements() {
  var achs = document.createTextNode("(counting...)");
  addUserStat("achievements", "Achievements: ", achs);
  getAsync("http://www.spore.com/rest/achievements/" + username + "/0/10000", gotAchievementXml, achs);
}
function gotAchievementXml(req, achs) {
	var response = req.responseXML.documentElement;
	var count = response.getElementsByTagName("length");
	count = count[0].firstChild.data;
	achs.data = count;
	var achHdr = document.getElementById("achHdr");
	if(achHdr)
	  achHdr.firstChild.data += " (" + count + ")";
}

function addUserStat(id, label, value) {
  var span = document.createElement("span");
  span.id = id;
  span.className = "userData";
  span.appendChild(value);
  var div = document.createElement("div");
  div.id = id + "Label";
  div.className = "dataLabel";
  div.style.marginTop = "10px";
  div.appendChild(document.createTextNode(label));
  div.appendChild(span);
  uploaded.parentNode.insertBefore(div, uploaded);
}

function addQualitySporeLink() {
	var userData = document.getElementById("pubUserDataDiv");
	if(userData) {
		var qslink = document.createElement("a");
		qslink.href = "http://www.qualityspore.com/ProfileViewer.htm?profile=" + username;
		qslink.appendChild(document.createTextNode("See " + username + "'s QualitySPORE profile"));
		var div = document.createElement("div");
		div.id = "qualitySporeLink";
		div.className = "dataLabel";
		div.appendChild(qslink);
		userData.parentNode.insertBefore(div, userData);
	}
}

function hideSporeIslands() {
	var topnews = document.getElementById("TopnewsDiv");
	if(topnews) {
		var link = topnews.getElementsByTagName("a");
		for(var i = link.length - 1; i >= 0; i--)
			if(link[i].href == "http://apps.facebook.com/sporeislands/")
				link[i].parentNode.removeChild(link[i]);
	}
}

function getUsername(publicProfile) {
	if(publicProfile) {
		// potentially viewing someone else's profile, so grab username from url
		var username = document.location.pathname.split("/");
		return username[username.length - 1];
	} else {
		// get the currently logged in user since viewing own profile
		var name = document.getElementById("auxwelcome");
		name = name.getElementsByTagName("a");
		return name[0].firstChild.nodeValue;
	}
}

function getAsync(url, finished, args) {
	var req = new XMLHttpRequest();
	req.onreadystatechange = function() {
		if(req.readyState == 4)
			finished(req, args);
	}
	req.open("GET", url, true);
	req.send(null);
	return true;
}
