<?php
  $dbuser = 'yourmysqluser';
  $dbpass = 'yourmysqlpass';
  $dbname = 'yourmysqldatabase';
  // check if the comment form information has been sent to this file
  if($_SERVER['REQUEST_URI'] == '/comments.php') {
    if(@mysql_connect('localhost',$dbuser,$dbpass))
      if(@mysql_select_db($dbname)) {
        // tidy up the comments by adding line breaks wherever the commenter
        // pressed enter
        if($comments = addslashes(str_replace(array("\r\n","\n","\r"), '<br />', stripslashes($_POST['comments'])))) {
          // take the contact and make a valid e-mail link or url
          $url = $_POST['contact'];
          if(strlen($url) > 0)
            if(substr($url,0,7) != 'mailto:' && !strstr($url,'//')) {
              if(strstr($url,'@'))
                $url = "mailto:$url";
              else
                $url = "http://$url";
            }
          // change the name to anonymous if the didn't enter a name
          if(!($name = $_POST['name']))
            $name = 'anonymous';
          $sql = "insert into comments (page, instant, name, url, comments)\n values ('" . ($filepath = $_POST['page']) . "', " . time() . ", '$name',\n '$url',\n '$comments')";
          if(@mysql_query($sql)) {
            // mail the webmaster that someone posted a comment.  remove the
            // next line if you don't want this e-mail to go out.
            @mail('webmaster@' . $_SERVER['HTTP_HOST'], "$name has commented on $filepath", 'http://' . $_SERVER['HTTP_HOST'] . $filepath . '#comments',
                    'From: comments <whatyousay@' . $_SERVER['HTTP_HOST'] . ">\r\n" .
                    'X-Mailer: PHP/' . phpversion() . "\r\n");
            // tell the browser to go back to the page that was commented on
            // so the commenter can see his/her comments
            header('Location: http://' . $_SERVER['HTTP_HOST'] . $filepath . "#comments\r\n");
            exit;
          } else {
            //query failed.  output an error message here if you want
          }
        } else {
          //no comments entered.  output an error message here if you want
        }
        mysql_close();
    } else {
      //can't connect to db.  output an error message here if you want
    }
  }
?>
      <div class="usercomments">
        <h2><a class="ref" name="comments">comments</a></h2>
<?php
  $page = $_SERVER['PHP_SELF'];
  while(substr($page,0,2) == '//')
    $page = substr($page,1);
  @mysql_connect('localhost',$dbuser,$dbpass);
  @mysql_select_db($dbname);
  // get all the comments for the page (if any) and display them
  $comments = mysql_query("select * from comments where page='" . $page . "' order by instant");
  if($comments)
    if(($rows = mysql_num_rows($comments)) > 0) {
      for($comment = 0; $comment < $rows; $comment++) {
        echo "        <div class=\"header\">\n" .
             "          <span class=\"date\">" . strtolower(date("F d, Y \a\\t\ g:i:s a",mysql_result($comments,$comment,'instant'))) . "</span>\n";
        $name = stripslashes(mysql_result($comments,$comment,'name'));
        if($url = stripslashes(mysql_result($comments,$comment,'url')))
          echo "          <a href=\"$url\" title=\"contact $name\">$name</a>\n";
        else
          echo "          <span class=\"name\">$name</span>\n";
        echo "        </div>\n" .
             "        <div class=\"comments\">\n          " . 
             stripslashes(mysql_result($comments,$comment,'comments')) .
             "\n        </div>\n";
      }
    }
?>
        <form method="post" action="/comments.php">
          name:
          <input class="field" name="name" maxlength="45" />
          contact <span class="hint">(e-mail or url)</span>:
          <input class="field" name="contact" maxlength="90" />
          comments <span class="hint">(html allowed, but may get edited)</span>:
          <textarea class="field" name="comments" rows="" cols=""></textarea>
          <div align="center">
            <input class="button" type="submit" value="save" /> &nbsp;
            <input class="button" type="reset" value="clear" />
          </div>
          <input type="hidden" name="page" value="<?php echo $page; ?>" />
        </form>
      </div>
