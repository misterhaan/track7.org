function elements(where,msg) {
  var path = "../";
  if(where == "main" || where == "contact" || where == "oldguestbook" || where == "new")
      path = "";
  document.write(
    "      <div class=thinline></div>" +
    "      <div class=elements>" +
    "        elements:&nbsp; [ "
  );
  if(where != "notebook")
    document.write("      <a class=element onmouseover=" + '"' + "javascript:window.status='read the notebook';return true;" + '"' + " title='read the notebook' onmouseout=" + '"' + "javascript:window.status='" + msg + "';return true;" + '"' + " href=http://notebook.track7.vze.com>notebook</a> |");
  else
    document.write("      notebook |");
  if(where != "heart")
    document.write("      <a class=element onmouseover=" + '"' + "javascript:window.status='open my heart';return true;" + '"' + " title='open my heart' onmouseout=" + '"' + "javascript:window.status='" + msg + "';return true;" + '"' + " href=http://heart.track7.vze.com>heart</a> |");
  else
    document.write("      heart |");
  if(where != "geek")
    document.write("      <a class=element onmouseover=" + '"' + "javascript:window.status='be a geek';return true;" + '"' + " title='be a geek' onmouseout=" + '"' + "javascript:window.status='" + msg + "';return true;" + '"' + " href=http://geek.track7.vze.com>geek</a> |");
  else
    document.write("      geek |");
  if(where != "photo")
    document.write("      <a class=element onmouseover=" + '"' + "javascript:window.status='look';return true;" + '"' + " title=look onmouseout=" + '"' + "javascript:window.status='" + msg + "';return true;" + '"' + " href=http://photo.track7.vze.com>photo</a> |");
  else
    document.write("      photo |");
  if(where != "music")
    document.write("      <a class=element onmouseover=" + '"' + "javascript:window.status='listen';return true;" + '"' + " title=listen onmouseout=" + '"' + "javascript:window.status='" + msg + "';return true;" + '"' + " href=http://music.track7.vze.com>music</a> |");
  else
    document.write("      music |");
  if(where != "contact")
    document.write("      <a class=element onmouseover=" + '"' + "javascript:window.status='make contact!';return true;" + '"' + " title='make contact!' onmouseout=" + '"' + "javascript:window.status='" + msg + "';return true;" + '"' + " href=http://track7.vze.com/contacts.html>contact</a> |");
  else
    document.write("      contact |");
  if(where != "sign")
    document.write("      <a class=element onmouseover=" + '"' + "javascript:window.status='make your mark--sign the guestbook';return true;" + '"' + " title='make your mark--sign the guestbook' onmouseout=" + '"' + "javascript:window.status='" + msg + "';return true;" + '"' + " href=http://track7.vze.com/sign.html>sign</a>");
  else
    document.write("      sign");
  document.write(
    "      ]</div>" +
    "      <div class=thinline></div>"
  );
  document.write("    <div align=right>");
  if(where != "main")
    document.write("<a style={background:transparent;} onmouseover=" + '"' + "javascript:document.t7.src='" + path + "t7hover.gif';window.status='go home';return true;" + '"' + " onmouseout=" + '"' + "javascript:document.t7.src='" + path + "t7.gif';window.status='" + msg + "';return true;" + '"' + " href=http://track7.vze.com/track7.html>");
  document.write("<img name=t7 src=" + path + "t7.gif style={margin-right:5px;margin-bottom:5px;width:100px;height:50px;} ");
  if(where != "main")
    document.write("alt=home></a");
  document.write("></div>");
  document.write("<div class=elements>last update:&nbsp; " + document.lastModified + "</div>");
}

function hostedby()
{
  document.write("    <div class=elements style=" + '"' + "{color:#cccccc;}" + '"' + ">hosted by <a href=" + '"' + "http://www.4gigs.com/" + '"' + " target=_top class=element style=" + '"' + "{background:transparent;}" + '"' + ">4gigs.com free hosting</a>, brought to you by <a href=" + '"' + "http://www.ocssolutions.com/" + '"' + " target=_top class=element style=" + '"' + "{background:transparent;}" + '"' + ">ocs solutions</a>.</div>");
}
