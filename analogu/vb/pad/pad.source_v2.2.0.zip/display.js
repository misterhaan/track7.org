function display(item, how) {
  if (document.getElementById)
    document.getElementById(item).style.display = how;
  else if (document.all)
    document.all[item].style.display = how;
  else
    return true;
  return false;
}
